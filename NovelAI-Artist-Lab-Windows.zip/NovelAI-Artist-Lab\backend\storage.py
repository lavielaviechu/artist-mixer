from __future__ import annotations

import json
import os
import threading
import uuid
from pathlib import Path
from typing import Any


class Storage:
    def __init__(self, root: Path):
        self.root = root
        self.data_dir = root / "data"
        self.outputs_dir = root / "outputs"
        self.logs_dir = root / "logs"
        self._lock = threading.RLock()
        for path in (self.data_dir, self.outputs_dir, self.logs_dir):
            path.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        return self.data_dir / f"{name}.json"

    def read_json(self, name: str, default: Any) -> Any:
        path = self._path(name)
        with self._lock:
            if not path.exists():
                return default
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return default

    def read_json_file(self, path: Path) -> Any:
        with self._lock:
            return json.loads(path.read_text(encoding="utf-8"))

    def write_json(self, name: str, value: Any) -> None:
        self.atomic_json(self._path(name), value)

    def atomic_json(self, path: Path, value: Any) -> None:
        self._atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8"))

    def write_bytes(self, path: Path, data: bytes) -> None:
        self._atomic_write(path, data)

    def _atomic_write(self, path: Path, data: bytes) -> None:
        """Write to a temp file and replace; on any failure the old file stays as it was
        and the temp file is removed (a cleanup failure is ignored, never raised)."""
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        with self._lock:
            try:
                temp.write_bytes(data)
                os.replace(temp, path)
            finally:
                try:
                    temp.unlink(missing_ok=True)
                except OSError:
                    pass

    def public_path(self, path: Path) -> str:
        return "/generated/" + path.relative_to(self.outputs_dir).as_posix()

    def get_token(self) -> str:
        return str(self.read_json("secrets", {}).get("token", ""))

    def set_token(self, token: str | None) -> None:
        if token:
            self.write_json("secrets", {"token": token})
        else:
            path = self._path("secrets")
            if path.exists():
                path.unlink()

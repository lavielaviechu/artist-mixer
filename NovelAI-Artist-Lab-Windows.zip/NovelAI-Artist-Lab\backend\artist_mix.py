from __future__ import annotations

import math
import random
import re
from decimal import Decimal, ROUND_HALF_UP
from typing import Iterable


class MixValidationError(ValueError):
    pass


def normalize_artist_name(value: str) -> str:
    value = value.strip()
    if value.lower().startswith("artist:"):
        value = value[7:].strip()
    return value


def normalize_artist_list(values: str | Iterable[str]) -> list[str]:
    lines = values.splitlines() if isinstance(values, str) else values
    result: list[str] = []
    seen: set[str] = set()
    for raw in lines:
        name = normalize_artist_name(str(raw))
        key = name.casefold()
        if name and key not in seen:
            result.append(name)
            seen.add(key)
    return result


def format_weight(value: float, decimals: int = 1) -> str:
    quantum = Decimal(1).scaleb(-decimals)
    rounded = Decimal(str(value)).quantize(quantum, rounding=ROUND_HALF_UP)
    return f"{rounded:.{decimals}f}"


def format_artist_tag(name: str, weight: float, decimals: int = 1) -> str:
    return f"{format_weight(weight, decimals)}::artist:{normalize_artist_name(name)} ::"


def format_artist_mix(artists: list[dict], decimals: int = 1) -> str:
    return ", ".join(format_artist_tag(a["name"], a["weight"], decimals) for a in artists)


def combination_capacity(pool_size: int, min_count: int, max_count: int) -> int:
    return sum(math.comb(pool_size, k) for k in range(min_count, max_count + 1))


_WEIGHTED_ARTIST_RE = re.compile(
    r"(?P<weight>[+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*::\s*artist\\?:\s*(?P<name>[^,:\r\n]+?)\s*::",
    re.IGNORECASE,
)
_PLAIN_ARTIST_RE = re.compile(r"artist\\?:\s*(?P<name>[^\s,:\r\n]+)", re.IGNORECASE)


def _prompt_artist_matches(prompt: str) -> list[dict]:
    matches: list[dict] = []
    occupied: list[tuple[int, int]] = []
    for match in _WEIGHTED_ARTIST_RE.finditer(prompt):
        name = normalize_artist_name(match.group("name").strip())
        if name:
            matches.append({"name": name, "weight": float(match.group("weight")), "span": match.span()})
            occupied.append(match.span())
    for match in _PLAIN_ARTIST_RE.finditer(prompt):
        if any(start <= match.start() < end for start, end in occupied):
            continue
        name = normalize_artist_name(match.group("name").strip())
        if name:
            matches.append({"name": name, "weight": None, "span": match.span()})
    return sorted(matches, key=lambda item: item["span"][0])


def extract_artist_tags(prompt: str) -> list[dict]:
    result: list[dict] = []
    seen: set[str] = set()
    for item in _prompt_artist_matches(prompt):
        key = item["name"].casefold()
        if key not in seen:
            result.append({"name": item["name"], "weight": item["weight"]})
            seen.add(key)
    return result


def detect_artist_input(value: str) -> list[str]:
    """Detect artist names from a NovelAI prompt or a loose pasted name list."""
    detected = extract_artist_tags(value)
    if detected:
        return [item["name"] for item in detected]
    return normalize_artist_list(re.split(r"[\r\n,;]+", value))


def replace_artist_tags_with_placeholder(prompt: str) -> tuple[str, list[dict]]:
    matches = _prompt_artist_matches(prompt)
    artists = extract_artist_tags(prompt)
    if not matches:
        return prompt, artists
    insert_placeholder = "{{ARTISTS}}" not in prompt and "{{ARTIST_BLOCK}}" not in prompt
    chunks: list[str] = []
    cursor = 0
    for index, item in enumerate(matches):
        start, end = item["span"]
        chunks.append(prompt[cursor:start])
        if index == 0 and insert_placeholder:
            chunks.append("{{ARTISTS}}")
        cursor = end
    chunks.append(prompt[cursor:])
    result = "".join(chunks)
    # Removing adjacent artist fields can leave an empty comma-delimited slot.
    # Only normalize those empty separators created by the removals.
    while re.search(r",[ \t]*,", result):
        result = re.sub(r",[ \t]*,", ",", result)
    result = re.sub(r"^[ \t]*,[ \t]*", "", result)
    result = re.sub(r"[ \t]*,[ \t]*$", "", result)
    return result, artists


def migrate_artist_record(record: dict | str) -> dict:
    source = {"name": record} if isinstance(record, str) else dict(record)
    name = normalize_artist_name(str(source.get("name", "")))
    legacy_mix = bool(source.get("mix_enabled", source.get("mix_selected", True)))
    fixed_include = bool(source.get("fixed_include", False))
    if fixed_include:
        legacy_mix = True
    # "enabled" is the single checkbox: usable artist AND random-mix candidate.
    # Older data kept "enabled" (활성) and "MIX" separately; real pools used MIX as the
    # meaningful state (e.g. every artist 활성 OFF + MIX ON with the "믹스 선택 작가"
    # pool), so the checkbox takes the old MIX value. mix_enabled/mix_selected are
    # kept as mirrors for older readers, which also makes this migration idempotent.
    enabled = legacy_mix
    mode = source.get("weight_mode", "global")
    if mode not in {"global", "fixed", "range"}:
        mode = "global"
    return {
        **source,
        "name": name,
        "enabled": enabled,
        "favorite": bool(source.get("favorite", False)),
        "excluded": bool(source.get("excluded", False)),
        "mix_enabled": enabled,
        "mix_selected": enabled,
        "fixed_include": fixed_include,
        "weight_mode": mode,
        "fixed_weight": source.get("fixed_weight"),
        "weight_min": source.get("weight_min"),
        "weight_max": source.get("weight_max"),
    }


def migrate_artist_records(records: Iterable[dict | str]) -> list[dict]:
    return [migrate_artist_record(record) for record in records if normalize_artist_name(str(record.get("name", "") if isinstance(record, dict) else record))]


def _random_weight(rng: random.Random, minimum: float, maximum: float, decimals: int) -> float:
    scale = 10**decimals
    low = math.ceil((minimum * scale) - 1e-9)
    high = math.floor((maximum * scale) + 1e-9)
    if low > high:
        raise MixValidationError("Weight 범위에 선택 가능한 값이 없습니다.")
    return rng.randint(low, high) / scale


def _validate_artist_rule(artist: dict) -> None:
    mode = artist.get("weight_mode", "global")
    if mode == "fixed" and artist.get("fixed_weight") is None:
        raise MixValidationError(f"{artist['name']}: 고정 weight가 필요합니다.")
    if mode == "range":
        minimum, maximum = artist.get("weight_min"), artist.get("weight_max")
        if minimum is None or maximum is None:
            raise MixValidationError(f"{artist['name']}: 개별 weight 최소/최대가 필요합니다.")
        if float(minimum) > float(maximum):
            raise MixValidationError(f"{artist['name']}: 최소 weight가 최대 weight보다 큽니다.")


def _combo_capacity(candidate_count: int, fixed_count: int, min_count: int, max_count: int) -> int:
    effective_min = max(min_count, fixed_count)
    return sum(math.comb(candidate_count, total - fixed_count) for total in range(effective_min, max_count + 1))


def validate_mix_settings(pool: list[dict], min_count: int, max_count: int, combo_count: int) -> None:
    if not pool:
        raise MixValidationError("랜덤 믹스에 사용할 artist가 없습니다.")
    if min_count < 1 or max_count < min_count:
        raise MixValidationError("Artist 개수 범위가 올바르지 않습니다.")
    fixed = [artist for artist in pool if artist.get("fixed_include")]
    candidates = [artist for artist in pool if not artist.get("fixed_include")]
    if len(fixed) > max_count:
        raise MixValidationError(f"고정 작가가 {len(fixed)}명인데 최대 작가 수가 {max_count}명입니다.")
    if max_count > len(pool):
        raise MixValidationError(f"최대 artist 수({max_count})가 사용 가능한 pool({len(pool)}명)보다 큽니다.")
    for artist in pool:
        _validate_artist_rule(artist)
    capacity = _combo_capacity(len(candidates), len(fixed), min_count, max_count)
    if combo_count > capacity:
        raise MixValidationError(f"중복 없이 만들 수 있는 조합은 최대 {capacity}개입니다.")


def generate_combo(
    pool: list[dict], rng: random.Random, count: int,
    weight_min: float, weight_max: float, decimals: int = 1,
) -> list[dict]:
    fixed = [artist for artist in pool if artist.get("fixed_include")]
    candidates = [artist for artist in pool if not artist.get("fixed_include")]
    chosen = fixed + rng.sample(candidates, count - len(fixed))
    # fixed_include controls membership, not prompt position. Mix every selected
    # artist into a deterministic random order so pinned artists do not always
    # occupy the beginning of the final prompt.
    rng.shuffle(chosen)
    result: list[dict] = []
    for artist in chosen:
        mode = artist.get("weight_mode", "global")
        if mode == "fixed":
            weight = float(artist["fixed_weight"])
        elif mode == "range":
            weight = _random_weight(rng, float(artist["weight_min"]), float(artist["weight_max"]), decimals)
        else:
            weight = _random_weight(rng, weight_min, weight_max, decimals)
        result.append({
            "name": artist["name"], "weight": weight, "weight_mode": mode,
            "fixed_include": bool(artist.get("fixed_include")),
        })
    return result


def generate_combo_set(
    pool: str | Iterable[str | dict], min_count: int, max_count: int,
    weight_min: float, weight_max: float, decimals: int,
    combo_count: int, mix_seed: int,
) -> list[dict]:
    if isinstance(pool, str):
        rules = migrate_artist_records(normalize_artist_list(pool))
    else:
        rules = migrate_artist_records(pool)
    # Checked/unchecked filtering is done by the caller's pool mode ("all" includes
    # unchecked artists); only hard-excluded artists are always dropped here.
    rules = [artist for artist in rules if not artist.get("excluded", False)]
    validate_mix_settings(rules, min_count, max_count, combo_count)
    if weight_min > weight_max:
        raise MixValidationError("최소 weight가 최대 weight보다 큽니다.")
    if decimals < 0 or decimals > 4:
        raise MixValidationError("Weight 소수점 자릿수는 0~4여야 합니다.")

    rng = random.Random(mix_seed)
    combos: list[dict] = []
    used_sets: set[tuple[str, ...]] = set()
    fixed_count = sum(1 for artist in rules if artist.get("fixed_include"))
    candidate_count = len(rules) - fixed_count
    capacity = _combo_capacity(candidate_count, fixed_count, min_count, max_count)
    max_attempts = max(500, min(capacity * 20, 100_000))
    attempts = 0
    while len(combos) < combo_count and attempts < max_attempts:
        attempts += 1
        count = rng.randint(max(min_count, fixed_count), max_count)
        artists = generate_combo(rules, rng, count, weight_min, weight_max, decimals)
        identity = tuple(sorted(a["name"].casefold() for a in artists))
        if identity in used_sets:
            continue
        used_sets.add(identity)
        combos.append({
            "combo_id": len(combos) + 1,
            "artists": artists,
            "artist_mix": format_artist_mix(artists, decimals),
            "mix_seed": mix_seed,
        })
    if len(combos) != combo_count:
        raise MixValidationError("요청한 수만큼 고유 조합을 만들 수 없습니다. 조합 수를 줄여 주세요.")
    return combos


ARTIST_BLOCK_PLACEHOLDER = "{{ARTIST_BLOCK}}"
LEGACY_ARTIST_PLACEHOLDER = "{{ARTISTS}}"
STYLE_BLOCK_PLACEHOLDER = "{{STYLE_BLOCK}}"
_BLOCK_PLACEHOLDER_RE = re.compile(r"\{\{(ARTIST_BLOCK|ARTISTS|STYLE_BLOCK)\}\}")
# Private-use markers keep block boundaries while separators are cleaned up.
_REMOVED = "\x00"
_MARK = "\x01"


def count_block_placeholders(prompt: str) -> dict[str, int]:
    return {
        "artist": prompt.count(ARTIST_BLOCK_PLACEHOLDER) + prompt.count(LEGACY_ARTIST_PLACEHOLDER),
        "style": prompt.count(STYLE_BLOCK_PLACEHOLDER),
    }


def has_artist_placeholder(prompt: str) -> bool:
    return count_block_placeholders(prompt)["artist"] > 0


def _remove_marked_slots(prompt: str) -> str:
    # A disabled/empty block removes its placeholder together with one adjacent
    # comma separator, so "a, {{STYLE_BLOCK}}, b" becomes "a, b".
    while _REMOVED in prompt:
        updated = re.sub(rf",[ \t\r\n]*{_REMOVED}[ \t\r\n]*(?=,|$)", "", prompt, count=1)
        if updated == prompt:
            updated = re.sub(rf"^[ \t\r\n]*{_REMOVED}[ \t\r\n]*,?[ \t\r\n]*", "", prompt, count=1)
        if updated == prompt:
            updated = prompt.replace(_REMOVED, "", 1)
        prompt = updated
    return prompt


def assemble_prompt_blocks(
    base_prompt: str, artist_block: str | None = None, style_block: str | None = None,
    artist_fallback: str = "prepend", style_fallback: str = "append",
) -> dict:
    """Insert Artist/Style blocks into placeholders or their fallback positions.

    ``None`` or an empty block means the block is off: its placeholders are
    removed and nothing is inserted. ``{{ARTISTS}}`` is kept as a legacy alias
    of ``{{ARTIST_BLOCK}}``.
    """
    blocks = {"artist": (artist_block or "").strip(), "style": (style_block or "").strip()}
    base_prompt = base_prompt.replace(_REMOVED, "").replace(_MARK, "")
    counts = count_block_placeholders(base_prompt)

    def mark(match: re.Match) -> str:
        kind = "style" if match.group(1) == "STYLE_BLOCK" else "artist"
        return f"{_MARK}{kind}{_MARK}" if blocks[kind] else _REMOVED

    marked = _remove_marked_slots(_BLOCK_PLACEHOLDER_RE.sub(mark, base_prompt))
    fallbacks = {"artist": artist_fallback, "style": style_fallback}
    prepend = [kind for kind in ("artist", "style") if blocks[kind] and not counts[kind] and fallbacks[kind] == "prepend"]
    append = [kind for kind in ("artist", "style") if blocks[kind] and not counts[kind] and fallbacks[kind] != "prepend"]
    parts = [f"{_MARK}{kind}{_MARK}" for kind in prepend]
    if marked.strip():
        parts.append(marked)
    parts.extend(f"{_MARK}{kind}{_MARK}" for kind in append)
    marked = ", ".join(parts)

    segments: list[dict] = []
    for index, chunk in enumerate(marked.split(_MARK)):
        if index % 2:
            segments.append({"type": chunk, "text": blocks[chunk]})
        elif chunk:
            segments.append({"type": "text", "text": chunk})
    return {
        "final_prompt": "".join(segment["text"] for segment in segments),
        "segments": segments,
        "artist_placeholder_count": counts["artist"],
        "style_placeholder_count": counts["style"],
    }


def apply_prompt_blocks(
    base_prompt: str, artist_block: str | None = None, style_block: str | None = None,
    artist_fallback: str = "prepend", style_fallback: str = "append",
) -> tuple[str, dict]:
    result = assemble_prompt_blocks(base_prompt, artist_block, style_block, artist_fallback, style_fallback)
    return result["final_prompt"], {
        "artist_placeholder_count": result["artist_placeholder_count"],
        "style_placeholder_count": result["style_placeholder_count"],
    }


def apply_artist_mix(base_prompt: str, artist_mix: str, fallback: str = "prepend") -> tuple[str, int]:
    final, counts = apply_prompt_blocks(base_prompt, artist_mix, None, fallback)
    return final, counts["artist_placeholder_count"]


def safe_folder_name(name: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return (cleaned[:80] or "artist")

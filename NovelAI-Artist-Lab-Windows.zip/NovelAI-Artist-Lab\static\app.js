const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let appState = { artists: [], saved_combos: [], style_pool: null };
let blockSample = {artist_block:'', style_block:'', artist_error:null, style_error:null, source:''};
let preview = null;
let activeJobId = null;
let pollTimer = null;
let detectedPrompt = {artists: [], base_prompt: ''};
let detectedAddArtists = [];
let selectedDetectedAddArtists = new Set();
let detectedCustomArtists = [];
let selectedDetectedCustomArtists = new Set();
let customSingleArtists = [];
let activeArtistSettings = null;
let galleryView = 'compare';

function esc(value) {
  return String(value ?? "").replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function value(id) { return $(id).value; }
function num(id, nullable=false) { const v=value(id); return nullable && v==='' ? null : Number(v); }
function toast(message, error=false) {
  const node=$('#toast'); node.textContent=message; node.className=`toast show${error?' error':''}`;
  clearTimeout(node._timer); node._timer=setTimeout(()=>node.className='toast',3300);
}
function openDialog(node) {
  if(!node)return;
  if(typeof node.showModal==='function'){if(!node.open)node.showModal();return}
  node.setAttribute('open','');node.classList.add('dialog-fallback');
}
function closeDialog(node) {
  if(!node)return;
  if(typeof node.close==='function'){node.close();return}
  node.removeAttribute('open');node.classList.remove('dialog-fallback');
}
async function api(url, options={}) {
  const config={...options, headers:{'Content-Type':'application/json',...(options.headers||{})}};
  const response=await fetch(url,config);
  if(!response.ok){let message=`요청 실패 (${response.status})`;try{const body=await response.json();message=body.detail||message}catch{}throw new Error(Array.isArray(message)?message.map(x=>x.msg).join(', '):message)}
  return response.status===204?null:response.json();
}

function generationSettings() {
  return {model:value('#model'),width:num('#width'),height:num('#height'),steps:num('#steps'),sampler:value('#sampler'),scheduler:value('#scheduler'),scale:num('#scale'),cfg_rescale:num('#cfgRescale')};
}
function syncResolutionPreset() {
  const dimensions=`${value('#width')}x${value('#height')}`;
  const preset=$('#resolutionPreset');
  preset.value=[...preset.options].some(option=>option.value===dimensions)?dimensions:'custom';
  updateResolutionFields();
}
function applyResolutionPreset() {
  const preset=value('#resolutionPreset');
  if(preset!=='custom'){const [width,height]=preset.split('x').map(Number);$('#width').value=width;$('#height').value=height}
  updateResolutionFields();
}
function updateResolutionFields() {
  const custom=value('#resolutionPreset')==='custom';$$('#widthField,#heightField').forEach(node=>node.classList.toggle('hidden',!custom));updateGenerationSummary();
}
function updateGenerationSummary() {
  const sampler=$('#sampler').selectedOptions[0]?.textContent||value('#sampler'),parts=[`${value('#width')}×${value('#height')}`,`${value('#steps')} steps`,sampler,`CFG ${value('#scale')}`];
  parts.push(`Style Block ${$('#styleBlockEnabled').checked?'ON':'OFF'}`);
  $('#generationSummary').textContent=parts.join(' · ');
}
function blockSettings() {
  return {artist_block_enabled:$('#artistBlockEnabled').checked,style_block_enabled:$('#styleBlockEnabled').checked,style_fallback:value('#styleFallback')};
}
const DEFAULT_ARTIST_TEMPLATE='artist:{artistname},';
let artistTemplate=DEFAULT_ARTIST_TEMPLATE; // last valid value; an invalid edit is never sent or saved
function settingsPayload() {
  return {generation:generationSettings(),positive_prompt:value('#positivePrompt'),negative_prompt:value('#negativePrompt'),character_prompt:value('#characterPrompt'),placeholder_fallback:value('#fallback'),retry_count:2,artist_template:artistTemplate,...blockSettings()};
}
function showArtistTemplateState(){
  const input=value('#artistTemplate'),valid=input.includes('{artistname}'),node=$('#artistTemplateMsg');
  node.classList.toggle('error',!valid);
  node.textContent=valid?'':'{artistname} 이 있어야 저장됩니다. 지금 값은 저장되지 않았습니다.';
  $('#artistTemplateResetBtn').disabled=input===DEFAULT_ARTIST_TEMPLATE;
  return valid;
}
async function onArtistTemplateChange(){
  if(!showArtistTemplateState()||value('#artistTemplate')===artistTemplate)return;
  artistTemplate=value('#artistTemplate');
  try{await saveCommonSettings();refreshBlockSample(false);if(preview)renderPreview()}catch(e){toast(e.message,true)}
}
function resetArtistTemplate(){$('#artistTemplate').value=DEFAULT_ARTIST_TEMPLATE;onArtistTemplateChange()}
function fillSettings(s) {
  const g=s.generation;
  $('#positivePrompt').value=s.positive_prompt; $('#negativePrompt').value=s.negative_prompt; $('#characterPrompt').value=s.character_prompt||''; $('#fallback').value=s.placeholder_fallback;
  for(const key of ['model','width','height','steps','sampler','scheduler','scale']) $(`#${key}`).value=g[key];
  $('#cfgRescale').value=g.cfg_rescale??0;
  $('#artistBlockEnabled').checked=s.artist_block_enabled??true;$('#styleBlockEnabled').checked=!!s.style_block_enabled;$('#styleFallback').value=s.style_fallback||'append';
  artistTemplate=(s.artist_template||'').includes('{artistname}')?s.artist_template:DEFAULT_ARTIST_TEMPLATE;$('#artistTemplate').value=artistTemplate;showArtistTemplateState();
  syncResolutionPreset();loadPromptBlocks();updateBlockControls();updatePlaceholderWarning();
}

/* Prompt block editor.
 * The user edits an ordered list of text rows and draggable Artist/Style Block cards.
 * The list is serialized into #positivePrompt with internal markers ({{ARTIST_BLOCK}},
 * {{STYLE_BLOCK}}) so the backend and stored settings keep working; legacy {{ARTISTS}}
 * loads as an Artist Block. Users never see or type the markers. */
const BLOCK_TOKEN={artist:'{{ARTIST_BLOCK}}',style:'{{STYLE_BLOCK}}'};
const BLOCK_LABEL={artist:'Artist Block',style:'Style Block'};
let promptItems=[{type:'text',value:''}];
let focusedItem=-1;
let dragFrom=null;
function trimPromptText(text){return text.replace(/^[\s,]+|[\s,]+$/g,'')}
function parsePromptItems(prompt){
  const items=[];let cursor=0;
  for(const match of prompt.matchAll(/\{\{(ARTIST_BLOCK|ARTISTS|STYLE_BLOCK)\}\}/g)){
    const text=trimPromptText(prompt.slice(cursor,match.index));if(text)items.push({type:'text',value:text});
    items.push({type:match[1]==='STYLE_BLOCK'?'style':'artist'});cursor=match.index+match[0].length;
  }
  const rest=trimPromptText(prompt.slice(cursor));if(rest)items.push({type:'text',value:rest});
  if(!items.some(item=>item.type==='text'))items.push({type:'text',value:''});
  return items;
}
function serializePromptItems(items){
  return items.map(item=>item.type==='text'?trimPromptText(item.value):BLOCK_TOKEN[item.type]).filter(Boolean).join(', ');
}
function loadPromptBlocks(){promptItems=parsePromptItems(value('#positivePrompt'));focusedItem=-1;renderBlockEditor()}
function syncPromptFromBlocks(structural=false){
  $('#positivePrompt').value=serializePromptItems(promptItems);
  $('#positivePrompt').dispatchEvent(new Event('input',{bubbles:true}));
  if(structural){clearTimeout(schedulePromptPreview.timer);refreshPromptPreview()}
}
function autosizeTextarea(node){node.style.height='auto';node.style.height=`${node.scrollHeight+2}px`}
function autosizePromptRows(){$$('#promptBlockEditor .pb-textarea').forEach(autosizeTextarea)}
function renderBlockEditor(){
  const textRows=promptItems.filter(item=>item.type==='text').length;
  $('#promptBlockEditor').innerHTML=promptItems.map((item,index)=>item.type==='text'
    ?`<div class="pb-row pb-text" data-index="${index}"><span class="pb-handle" data-drag-handle title="끌어서 이동">⋮⋮</span><textarea class="pb-textarea" data-text-index="${index}" rows="1" spellcheck="false" placeholder="프롬프트 텍스트 입력">${esc(item.value)}</textarea>${textRows>1?`<button type="button" class="pb-icon pb-remove" data-remove-item="${index}" title="이 텍스트 줄 삭제">×</button>`:'<span></span>'}</div>`
    :`<div class="pb-row pb-block ${item.type}" data-index="${index}"><span class="pb-handle" data-drag-handle title="끌어서 이동">⋮⋮</span><div class="pb-block-body"><span class="pb-block-title">${BLOCK_LABEL[item.type]}</span><span class="pb-sample" data-sample="${item.type}"></span></div><span class="pb-actions"><button type="button" class="pb-icon" data-move-item="${index}" data-dir="-1" title="위로">↑</button><button type="button" class="pb-icon" data-move-item="${index}" data-dir="1" title="아래로">↓</button><button type="button" class="pb-icon pb-remove" data-remove-item="${index}" title="블록 삭제">×</button></span></div>`).join('');
  autosizePromptRows();requestAnimationFrame(autosizePromptRows);
  $$('[data-add-item]').forEach(node=>{const type=node.dataset.addItem;if(type==='text')return;const exists=promptItems.some(item=>item.type===type);node.disabled=exists;node.title=exists?`${BLOCK_LABEL[type]}이 이미 있습니다. 끌어서 위치를 옮기세요.`:`${BLOCK_LABEL[type]} 추가`});
  updateBlockSamples();
}
function updateBlockSamples(){
  const s=blockSettings();
  for(const type of ['artist','style']){
    const enabled=type==='artist'?s.artist_block_enabled:s.style_block_enabled,error=blockSample[`${type}_error`],sample=blockSample[`${type}_block`];
    $$(`#promptBlockEditor .pb-block.${type}`).forEach(node=>node.classList.toggle('off',!enabled));
    $$(`#promptBlockEditor [data-sample="${type}"]`).forEach(node=>{node.classList.toggle('error',enabled&&!!error);node.textContent=!enabled?'꺼짐 — 아래 Block 설정에서 켜면 적용됩니다':error||sample||'샘플 없음'});
  }
}
function addPromptItem(type){
  const at=focusedItem>=0&&focusedItem<promptItems.length?focusedItem+1:promptItems.length;
  promptItems.splice(at,0,type==='text'?{type:'text',value:''}:{type});
  renderBlockEditor();syncPromptFromBlocks(true);
  if(type==='text')$(`#promptBlockEditor [data-text-index="${at}"]`)?.focus();
}
function removePromptItem(index){
  promptItems.splice(index,1);
  if(!promptItems.some(item=>item.type==='text'))promptItems.push({type:'text',value:''});
  focusedItem=-1;renderBlockEditor();syncPromptFromBlocks(true);
}
function movePromptItem(from,insertAt){
  if(insertAt<0||insertAt>promptItems.length)return;
  const [item]=promptItems.splice(from,1);if(insertAt>from)insertAt--;
  promptItems.splice(insertAt,0,item);focusedItem=-1;renderBlockEditor();syncPromptFromBlocks(true);
}
function clearDropMarks(){$$('#promptBlockEditor .pb-row').forEach(node=>node.classList.remove('drop-before','drop-after','dragging'))}
function setupBlockEditor(){
  const editor=$('#promptBlockEditor');
  editor.addEventListener('input',e=>{const node=e.target;if(!node.matches('.pb-textarea'))return;promptItems[Number(node.dataset.textIndex)].value=node.value;autosizeTextarea(node);syncPromptFromBlocks()});
  editor.addEventListener('focusin',e=>{const row=e.target.closest('.pb-row');if(row)focusedItem=Number(row.dataset.index)});
  editor.addEventListener('click',e=>{
    const button=e.target.closest('button');if(!button)return;
    if(button.dataset.removeItem!==undefined)removePromptItem(Number(button.dataset.removeItem));
    if(button.dataset.moveItem!==undefined){const index=Number(button.dataset.moveItem),dir=Number(button.dataset.dir);movePromptItem(index,dir<0?index-1:index+2)}
  });
  // Pointer-based drag from the ⋮⋮ handle (works for mouse, touch and pen).
  const dropTarget=e=>document.elementFromPoint(e.clientX,e.clientY)?.closest('#promptBlockEditor .pb-row');
  editor.addEventListener('pointerdown',e=>{
    const handle=e.target.closest('[data-drag-handle]');if(!handle||e.button>0)return;
    e.preventDefault();dragFrom=Number(handle.closest('.pb-row').dataset.index);
    handle.setPointerCapture(e.pointerId);handle.closest('.pb-row').classList.add('dragging');document.body.classList.add('pb-dragging');
  });
  editor.addEventListener('pointermove',e=>{
    if(dragFrom===null)return;
    $$('#promptBlockEditor .pb-row').forEach(node=>node.classList.remove('drop-before','drop-after'));
    const row=dropTarget(e);if(!row||Number(row.dataset.index)===dragFrom)return;
    const box=row.getBoundingClientRect();row.classList.add(e.clientY>box.top+box.height/2?'drop-after':'drop-before');
  });
  const finishDrag=(e,commit)=>{
    if(dragFrom===null)return;
    const from=dragFrom,row=$('#promptBlockEditor .drop-before, #promptBlockEditor .drop-after');dragFrom=null;
    const target=row?Number(row.dataset.index):null,after=row?.classList.contains('drop-after');
    clearDropMarks();document.body.classList.remove('pb-dragging');
    if(commit&&target!==null&&target!==from)movePromptItem(from,after?target+1:target);
  };
  editor.addEventListener('pointerup',e=>finishDrag(e,true));
  editor.addEventListener('pointercancel',e=>finishDrag(e,false));
}
function updateBlockControls() {
  updateBlockSamples();
  const style=$('#styleBlockEnabled').checked;
  $('.block-card.style').classList.toggle('off',!style);$('.block-card.artist').classList.toggle('off',!$('#artistBlockEnabled').checked);
}
async function refreshBlockSample(fromPreview=true) {
  const s=blockSettings(),locked=fromPreview&&preview&&preview.combos?.length&&(preview.settings.artist_block_enabled??true)===s.artist_block_enabled&&(preview.settings.style_block_enabled??false)===s.style_block_enabled;
  if(locked){const c=preview.combos[0];blockSample={artist_block:c.artist_mix,style_block:c.style_block||'',artist_error:null,style_error:null,source:`확정된 Combo ${String(c.combo_id).padStart(3,'0')} 기준`}}
  else{try{blockSample={...await api('/api/blocks/sample',{method:'POST',body:JSON.stringify(previewRequest())}),source:'랜덤 샘플'}}catch(e){blockSample={artist_block:'',style_block:'',artist_error:e.message,style_error:null,source:'샘플 실패'}}}
  await refreshPromptPreview();
}
async function refreshPromptPreview() {
  const s=blockSettings();
  $('#blockPreviewSource').textContent=blockSample.source||'';updateBlockSamples();
  try{
    const result=await api('/api/prompt/preview',{method:'POST',body:JSON.stringify({prompt:value('#positivePrompt'),artist_block:blockSample.artist_block,style_block:blockSample.style_block,artist_block_enabled:s.artist_block_enabled,style_block_enabled:s.style_block_enabled,artist_fallback:value('#fallback'),style_fallback:s.style_fallback})});
    $('#finalPromptPreview').innerHTML=result.segments.map(seg=>seg.type==='text'?esc(seg.text):`<span class="seg ${seg.type}">${esc(seg.text)}</span>`).join('')||'<span class="muted">(빈 prompt)</span>';
  }catch(e){$('#finalPromptPreview').textContent=e.message}
}
function schedulePromptPreview(){clearTimeout(schedulePromptPreview.timer);schedulePromptPreview.timer=setTimeout(refreshPromptPreview,250)}
function scheduleSettingsSave(){clearTimeout(scheduleSettingsSave.timer);scheduleSettingsSave.timer=setTimeout(()=>saveCommonSettings().catch(e=>toast(e.message,true)),600)}
// Every common setting (prompts, negative, character, fallback, generation) is saved shortly
// after it changes; a save still pending when the page is closed or reloaded is flushed.
let commonAutosavePending=false;
function commonSettingsSavable(){const w=num('#width'),h=num('#height');return Number.isInteger(w)&&Number.isInteger(h)&&w>0&&h>0&&w%64===0&&h%64===0}
function scheduleCommonAutosave(){commonAutosavePending=true;clearTimeout(scheduleCommonAutosave.timer);scheduleCommonAutosave.timer=setTimeout(()=>{if(!commonSettingsSavable())return;commonAutosavePending=false;saveCommonSettings().catch(e=>{commonAutosavePending=true;toast(e.message,true)})},700)}
function flushCommonAutosave(){if(!commonAutosavePending||!commonSettingsSavable())return;commonAutosavePending=false;clearTimeout(scheduleCommonAutosave.timer);try{fetch('/api/settings',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(settingsPayload()),keepalive:true})}catch{}}
function onBlockSettingsChange(resample=false){updateBlockControls();updatePlaceholderWarning();if(resample)refreshBlockSample();else schedulePromptPreview();scheduleSettingsSave()}

/* Style Pool: ☑ = required (always in the Style Block), RND = random extra candidate, ⋯ = weight settings. */
let openStyleCategories=new Set();
let activeStyleTag=null;
function stylePool(){return appState.style_pool||{categories:[],tags:[],weight_range:{min:-1,max:1,step:0.1}}}
function styleWeightText(s){if(s.weight_mode==='fixed'&&s.weight!==null)return String(s.weight);if(s.weight_mode==='global')return 'W±';if(s.weight_mode==='range')return `${s.weight_min??'…'}~${s.weight_max??'…'}`;return ''}
function styleLine(s){if(s.weight_mode!=='fixed'||s.weight===null||s.weight===undefined)return s.tag;const w=Number(Number(s.weight).toFixed(2)).toString();return `${w.includes('.')?w:`${w}.0`}::${s.tag} ::`}
function categoryOptions(selected){return stylePool().categories.map(c=>`<option value="${esc(c.id)}" ${c.id===selected?'selected':''}>${esc(c.name)}</option>`).join('')}
function renderStyles() {
  const pool=stylePool(),required=pool.tags.filter(t=>t.required&&pool.categories.find(c=>c.id===t.category)?.enabled);
  $('#stylePoolCount').textContent=`필수 ${required.length}개`;
  $('#styleList').innerHTML=pool.categories.map(c=>{
    const tags=pool.tags.filter(t=>t.category===c.id),checked=tags.filter(t=>t.required),rnd=tags.filter(t=>t.rnd&&!t.required).length,open=openStyleCategories.has(c.id);
    const summary=checked.length?checked.map(t=>t.tag).join(', '):'필수 없음';
    return `<div class="style-cat ${c.enabled?'':'off'}">
      <div class="style-cat-head"><button type="button" class="style-cat-name" data-style-cat-open="${esc(c.id)}" aria-expanded="${open}"><span class="caret">${open?'▾':'▸'}</span>${esc(c.name)}<small>${tags.length}</small></button><label class="switch" title="카테고리 ON/OFF (꺼도 ☑·RND·weight 설정은 유지)"><input type="checkbox" data-style-cat-enabled="${esc(c.id)}" ${c.enabled?'checked':''}><span>${c.enabled?'ON':'OFF'}</span></label></div>
      <div class="style-cat-summary" title="${esc(summary)}">☑ ${esc(summary)}${rnd?` <span class="rnd-count">· RND ${rnd}개 중 ${c.rnd_min}~${c.rnd_max}</span>`:''}</div>
      ${open?`<div class="style-cat-tools"><span class="rnd-range">RND 추가<input type="number" min="0" max="50" value="${c.rnd_min}" data-style-cat-min="${esc(c.id)}" aria-label="RND 최소">~<input type="number" min="0" max="50" value="${c.rnd_max}" data-style-cat-max="${esc(c.id)}" aria-label="RND 최대">개</span><span><button class="mini" data-style-bulk="check_all" data-style-bulk-cat="${esc(c.id)}">전체 선택</button><button class="mini" data-style-bulk="uncheck_all" data-style-bulk-cat="${esc(c.id)}">전체 해제</button></span></div>
      <div class="style-rows">${tags.map(s=>`<div class="style-row ${s.required?'checked':''}"><input type="checkbox" ${s.required?'checked':''} data-style-required="${esc(s.tag)}" title="필수 포함"><span class="style-name" title="${esc(styleLine(s))}">${esc(s.tag)}${styleWeightText(s)?` <small class="style-weight">${esc(styleWeightText(s))}</small>`:''}</span><button class="icon-toggle rnd ${s.rnd?'on':''}" data-style-rnd="${esc(s.tag)}" title="랜덤 추가 후보">RND</button><button class="icon-toggle" data-style-settings="${esc(s.tag)}" title="weight / 세부 설정">⋯</button></div>`).join('')||'<div class="empty small">태그가 없습니다.</div>'}</div>`:''}
    </div>`}).join('');
  const addSelected=value('#styleAddCategory')||'custom';$('#styleAddCategory').innerHTML=categoryOptions(addSelected);
  const range=pool.weight_range;$('#styleWeightMin').value=range.min;$('#styleWeightMax').value=range.max;$('#styleWeightStep').value=range.step;
}
async function styleRequest(url,options,message){
  try{appState.style_pool=await api(url,options);renderStyles();if(activeStyleTag)fillStyleSettings();if(message)toast(message);refreshBlockSample(false);return true}catch(e){toast(e.message,true)}
  return false;
}
const jsonBody=(method,body)=>({method,body:JSON.stringify(body)});
async function addStyles(text){if(text.trim()&&await styleRequest('/api/styles/add',jsonBody('POST',{text,category:value('#styleAddCategory')}),'태그를 추가했습니다. ☑ 또는 RND로 사용할 수 있습니다.')){$('#styleAddInput').value='';openStyleCategories.add(value('#styleAddCategory'));renderStyles()}}
async function patchStyle(tag,changes){return styleRequest(`/api/styles/${encodeURIComponent(tag)}`,jsonBody('PATCH',changes))}
async function patchStyleCategory(id,changes){return styleRequest(`/api/styles/categories/${encodeURIComponent(id)}`,jsonBody('PATCH',changes))}
async function styleBulk(action,category){return styleRequest('/api/styles/bulk',jsonBody('POST',{action,category:category||null}),action==='check_all'?'필수 포함으로 모두 체크했습니다.':'필수 포함 체크를 해제했습니다.')}
async function randomizeStyleDefaults(){if(confirm('각 카테고리에서 태그 1개씩 새로 필수 체크합니다.\n현재 ☑ 체크는 해제되고 카테고리 ON/OFF는 기본값(채색/색감만 OFF)으로 돌아갑니다. RND와 weight 설정은 유지됩니다.'))await styleRequest('/api/styles/randomize-defaults',{method:'POST'},'기본 조합을 새로 뽑아 저장했습니다.')}
async function saveStyleWeightRange(){await styleRequest('/api/styles/weight-range',jsonBody('PUT',{min:num('#styleWeightMin'),max:num('#styleWeightMax'),step:num('#styleWeightStep')}),'Weight 전역 범위를 저장했습니다.')}
function fillStyleEditor(){const id=value('#styleEditCategory');$('#styleEditText').value=stylePool().tags.filter(t=>t.category===id).map(styleLine).join('\n')}
function openStyleEditor(){$('#styleEditCategory').innerHTML=categoryOptions([...openStyleCategories][0]||'style');fillStyleEditor();openDialog($('#styleEditDialog'));$('#styleEditText').focus()}
async function saveStyleEditor(){if(await styleRequest('/api/styles',jsonBody('PUT',{text:value('#styleEditText'),category:value('#styleEditCategory')}),'Style Pool을 저장했습니다.'))closeDialog($('#styleEditDialog'))}
function updateStyleWeightFields(){const mode=value('#styleDetailWeightMode');$('#styleFixedWeightFields').classList.toggle('hidden',mode!=='fixed');$('#styleRangeWeightFields').classList.toggle('hidden',mode!=='range')}
function fillStyleSettings(){
  const s=stylePool().tags.find(t=>t.tag===activeStyleTag);if(!s)return;const range=stylePool().weight_range;
  $('#styleSettingsName').textContent=s.tag;$('#styleDetailRequired').checked=s.required;$('#styleDetailRnd').checked=s.rnd;$('#styleDetailCategory').innerHTML=categoryOptions(s.category);$('#styleDetailWeightMode').value=s.weight_mode;
  $('#styleDetailWeight').value=s.weight??1.0;$('#styleDetailWeightMin').value=s.weight_min??range.min;$('#styleDetailWeightMax').value=s.weight_max??range.max;
  $$('#styleDetailWeight,#styleDetailWeightMin,#styleDetailWeightMax').forEach(node=>node.step=range.step);updateStyleWeightFields();
}
function openStyleSettings(tag){activeStyleTag=tag;fillStyleSettings();openDialog($('#styleSettingsDialog'))}
async function saveStyleSettings(){
  const mode=value('#styleDetailWeightMode');
  await patchStyle(activeStyleTag,{required:$('#styleDetailRequired').checked,rnd:$('#styleDetailRnd').checked,category:value('#styleDetailCategory'),weight_mode:mode,weight:mode==='fixed'?num('#styleDetailWeight'):null,weight_min:mode==='range'?num('#styleDetailWeightMin'):null,weight_max:mode==='range'?num('#styleDetailWeightMax'):null});
}
async function deleteActiveStyle(){if(!activeStyleTag||!confirm(`"${activeStyleTag}" 태그를 Style Pool에서 삭제할까요?`))return;const tag=activeStyleTag;activeStyleTag=null;if(await styleRequest(`/api/styles/${encodeURIComponent(tag)}`,{method:'DELETE'},'태그를 삭제했습니다.'))closeDialog($('#styleSettingsDialog'))}

/* Artist Library: per-artist samples made with the Library's own settings (independent of the main screen). */
let libraryArtist=null;
let libraryCompletedSeen=-1;
let libraryState={settings:null,saved:false,settings_key:null};
let libraryJobId=null,libraryJobTimer=null,libraryJobSeen=-1;
const libraryKey=name=>String(name).replace(/^artist:/i,'').trim().toLocaleLowerCase();
function libraryEntry(name){return appState.artist_library?.artists?.[libraryKey(name)]||null}
function libraryCover(entry){if(!entry?.images?.length)return null;return entry.images.find(i=>i.image_id===entry.cover_image_id)||entry.images[entry.images.length-1]}
function hasCurrentSample(entry){const key=libraryState.settings_key;return !!(key&&entry?.images?.some(i=>i.settings_key===key))}
function applyLibraryState(state){libraryState={settings:state.settings,saved:state.saved,settings_key:state.settings_key};appState.artist_library=state.library;renderArtists()}
async function refreshLibrary(){try{applyLibraryState(await api('/api/library'));if($('#libraryDialog').open)renderLibrary()}catch(e){toast(e.message,true)}}

/* Library 설정 form */
function fillLibraryForm(s){
  const g=s.generation;$('#libPositive').value=s.positive_prompt;$('#libNegative').value=s.negative_prompt;$('#libModel').value=s.model;$('#libSeed').value=s.seed??'';
  $('#libWidth').value=g.width;$('#libHeight').value=g.height;$('#libSteps').value=g.steps;$('#libSampler').value=g.sampler;$('#libScheduler').value=g.scheduler;$('#libScale').value=g.scale;$('#libCfgRescale').value=g.cfg_rescale;
  $('#libArtistWeight').value=s.artist_weight;$('#libArtistPosition').value=s.artist_position;$('#libCharacter').value=s.character_prompt;
  syncLibraryResolution();updateLibrarySaveState();
}
function readLibraryForm(){
  return {positive_prompt:value('#libPositive'),negative_prompt:value('#libNegative'),model:value('#libModel'),seed:num('#libSeed',true),
    artist_weight:num('#libArtistWeight'),artist_position:value('#libArtistPosition'),character_prompt:value('#libCharacter'),
    generation:{width:num('#libWidth'),height:num('#libHeight'),steps:num('#libSteps'),sampler:value('#libSampler'),scheduler:value('#libScheduler'),scale:num('#libScale'),cfg_rescale:num('#libCfgRescale')}};
}
function libraryFormDirty(){const s=libraryState.settings;if(!s)return false;const {updated_at,...saved}=s;return JSON.stringify(readLibraryForm())!==JSON.stringify({positive_prompt:saved.positive_prompt,negative_prompt:saved.negative_prompt,model:saved.model,seed:saved.seed,artist_weight:saved.artist_weight,artist_position:saved.artist_position,character_prompt:saved.character_prompt,generation:{width:saved.generation.width,height:saved.generation.height,steps:saved.generation.steps,sampler:saved.generation.sampler,scheduler:saved.generation.scheduler,scale:saved.generation.scale,cfg_rescale:saved.generation.cfg_rescale}})}
function updateLibrarySaveState(){
  const node=$('#librarySaveState'),dirty=libraryFormDirty(),s=libraryState.settings;
  node.className=`library-save-state ${dirty?'dirty':libraryState.saved?'saved':''}`;
  node.textContent=dirty?'● 저장 안 된 변경':libraryState.saved?`✓ 저장됨 ${(s.updated_at||'').replace('T',' ').slice(5,16)}`:'기본값 (저장 전)';
  $('#librarySaveBtn').disabled=!dirty&&libraryState.saved;
  const f=readLibraryForm(),g=f.generation;
  $('#libraryDetailsSummary').textContent=`· Seed ${f.seed??'자동'} · ${g.width}×${g.height} · ${g.steps} steps · CFG ${g.scale} · weight ${f.artist_weight}`;
}
function syncLibraryResolution(){const d=`${value('#libWidth')}x${value('#libHeight')}`,p=$('#libResolution');p.value=[...p.options].some(o=>o.value===d)?d:'custom';updateLibraryResolutionFields()}
function applyLibraryResolution(){const p=value('#libResolution');if(p!=='custom'){const [w,h]=p.split('x');$('#libWidth').value=w;$('#libHeight').value=h}updateLibraryResolutionFields();updateLibrarySaveState()}
function updateLibraryResolutionFields(){const custom=value('#libResolution')==='custom';$$('#libWidth,#libHeight').forEach(n=>n.closest('label').classList.toggle('hidden',!custom))}
async function saveLibrarySettings(quiet=false){
  try{applyLibraryState(await api('/api/library/settings',{method:'PUT',body:JSON.stringify(readLibraryForm())}));fillLibraryForm(libraryState.settings);renderLibrary();if(!quiet)toast('Library 설정을 저장했습니다.');return true}
  catch(e){toast(e.message,true);return false}
}
async function resetWholeLibrary(){
  if(libraryJobId){toast('Library 생성이 끝난 뒤 초기화할 수 있습니다.',true);return}
  const images=Object.values(appState.artist_library?.artists||{}).reduce((sum,e)=>sum+e.images.length,0);
  if(!confirm(`모든 Artist Library 이미지(${images}장)와 Library 설정(Seed 포함)이 삭제됩니다.\nArtist Pool은 삭제되지 않습니다.\n\n계속하시겠습니까?`))return;
  try{
    const state=await api('/api/library',{method:'DELETE',body:JSON.stringify({confirm:true})});
    libraryArtist=null;libraryViewer=null;$('#libraryViewer').classList.add('hidden');$('#libraryJobStatus').classList.add('hidden');
    applyLibraryState(state);fillLibraryForm(libraryState.settings);renderLibrary();
    toast(`Library를 초기화했습니다 (이미지 ${state.removed.images}장 삭제).`);
  }catch(e){toast(e.message,true)}
}

/* Library view. Library targets = every Artist Pool artist; ☑ / 🚫 / 📌 never hide or skip an artist here. */
let libraryViewer=null; // {name, imageId}
function libraryNames(){
  const pool=appState.artists.map(a=>a.name),seen=new Set(pool.map(libraryKey));
  const extra=Object.values(appState.artist_library?.artists||{}).map(e=>e.name).filter(n=>!seen.has(libraryKey(n)));
  return [...pool,...extra];
}
function poolArtist(name){return appState.artists.find(a=>libraryKey(a.name)===libraryKey(name))||null}
function poolArtistsWithoutCurrentSample(){return appState.artists.filter(a=>!hasCurrentSample(libraryEntry(a.name))).map(a=>a.name)}
function artistStateButtons(name){
  const a=poolArtist(name);if(!a)return '<span class="muted library-outside">Pool 밖 (기록만 보관)</span>';
  // Same data-artist / data-field toggles as the Artist Pool rows: one artist record, always in sync.
  return `<span class="library-states"><button type="button" class="icon-toggle ${a.enabled?'on':''}" data-artist="${esc(a.name)}" data-field="enabled" title="사용 (랜덤 믹스·생성 후보). Library 표시·생성과는 무관">${a.enabled?'☑':'☐'}</button><button type="button" class="icon-toggle pin ${a.fixed_include?'on':''}" data-artist="${esc(a.name)}" data-field="fixed_include" title="모든 Combo에 고정 포함">📌</button><button type="button" class="icon-toggle ${a.favorite?'on':''}" data-artist="${esc(a.name)}" data-field="favorite" title="즐겨찾기">★</button><button type="button" class="icon-toggle exclude-toggle ${a.excluded?'on':''}" data-artist="${esc(a.name)}" data-field="excluded" title="🚫 강제 제외 (랜덤 믹스·전체 모드). Library와는 무관">🚫</button><button type="button" class="icon-toggle" data-open-artist="${esc(a.name)}" title="세부 설정">⋯</button></span>`;
}
function renderLibraryGrid(){
  const query=value('#librarySearch').trim().toLocaleLowerCase(),missingOnly=$('#libraryMissingOnly').checked;
  const names=libraryNames().filter(n=>n.toLocaleLowerCase().includes(query)).filter(n=>!missingOnly||!hasCurrentSample(libraryEntry(n)));
  $('#libraryGrid').innerHTML=names.map(name=>{const entry=libraryEntry(name),cover=libraryCover(entry),count=entry?.images.length||0,current=hasCurrentSample(entry),inPool=!!poolArtist(name);
    return `<div class="library-card ${current?'current':''} ${poolArtist(name)?.enabled===false?'unchecked':''}">
      <button type="button" class="library-card-image" data-library-open="${esc(name)}" ${count?'':'disabled'} title="${count===1?'크게 보기':count>1?`${count}장 보기`:'샘플 없음'}">${cover?`<img src="${esc(cover.image_url)}" alt="${esc(name)}" loading="lazy">`:'<span class="library-empty">샘플 없음</span>'}${count>1?`<span class="library-count">${count}장</span>`:''}</button>
      <div class="library-card-body"><div class="library-card-title"><span class="library-card-name" title="${esc(name)}">${esc(name)}</span><span class="library-card-meta">${count}장${current?' · 현재 설정 ✓':''}</span></div>
      <div class="library-card-actions">${artistStateButtons(name)}${inPool?`<button type="button" class="mini library-add" data-library-generate="${esc(name)}" ${libraryJobId?'disabled':''}>샘플 추가</button>`:''}</div></div></div>`}).join('')||'<div class="empty">조건에 맞는 작가가 없습니다.</div>';
  const all=appState.artists.length,missing=poolArtistsWithoutCurrentSample().length;
  $('#libraryGenerateAllBtn').disabled=!all||!!libraryJobId;$('#libraryGenerateAllBtn').textContent=`전체 Artist Pool 새 샘플 생성 (${all}명)`;
  $('#libraryGenerateMissingBtn').disabled=!missing||!!libraryJobId;$('#libraryGenerateMissingBtn').textContent=missing?`현재 설정 샘플 없는 작가만 생성 (${missing}명)`:'모든 작가에 현재 설정 샘플 있음';
}
function renderLibraryDetail(){
  const name=libraryArtist,entry=libraryEntry(name),key=libraryState.settings_key,cover=libraryCover(entry);
  $('#libraryArtistName').textContent=name;
  $('#libraryArtistMeta').innerHTML=`${entry?`샘플 ${entry.images.length}장 · ${hasCurrentSample(entry)?'현재 설정 샘플 있음':'현재 설정 샘플 없음'}`:'아직 샘플이 없습니다.'} ${artistStateButtons(name)}`;
  $('#libraryGenerateOneBtn').disabled=!!libraryJobId||!poolArtist(name);
  $('#librarySamples').innerHTML=(entry?.images||[]).slice().reverse().map(img=>`<button type="button" class="library-sample ${cover?.image_id===img.image_id?'cover':''}" data-library-view="${esc(img.image_id)}"><img src="${esc(img.image_url)}" alt="${esc(name)} 샘플" loading="lazy"><span class="library-sample-caption">${img.settings_key===key?'<b class="badge-current">현재 설정</b>':'<b class="badge-old">이전 설정</b>'} Seed ${esc(img.seed??'')}${cover?.image_id===img.image_id&&entry.cover_image_id?' · ★ 대표':''}</span></button>`).join('')||'<div class="empty">"샘플 생성"을 누르면 왼쪽 Library 설정으로 이 작가의 샘플을 만듭니다.</div>';
}
function renderLibrary(){
  if(libraryArtist&&(libraryEntry(libraryArtist)?.images.length||0)<2)libraryArtist=null; // a gallery only exists for 2+ images
  if(libraryArtist){$('#libraryOverview').classList.add('hidden');$('#libraryDetail').classList.remove('hidden');renderLibraryDetail()}else{$('#libraryDetail').classList.add('hidden');$('#libraryOverview').classList.remove('hidden');renderLibraryGrid()}
  if(libraryViewer)renderLibraryViewer();
}
/* 0장: nothing to open · 1장: straight to the viewer · 2장+: the artist's gallery */
function openLibraryArtist(name){
  const images=libraryEntry(name)?.images||[];
  if(images.length===1){openLibraryViewer(name,images[0].image_id);return}
  libraryArtist=images.length>1?name:null;renderLibrary();
  if(!images.length)$(`[data-library-generate="${CSS.escape(name)}"]`)?.focus();
}
async function openLibrary(artist=null){
  libraryArtist=null;libraryViewer=null;$('#libraryViewer').classList.add('hidden');openDialog($('#libraryDialog'));
  try{applyLibraryState(await api('/api/library'));fillLibraryForm(libraryState.settings)}catch(e){toast(e.message,true)}
  if(artist)openLibraryArtist(artist);else renderLibrary();
}

/* Full view: big image + the settings it was made with; ◀ ▶ within the same artist. */
function openLibraryViewer(name,imageId){libraryViewer={name,imageId};renderLibraryViewer()}
function closeLibraryViewer(){libraryViewer=null;$('#libraryViewer').classList.add('hidden');renderLibrary()}
function renderLibraryViewer(){
  const entry=libraryEntry(libraryViewer.name),images=(entry?.images||[]).slice().reverse(),index=images.findIndex(i=>i.image_id===libraryViewer.imageId);
  if(index<0){closeLibraryViewer();return}
  const img=images[index],s=img.settings||{},g=s.generation||{},isCover=libraryCover(entry)?.image_id===img.image_id&&entry.cover_image_id;
  $('#libraryViewer').classList.remove('hidden');
  $('#libraryViewerImage').src=img.image_url;
  $('#libraryViewerInfo').innerHTML=`<h3>${esc(entry.name)} <small class="muted">${index+1} / ${images.length}</small></h3>
    <p>${img.settings_key===libraryState.settings_key?'<b class="badge-current">현재 설정으로 생성</b>':'<b class="badge-old">이전 설정으로 생성</b>'}</p>
    <dl><dt>모델</dt><dd>${esc(img.model??'')}</dd><dt>Seed</dt><dd>${esc(img.seed??'')}</dd><dt>생성</dt><dd>${esc((img.created_at||'').replace('T',' '))}</dd>
    ${g.width?`<dt>설정</dt><dd>${esc(`${g.width}×${g.height} · ${g.steps} steps · ${g.sampler} / ${g.scheduler} · CFG ${g.scale}`)}</dd>`:''}
    <dt>Positive</dt><dd class="viewer-prompt">${esc(s.positive_prompt||'(비어 있음)')}</dd><dt>Negative</dt><dd class="viewer-prompt">${esc(s.negative_prompt||'(비어 있음)')}</dd></dl>
    <div class="library-viewer-actions">${isCover?'<b>★ 대표 이미지</b>':`<button class="mini" data-library-cover="${esc(img.image_id)}">대표로 지정</button>`}<button class="mini" data-library-delete="${esc(img.image_id)}">삭제</button></div>`;
  $('#libraryViewerPrev').classList.toggle('hidden',images.length<2);$('#libraryViewerNext').classList.toggle('hidden',images.length<2);
  libraryViewer.order=images.map(i=>i.image_id);libraryViewer.index=index;
}
function stepLibraryViewer(delta){if(!libraryViewer?.order)return;const n=libraryViewer.order.length;libraryViewer.imageId=libraryViewer.order[(libraryViewer.index+delta+n)%n];renderLibraryViewer()}

/* Generation runs and reports inside the Library dialog. */
async function generateLibrary(target,names=[]){
  if(libraryJobId)return;
  const count=target==='all'?appState.artists.length:target==='missing'?poolArtistsWithoutCurrentSample().length:names.length;
  if(!count)return;
  const dirty=libraryFormDirty(),f=readLibraryForm(),what=target==='all'?`Artist Pool 전체 ${count}명 (체크·🚫 여부와 관계없이, 기존 샘플이 있어도 1장씩 추가)`:target==='missing'?`현재 설정 샘플이 없는 작가 ${count}명`:`${names.join(', ')}`;
  if(!confirm(`${what}의 샘플을 Library 설정으로 생성합니다.${dirty?'\n변경된 Library 설정을 먼저 저장합니다.':''}${f.seed===null?'\nSeed가 비어 있어 이번에 랜덤 Seed를 정해 저장합니다.':''}\n\nNovelAI API 요청을 시작할까요?`))return;
  if((dirty||!libraryState.saved)&&!await saveLibrarySettings(true))return;
  try{
    const result=await api('/api/library/generate',{method:'POST',body:JSON.stringify({target,artist_names:names})});
    applyLibraryState(result);fillLibraryForm(libraryState.settings);
    libraryJobId=result.job.job_id;libraryJobSeen=-1;renderLibrary();pollLibraryJob();
  }catch(e){toast(e.message,true)}
}
async function pollLibraryJob(){
  clearTimeout(libraryJobTimer);if(!libraryJobId)return;
  try{
    const job=await api(`/api/jobs/${libraryJobId}`),s=job.summary,done=['completed','completed_with_errors','cancelled'].includes(job.status);
    const current=job.items.find(i=>i.status==='generating'),failed=job.items.filter(i=>i.status==='failed');
    const node=$('#libraryJobStatus');node.classList.remove('hidden');node.classList.toggle('error',!!failed.length);
    const label=done?'생성 완료':{paused:'일시정지됨 (최근 기록에서 재개·중지)',pausing:'일시정지 중',stopping:'중지 중'}[job.status]||'생성 중';
    node.innerHTML=`<strong>${label}</strong> ${s.completed}/${s.total}${current?` · ${esc(current.label)}`:''}${failed.length?` · 실패 ${failed.length}: ${esc(failed[0].error||'')}`:''}<div class="progress-track"><div style="width:${s.total?(s.completed+s.failed+s.cancelled)/s.total*100:0}%"></div></div>`;
    if(s.completed!==libraryJobSeen){libraryJobSeen=s.completed;await refreshLibrary()}
    if(done){libraryJobId=null;renderLibrary();toast(failed.length?`Library 생성 완료 · 실패 ${failed.length}건`:'Library 샘플을 저장했습니다.',!!failed.length);setTimeout(()=>{if(!libraryJobId)node.classList.add('hidden')},failed.length?8000:3000);return}
  }catch(e){toast(e.message,true)}
  libraryJobTimer=setTimeout(pollLibraryJob,1000);
}
async function libraryImageAction(kind,imageId){
  const name=libraryViewer?.name||libraryArtist;if(!name)return;
  try{
    if(kind==='delete'&&!confirm('이 샘플을 Library에서 삭제할까요? (Library 사본만 지워지고, 원래 생성 결과 폴더의 파일은 남습니다)'))return;
    const state=kind==='cover'
      ?await api(`/api/library/artists/${encodeURIComponent(name)}/cover`,{method:'PUT',body:JSON.stringify({image_id:imageId})})
      :await api(`/api/library/artists/${encodeURIComponent(name)}/images/${encodeURIComponent(imageId)}`,{method:'DELETE'});
    if(kind==='delete'&&libraryViewer){const rest=(state.library.artists[libraryKey(name)]?.images||[]).slice().reverse();if(rest.length)libraryViewer.imageId=rest[Math.min(libraryViewer.index,rest.length-1)].image_id;else libraryViewer=null}
    applyLibraryState(state);if(!libraryViewer)$('#libraryViewer').classList.add('hidden');renderLibrary();
  }catch(e){toast(e.message,true)}
}

async function init() {
  try {
    appState=await api('/api/state'); fillSettings(appState.settings); preview=appState.preview;
    $('#rememberToken').checked=appState.token_remembered;
    $('#tokenState').textContent=appState.token_remembered?'저장됨':'미입력'; $('#tokenState').classList.toggle('ok',appState.token_remembered);setTokenCompact(appState.token_remembered?'저장됨':null);
    restorePromptPreviewOpen();
    renderArtists(); renderStyles(); renderSaved(); renderRecent(); if(preview) renderPreview(); $('#singleCustomSelection').classList.add('show'); updateEstimates(); await detectPromptArtists(); await refreshBlockSample();
    const recent=appState.jobs?.[0]; if(recent&&!['completed','completed_with_errors','cancelled'].includes(recent.status))openJob(await api(`/api/jobs/${recent.job_id}`));
  } catch(e) { toast(e.message,true); }
}

function renderArtists() {
  const query=value('#artistSearch').trim().toLocaleLowerCase();
  const filtered=appState.artists.filter(a=>a.name.toLocaleLowerCase().includes(query));
  $('#poolCount').textContent=`${appState.artists.length}명`;
  $('#artistList').innerHTML=filtered.map(a=>`<div class="artist-row ${a.enabled?'':'off'}">
    <input type="checkbox" ${a.enabled?'checked':''} data-enabled-artist="${esc(a.name)}" title="체크된 작가는 생성 및 랜덤 믹스 후보에 포함됩니다.">
    <button class="artist-name icon-toggle" data-open-artist="${esc(a.name)}">${esc(a.name)}${a.fixed_include?' <span class="artist-flag" title="모든 Combo에 고정 포함">📌</span>':''}${a.excluded?' <span class="artist-flag" title="강제 제외">🚫</span>':''}</button>
    <button class="icon-toggle ${a.favorite?'on':''}" data-artist="${esc(a.name)}" data-field="favorite" title="즐겨찾기">★</button>
    <button class="icon-toggle artist-settings" data-open-artist="${esc(a.name)}" title="weight · 고정 포함 · 제외 · Library · 삭제">⋯</button></div>`).join('') || '<div class="empty">조건에 맞는 Artist가 없습니다.</div>';
  updateEstimates();
  if($('#libraryDialog').open)renderLibrary();
}
async function addArtists(text) {
  try { appState.artists=await api('/api/artists/add',{method:'POST',body:JSON.stringify({text})});renderArtists();toast('Artist를 추가했습니다.'); }
  catch(e){toast(e.message,true)}
}
async function patchArtist(name,field,current) {
  return patchArtistValues(name,{[field]:!current});
}
async function patchArtistValues(name,changes) {
  try { appState.artists=await api(`/api/artists/${encodeURIComponent(name)}`,{method:'PATCH',body:JSON.stringify(changes)});renderArtists();return true; }
  catch(e){toast(e.message,true)}
  return false;
}

async function bulkArtistAction(action) {
  try{appState.artists=await api('/api/artists/bulk',{method:'POST',body:JSON.stringify({action,names:[]})});renderArtists();toast('Artist Pool에 자동 저장했습니다.')}catch(e){toast(e.message,true)}
}

function openArtistSettings(name) {
  const artist=appState.artists.find(a=>a.name===name);if(!artist)return;
  activeArtistSettings=name;$('#artistSettingsName').textContent=name;$('#detailFixedInclude').checked=artist.fixed_include;$('#detailExcluded').checked=artist.excluded;$('#detailWeightMode').value=artist.weight_mode||'global';$('#detailFixedWeight').value=artist.fixed_weight??1.0;$('#detailWeightMin').value=artist.weight_min??0.2;$('#detailWeightMax').value=artist.weight_max??1.2;updateRuleFields();openDialog($('#artistSettingsDialog'));
}
function updateRuleFields(){const mode=value('#detailWeightMode');$('#fixedWeightFields').classList.toggle('hidden',mode!=='fixed');$('#rangeWeightFields').classList.toggle('hidden',mode!=='range')}
async function saveArtistSettings(closeAfterSave=true){
  const mode=value('#detailWeightMode');const changes={fixed_include:$('#detailFixedInclude').checked,excluded:$('#detailExcluded').checked,weight_mode:mode,fixed_weight:mode==='fixed'?num('#detailFixedWeight'):null,weight_min:mode==='range'?num('#detailWeightMin'):null,weight_max:mode==='range'?num('#detailWeightMax'):null};
  if(await patchArtistValues(activeArtistSettings,changes)){if(closeAfterSave){closeDialog($('#artistSettingsDialog'));toast('Artist 규칙을 저장했습니다.')}}
}
async function deleteActiveArtist(){
  if(!activeArtistSettings||!confirm(`${activeArtistSettings} 작가를 Artist Pool에서 삭제할까요?\n기존 생성 이미지와 기록은 유지됩니다.`))return;
  try{appState.artists=await api(`/api/artists/${encodeURIComponent(activeArtistSettings)}`,{method:'DELETE'});closeDialog($('#artistSettingsDialog'));activeArtistSettings=null;renderArtists();toast('Artist Pool에서 삭제했습니다.')}catch(e){toast(e.message,true)}
}

async function detectArtistsForAdd() {
  const text=value('#addArtistsText').trim(),result=$('#addArtistsDetected'),button=$('#confirmAddArtistsBtn');
  if(!text){detectedAddArtists=[];selectedDetectedAddArtists.clear();result.textContent='붙여넣으면 자동으로 인식합니다.';button.disabled=true;button.textContent='인식된 작가 추가';return}
  try{
    const response=await api('/api/artists/detect',{method:'POST',body:JSON.stringify({text})});detectedAddArtists=response.artists;
    selectedDetectedAddArtists=new Set(detectedAddArtists);renderDetectedAddArtists();
  }catch(e){detectedAddArtists=[];selectedDetectedAddArtists.clear();button.disabled=true;result.textContent=e.message;toast(e.message,true)}
}
function scheduleAddArtistDetection(){clearTimeout(scheduleAddArtistDetection.timer);scheduleAddArtistDetection.timer=setTimeout(detectArtistsForAdd,180)}
function renderDetectedAddArtists(){
  const selected=detectedAddArtists.filter(name=>selectedDetectedAddArtists.has(name));
  $('#addArtistsDetected').innerHTML=detectedAddArtists.length?`<strong>${detectedAddArtists.length}명 자동 인식 · ${selected.length}명 포함</strong><small class="detect-hint">이름을 눌러 포함/배제</small><div>${detectedAddArtists.map(name=>`<button type="button" class="auto-detect-chip ${selectedDetectedAddArtists.has(name)?'on':'off'}" data-toggle-add-artist="${esc(name)}">${esc(name)}</button>`).join('')}</div>`:'인식된 artist tag 또는 이름이 없습니다.';
  $('#confirmAddArtistsBtn').disabled=!selected.length;$('#confirmAddArtistsBtn').textContent=selected.length?`${selected.length}명 추가`:'인식된 작가 추가';
}
function toggleDetectedAddArtist(name){selectedDetectedAddArtists.has(name)?selectedDetectedAddArtists.delete(name):selectedDetectedAddArtists.add(name);renderDetectedAddArtists()}

let pendingImageArtists=[];
function customTextArtists(){return new Set(detectedCustomArtists.map(n=>n.toLocaleLowerCase()))}
function showImageImportResult(html,kind=''){const node=$('#singleImageImportResult');node.className=`image-import-result ${kind}`;node.innerHTML=html}
async function importArtistsFromImage(file){
  if(!file)return;
  showImageImportResult(`<span class="muted">${esc(file.name)} 읽는 중…</span>`);
  try{
    // Raw bytes to the local app only; nothing is uploaded elsewhere or added to the Artist Pool.
    const response=await fetch('/api/metadata/artists',{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:await file.arrayBuffer()});
    const result=await response.json();
    if(result.status!=='ok'){showImageImportResult(esc(result.message||'이미지 메타데이터를 읽지 못했습니다.'),'warn');return}
    pendingImageArtists=result.artists;
    const names=`<span class="image-import-names">${result.artists.map(n=>`<span class="auto-detect-chip on">${esc(n)}</span>`).join('')}</span>`;
    if(!value('#singleCustomText').trim()){applyImageArtists('replace');showImageImportResult(`<strong>${esc(result.message)}</strong> 직접 입력에 넣었습니다.${names}`,'ok');return}
    showImageImportResult(`<strong>${esc(result.message)}</strong>${names}<span class="image-import-choice">기존 입력이 있습니다: <button class="mini" type="button" data-image-import="append">기존 내용에 추가</button><button class="mini" type="button" data-image-import="replace">추출 결과로 교체</button><button class="mini" type="button" data-image-import="cancel">취소</button></span>`,'ok');
  }catch(e){showImageImportResult('이미지 메타데이터를 읽지 못했습니다.','warn')}
}
function applyImageArtists(mode){
  if(mode==='cancel'){pendingImageArtists=[];$('#singleImageImportResult').classList.add('hidden');return}
  const area=$('#singleCustomText'),known=customTextArtists();
  const added=mode==='append'?pendingImageArtists.filter(n=>!known.has(n.toLocaleLowerCase())):pendingImageArtists;
  area.value=mode==='append'?[area.value.replace(/\s+$/,''),...added].filter(Boolean).join('\n'):added.join('\n');
  showImageImportResult(mode==='append'?`${added.length}명을 추가했습니다${pendingImageArtists.length>added.length?` (이미 있던 ${pendingImageArtists.length-added.length}명 제외)`:''}.`:`추출 결과 ${added.length}명으로 바꿨습니다.`,'ok');
  pendingImageArtists=[];detectCustomArtists();
}
function openSingleCustomDialog(){
  $('#singleImageImportResult').classList.add('hidden');pendingImageArtists=[];
  $('#singleCustomText').value=customSingleArtists.join(', ');detectedCustomArtists=[...customSingleArtists];selectedDetectedCustomArtists=new Set(customSingleArtists);renderDetectedCustomArtists();openDialog($('#singleCustomDialog'));$('#singleCustomText').focus();
}
async function detectCustomArtists(){
  const text=value('#singleCustomText').trim(),result=$('#singleCustomDetected');
  if(!text){detectedCustomArtists=[];selectedDetectedCustomArtists.clear();renderDetectedCustomArtists();return}
  try{const response=await api('/api/artists/detect',{method:'POST',body:JSON.stringify({text})});detectedCustomArtists=response.artists;selectedDetectedCustomArtists=new Set(detectedCustomArtists);renderDetectedCustomArtists()}
  catch(e){detectedCustomArtists=[];selectedDetectedCustomArtists.clear();result.textContent=e.message;$('#confirmSingleCustomBtn').disabled=true;toast(e.message,true)}
}
function scheduleCustomArtistDetection(){clearTimeout(scheduleCustomArtistDetection.timer);scheduleCustomArtistDetection.timer=setTimeout(detectCustomArtists,180)}
function renderDetectedCustomArtists(){
  const selected=detectedCustomArtists.filter(name=>selectedDetectedCustomArtists.has(name));
  $('#singleCustomDetected').innerHTML=detectedCustomArtists.length?`<strong>${detectedCustomArtists.length}명 자동 인식 · ${selected.length}명 포함</strong><small class="detect-hint">이름을 눌러 포함/배제</small><div>${detectedCustomArtists.map(name=>`<button type="button" class="auto-detect-chip ${selectedDetectedCustomArtists.has(name)?'on':'off'}" data-toggle-custom-artist="${esc(name)}">${esc(name)}</button>`).join('')}</div>`:'붙여넣으면 자동으로 인식합니다.';
  $('#confirmSingleCustomBtn').disabled=!selected.length;
}
function toggleDetectedCustomArtist(name){selectedDetectedCustomArtists.has(name)?selectedDetectedCustomArtists.delete(name):selectedDetectedCustomArtists.add(name);renderDetectedCustomArtists()}
function applyCustomArtists(){
  customSingleArtists=detectedCustomArtists.filter(name=>selectedDetectedCustomArtists.has(name));
  $('#singleCustomSummary').textContent=customSingleArtists.length?`${customSingleArtists.length}명 · Artist Pool에 저장되지 않음`:'직접 입력한 작가가 없습니다.';
  $('#singleCustomArtists').innerHTML=customSingleArtists.map(name=>`<span class="auto-detect-chip on">${esc(name)}</span>`).join('');closeDialog($('#singleCustomDialog'));updateEstimates();
}

function updatePlaceholderWarning() {
  const s=blockSettings(),where=v=>v==='append'?'맨 뒤':'맨 앞',notes=[];
  const artists=promptItems.filter(item=>item.type==='artist').length,styles=promptItems.filter(item=>item.type==='style').length;
  if(s.artist_block_enabled)notes.push(artists>1?`Artist Block ${artists}개 · 모두 같은 조합`:artists===0?`Artist Block 없음 → ${where(value('#fallback'))}에 자동 추가`:'');
  if(s.style_block_enabled)notes.push(styles>1?`Style Block ${styles}개 · 모두 같은 태그`:styles===0?`Style Block 없음 → ${where(s.style_fallback)}에 자동 추가`:'');
  $('#placeholderWarning').textContent=notes.filter(Boolean).join(' · ');
}
async function detectPromptArtists() {
  try{
    detectedPrompt=await api('/api/prompt/detect',{method:'POST',body:JSON.stringify({prompt:value('#positivePrompt')})});
    const panel=$('#detectedPanel'),artists=detectedPrompt.artists;
    panel.classList.toggle('hidden',!artists.length);$('#detectedCount').textContent=`감지된 Artist: ${artists.length}명`;
    $('#detectedArtists').innerHTML=artists.map(a=>`<span class="auto-detect-chip on">${esc(a.name)}${a.weight!==null?` <small>(${a.weight})</small>`:''}</span>`).join('');
    $('#detectedBasePrompt').textContent=detectedPrompt.base_prompt;updateEstimates();
  }catch(e){toast(e.message,true)}
}
function schedulePromptDetection(){updatePlaceholderWarning();schedulePromptPreview();clearTimeout(schedulePromptDetection.timer);schedulePromptDetection.timer=setTimeout(detectPromptArtists,250)}
function activeArtistCount(mode) {
  if(mode==='custom') return customSingleArtists.length;
  return appState.artists.filter(a=>!a.excluded&&(mode==='all'||a.enabled)).length;
}
function updateEstimates() {
  const singles=activeArtistCount(value('#singleTarget'))*num('#singleImages'); $('#singleEstimate').textContent=`${activeArtistCount(value('#singleTarget'))}명 · 총 ${singles}장 생성 예정`;
  const combos=num('#comboCount'), images=num('#imagesPerCombo'); $('#mixEstimate').textContent=`${combos}개 조합 · 조합당 ${images}장 · 총 ${combos*images}장`;
}

function previewRequest(keepSeed=false) {
  return {min_artists:num('#minArtists'),max_artists:num('#maxArtists'),weight_min:num('#weightMin'),weight_max:num('#weightMax'),decimals:num('#weightDecimals'),combo_count:num('#comboCount'),images_per_combo:num('#imagesPerCombo'),mix_seed:keepSeed?num('#mixSeed',true):num('#mixSeed',true),seed_mode:value('#mixSeedMode'),base_seed:num('#mixBaseSeed',true),pool_mode:value('#mixPoolMode'),
    artist_block_enabled:$('#artistBlockEnabled').checked,style_block_enabled:$('#styleBlockEnabled').checked};
}
async function makePreview(forceNew=false) {
  try {
    const body=previewRequest(); if(forceNew) body.mix_seed=null;
    preview=await api('/api/preview/mix',{method:'POST',body:JSON.stringify(body)}); $('#mixSeed').value=preview.mix_seed;renderPreview();refreshBlockSample();toast('조합이 확정되었습니다.');
  }catch(e){toast(e.message,true)}
}
function renderPreview() {
  if(!preview)return; $('#previewSection').classList.remove('hidden');setPreviewCollapsed(false);$('#startMixBtn').disabled=false;$('#previewSeed').textContent=`Mix Seed ${preview.mix_seed}`;
  $('#comboPreview').innerHTML=preview.combos.map(c=>`<article class="combo-card"><h3>Combo ${String(c.combo_id).padStart(3,'0')} <span class="pill">${c.artists.length} artists</span>${c.style_tags?.length?` <span class="pill style-pill">${c.style_tags.length} styles</span>`:''}</h3>${c.artists.length?`<ul>${c.artists.map(a=>`<li><span>${esc(a.name)} ${a.fixed_include?'📌':''}<small class="combo-rule">${a.weight_mode}</small></span><strong>${a.weight.toFixed(preview.settings.decimals)}</strong></li>`).join('')}</ul><p class="mix-code">${esc(c.artist_mix)}</p>`:'<p class="muted">Artist Block 꺼짐</p>'}${c.style_block?`<p class="mix-code style-code">${esc(c.style_block)}</p>`:''}<small class="muted">Seeds: ${c.seeds.join(', ')}</small></article>`).join('');
}
function setPreviewCollapsed(collapsed){$('#comboPreview').classList.toggle('hidden',collapsed);$('#togglePreviewBtn').textContent=collapsed?'펼치기':'접기';$('#togglePreviewBtn').setAttribute('aria-expanded',String(!collapsed))}

function setTokenCompact(state){$('#tokenPanel').classList.toggle('compact',!!state);if(state)$('#tokenCompactState').textContent=state}
function restorePromptPreviewOpen(){try{$('#promptPreviewSection').open=localStorage.getItem('artistLab.promptPreviewOpen')==='1'}catch{}}
async function saveCommonSettings() { await api('/api/settings',{method:'PUT',body:JSON.stringify(settingsPayload())}); }
async function startSingle() {
  const mode=value('#singleTarget');const names=mode==='custom'?[...customSingleArtists]:[], count=activeArtistCount(mode), images=num('#singleImages');
  if(!count){toast('테스트할 artist를 선택해 주세요.',true);return}
  if(!confirm(`작가 ${count}명 × ${images}장 = 총 ${count*images}장을 생성합니다.\nNovelAI API 요청을 시작할까요?`))return;
  try {await saveCommonSettings();const body={settings:settingsPayload(),target_mode:value('#singleTarget'),selected_names:names,images_per_artist:images,artist_weight:num('#singleWeight'),weight_decimals:1,seed_mode:value('#singleSeedMode'),base_seed:num('#singleBaseSeed',true)};const job=await api('/api/jobs/single',{method:'POST',body:JSON.stringify(body)});openJob(job,'single');toast('단일 작가 테스트를 시작했습니다.')}catch(e){toast(e.message,true)}
}
async function startMix() {
  if(!preview){toast('먼저 조합 미리보기를 만들어 주세요.',true);return}
  const n=preview.total_images;if(!confirm(`조합 ${preview.combos.length}개 × 조합당 ${preview.settings.images_per_combo}장 = 총 ${n}장을 생성합니다.\n미리 확정된 조합으로 NovelAI API 요청을 시작할까요?`))return;
  try {await saveCommonSettings();const job=await api('/api/jobs/mix',{method:'POST',body:JSON.stringify({preview_id:preview.preview_id,settings:settingsPayload()})});openJob(job,'mix');toast('랜덤 믹스 생성을 시작했습니다.')}catch(e){toast(e.message,true)}
}
function activateTab(tabName){$$('.nav-btn').forEach(node=>node.classList.toggle('active',node.dataset.tab===tabName));$$('.tab-panel').forEach(node=>node.classList.toggle('active',node.id===`tab-${tabName}`))}
function defaultJobTab(job){return job.mode==='single_artist'||job.mode==='artist_library'?'single':job.mode==='saved_combo'?'saved':'mix'}
function openJob(job,hostTab=null){const tabName=hostTab||defaultJobTab(job),section=$('#jobSection');$(`#tab-${tabName}`).append(section);activateTab(tabName);activeJobId=job.job_id;section.classList.remove('hidden');renderJob(job);section.scrollIntoView({behavior:'smooth'});if(!['completed','completed_with_errors','cancelled'].includes(job.status))schedulePoll()}
function schedulePoll(){clearTimeout(pollTimer);if(activeJobId)pollTimer=setTimeout(pollJob,1000)}
async function pollJob(){if(!activeJobId)return;try{const job=await api(`/api/jobs/${activeJobId}`);$('#jobSection').classList.remove('hidden');renderJob(job);if(!['completed','completed_with_errors','cancelled'].includes(job.status))schedulePoll()}catch(e){toast(e.message,true)}}
const FINAL_JOB_STATUSES=['completed','completed_with_errors','cancelled'];
function jobOrder(a,b){return String(b.created_at||'').localeCompare(String(a.created_at||''))||(Number(b.created_ts)||0)-(Number(a.created_ts)||0)||String(b.job_id).localeCompare(String(a.job_id))}
function upsertRecentJob(job){
  // Same order as the server (created_at, created_ts, job_id); the newest 30 plus any unfinished job.
  const jobs=[job,...(appState.jobs||[]).filter(item=>item.job_id!==job.job_id)].sort(jobOrder);
  appState.jobs=[...jobs.slice(0,30),...jobs.slice(30).filter(item=>!FINAL_JOB_STATUSES.includes(item.status))];renderRecent();
}
function renderJob(job) {
  upsertRecentJob(job);
  if(job.mode==='artist_library'&&job.summary.completed!==libraryCompletedSeen){libraryCompletedSeen=job.summary.completed;refreshLibrary()}
  const s=job.summary, done=s.completed+s.failed+s.cancelled, pct=s.total?done/s.total*100:0;
  $('#jobTitle').textContent=job.mode==='single_artist'?'단일 작가 테스트':job.mode==='artist_library'?'Artist Library 생성':job.mode==='saved_combo'?'저장 조합 재생성':'랜덤 믹스 생성';$('#jobStatus').textContent=job.status;$('#progressBar').style.width=`${pct}%`;
  $('#progressText').textContent=`${s.completed} / ${s.total} 완료 · 실패 ${s.failed}`;const current=job.items.find(i=>i.status==='generating'),problem=job.persist_error||job.error||'';$('#currentText').textContent=problem||(current?`현재: ${current.label} · Seed ${current.seed}`:'');$('#currentText').classList.toggle('error-text',!!problem);
  $('#pauseBtn').disabled=!['running','pending'].includes(job.status);$('#resumeBtn').disabled=!['paused','pausing'].includes(job.status);$('#stopBtn').disabled=['completed','completed_with_errors','cancelled'].includes(job.status);$('#retryBtn').disabled=!s.failed;
  const isSingle=job.mode==='single_artist'||job.mode==='artist_library';$('#galleryViewToggle').classList.toggle('hidden',!isSingle);$('#gallery').className=`gallery-groups ${isSingle?galleryView:'detail'}`;
  $('#gallery').innerHTML=job.groups.map(group=>renderGroup(job,group)).join('');
}
function renderGroup(job,g) {
  const items=job.items.filter(i=>i.group_key===g.group_key); const comboMode=!['single_artist','artist_library'].includes(job.mode);
  const title=comboMode?`Combo ${String(g.combo_id).padStart(3,'0')}`:g.artist_name;
  const controls=comboMode?`${g.artist_mix?`<button class="mini" data-copy="${esc(g.artist_mix)}">Mix 복사</button>`:''}${g.style_block?`<button class="mini" data-copy="${esc(g.style_block)}">Style 복사</button>`:''}<button class="mini" data-save-combo="${g.combo_id}">★ 저장</button>`:`<button class="mini" data-result-artist="${esc(g.artist_name)}" data-result-field="favorite">★</button><button class="mini" data-result-artist="${esc(g.artist_name)}" data-result-field="enabled" title="Artist Pool에서 체크 (생성·랜덤 믹스 후보)">☑ 사용</button><button class="mini exclude" data-result-artist="${esc(g.artist_name)}" data-result-field="excluded">제외</button><button class="mini" data-open-library="${esc(g.artist_name)}" title="Artist Library 열기">📚</button>`;
  return `<article class="gallery-group"><div class="gallery-group-head"><div><h3>${esc(title)} <span class="pill">${items.filter(i=>i.status==='completed').length}/${items.length}</span></h3><div class="mix-code">${esc(g.artist_mix)}</div>${g.style_block?`<div class="mix-code style-code">${esc(g.style_block)}</div>`:''}</div><div>${controls}</div></div><div class="image-grid">${items.map(renderItem).join('')}</div></article>`;
}
function renderItem(i) {
  if(i.status==='completed')return `<div class="image-card"><img src="${esc(i.image_url)}" alt="${esc(i.label)}" data-large="${esc(i.image_url)}"><div class="image-meta"><span>Seed ${i.seed}</span><button class="mini" data-prompt-id="${esc(i.item_id)}">Prompt</button></div><script type="application/json" id="prompt-${esc(i.item_id)}">${JSON.stringify(i.final_prompt).replace(/</g,'\\u003c')}</script></div>`;
  return `<div class="image-card"><div class="placeholder-card ${i.status}"><div><strong>${esc(i.status)}</strong><br><small>Seed ${i.seed}</small>${i.error?`<br><small>${esc(i.error)}</small>`:''}</div></div></div>`;
}
async function jobAction(action){if(!activeJobId)return;try{const job=await api(`/api/jobs/${activeJobId}/${action}`,{method:'POST'});renderJob(job);schedulePoll()}catch(e){toast(e.message,true)}}

async function resultArtistAction(name,field){
  try{
    let artist=appState.artists.find(item=>item.name===name);
    if(!artist){appState.artists=await api('/api/artists/add',{method:'POST',body:JSON.stringify({text:name})});renderArtists();artist=appState.artists.find(item=>item.name===name);const desired=true;if(artist[field]!==desired&&!await patchArtistValues(name,{[field]:desired}))return;toast(field==='favorite'?'Artist Pool 즐겨찾기에 저장했습니다.':'Artist Pool에 저장했습니다.');return}
    await patchArtist(name,field,artist[field]);
  }catch(e){toast(e.message,true)}
}

function renderSaved() {
  const saved=appState.saved_combos||[];$('#savedCount').textContent=`${saved.length}개`;
  $('#savedList').innerHTML=saved.map(s=>`<article class="saved-card"><h3>★ ${esc(s.artists.map(a=>a.name).join(' + ')||'Style only')}</h3><div class="mix-code">${esc(s.artist_mix)}</div>${s.style_block?`<div class="mix-code style-code">${esc(s.style_block)}</div>`:''}<div class="saved-images">${s.images.slice(0,5).map(u=>`<img src="${esc(u)}" data-large="${esc(u)}">`).join('')}</div><small class="muted">Seeds: ${s.seeds.join(', ')}</small><div class="action-row"><button class="btn secondary" data-regen="${s.saved_id}">현재 Prompt로 생성</button><button class="btn ghost danger" data-delete-saved="${s.saved_id}">삭제</button></div></article>`).join('')||'<div class="empty">아직 저장한 조합이 없습니다.</div>';
}
function jobModeLabel(mode){return mode==='single_artist'?'단일 작가 테스트':mode==='artist_library'?'Artist Library 생성':mode==='saved_combo'?'저장 조합 재생성':'랜덤 믹스'}
function renderRecent(){
  const jobs=appState.jobs||[];$('#recentCount').textContent=`${jobs.length}개`;
  $('#recentList').innerHTML=jobs.map(job=>{const summary=job.summary||{},images=(job.items||[]).filter(item=>item.image_url).slice(0,4);return `<article class="recent-card"><div class="recent-card-head"><div><span class="status-chip">${esc(job.status)}</span><h3>${esc(jobModeLabel(job.mode))}</h3></div><button class="btn secondary" data-open-job="${esc(job.job_id)}">열기</button></div><small class="muted">${esc((job.created_at||'').replace('T',' '))} · ${summary.completed||0}/${summary.total||0} 완료 · 실패 ${summary.failed||0}</small><div class="recent-images">${images.map(item=>`<img src="${esc(item.image_url)}" data-large="${esc(item.image_url)}" alt="최근 생성 이미지">`).join('')}</div></article>`}).join('')||'<div class="empty">최근 생성 기록이 없습니다.</div>';
}
async function openRecentJob(jobId){try{openJob(await api(`/api/jobs/${encodeURIComponent(jobId)}`),'recent')}catch(e){toast(e.message,true)}}
async function saveCombo(comboId){try{await api('/api/saved-combos',{method:'POST',body:JSON.stringify({job_id:activeJobId,combo_id:Number(comboId)})});appState=(await api('/api/state'));renderSaved();toast('조합을 저장했습니다.')}catch(e){toast(e.message,true)}}
async function regenerate(id){if(!confirm('이 artist mix를 현재 Prompt에 적용해 1장 생성할까요?'))return;try{const job=await api(`/api/saved-combos/${id}/regenerate`,{method:'POST',body:JSON.stringify({settings:settingsPayload(),images:1,seed_mode:'random'})});openJob(job,'saved')}catch(e){toast(e.message,true)}}
async function deleteSaved(id){if(!confirm('저장된 조합 기록을 삭제할까요? 생성 이미지는 삭제하지 않습니다.'))return;try{await api(`/api/saved-combos/${id}`,{method:'DELETE'});appState.saved_combos=appState.saved_combos.filter(x=>x.saved_id!==id);renderSaved()}catch(e){toast(e.message,true)}}

document.addEventListener('click',async e=>{
  const t=e.target.closest('button,img');if(!t)return;
  if(t.matches('.nav-btn'))activateTab(t.dataset.tab);
  if(t.dataset.artist){const a=appState.artists.find(x=>x.name===t.dataset.artist);await patchArtist(a.name,t.dataset.field,a[t.dataset.field])}
  if(t.dataset.openArtist)openArtistSettings(t.dataset.openArtist);
  if(t.dataset.openLibrary){closeDialog($('#artistSettingsDialog'));openLibrary(t.dataset.openLibrary)}
  if(t.dataset.libraryOpen)openLibraryArtist(t.dataset.libraryOpen);
  if(t.dataset.libraryView)openLibraryViewer(libraryArtist,t.dataset.libraryView);
  if(t.dataset.libraryGenerate)await generateLibrary('names',[t.dataset.libraryGenerate]);
  if(t.dataset.libraryCover)await libraryImageAction('cover',t.dataset.libraryCover);
  if(t.dataset.libraryDelete)await libraryImageAction('delete',t.dataset.libraryDelete);
  if(t.dataset.bulk)await bulkArtistAction(t.dataset.bulk);
  if(t.dataset.resultArtist)await resultArtistAction(t.dataset.resultArtist,t.dataset.resultField);
  if(t.dataset.toggleAddArtist)toggleDetectedAddArtist(t.dataset.toggleAddArtist);
  if(t.dataset.toggleCustomArtist)toggleDetectedCustomArtist(t.dataset.toggleCustomArtist);
  if(t.hasAttribute('data-close-dialog'))closeDialog(t.closest('dialog'));
  if(t.dataset.large){$('#largeImage').src=t.dataset.large;openDialog($('#imageDialog'))}
  if(t.dataset.promptId){const node=$(`#prompt-${CSS.escape(t.dataset.promptId)}`);$('#promptText').textContent=JSON.parse(node.textContent);openDialog($('#promptDialog'))}
  if(t.dataset.copy){await navigator.clipboard.writeText(t.dataset.copy);toast('복사했습니다.')}
  if(t.dataset.addItem)addPromptItem(t.dataset.addItem);
  if(t.dataset.styleRnd){const s=stylePool().tags.find(x=>x.tag===t.dataset.styleRnd);if(s)await patchStyle(s.tag,{rnd:!s.rnd})}
  if(t.dataset.styleSettings)openStyleSettings(t.dataset.styleSettings);
  if(t.dataset.styleCatOpen){const id=t.dataset.styleCatOpen;openStyleCategories.has(id)?openStyleCategories.delete(id):openStyleCategories.add(id);renderStyles()}
  if(t.dataset.styleBulk)await styleBulk(t.dataset.styleBulk,t.dataset.styleBulkCat);
  if(t.dataset.saveCombo)await saveCombo(t.dataset.saveCombo);
  if(t.dataset.regen)await regenerate(t.dataset.regen);
  if(t.dataset.deleteSaved)await deleteSaved(t.dataset.deleteSaved);
  if(t.dataset.openJob)await openRecentJob(t.dataset.openJob);
  if(t.dataset.galleryView){galleryView=t.dataset.galleryView;$$('[data-gallery-view]').forEach(x=>x.classList.toggle('on',x.dataset.galleryView===galleryView));$('#gallery').className=`gallery-groups ${galleryView}`}
});
document.addEventListener('change',async e=>{
  const t=e.target;
  if(t.dataset.enabledArtist){const a=appState.artists.find(x=>x.name===t.dataset.enabledArtist);await patchArtistValues(a.name,{enabled:t.checked})}
  if(t.dataset.styleRequired)await patchStyle(t.dataset.styleRequired,{required:t.checked});
  if(t.dataset.styleCatEnabled)await patchStyleCategory(t.dataset.styleCatEnabled,{enabled:t.checked});
  if(t.dataset.styleCatMin||t.dataset.styleCatMax){const id=t.dataset.styleCatMin||t.dataset.styleCatMax,min=Number($(`[data-style-cat-min="${CSS.escape(id)}"]`).value),max=Number($(`[data-style-cat-max="${CSS.escape(id)}"]`).value);await patchStyleCategory(id,{rnd_min:min,rnd_max:Math.max(min,max)})}
});
$('#positivePrompt').addEventListener('input',schedulePromptDetection);
setupBlockEditor();
$('#openLibraryBtn').addEventListener('click',()=>openLibrary(null));
$('#libraryBackBtn').addEventListener('click',()=>{libraryArtist=null;renderLibrary()});
$('#libraryGenerateOneBtn').addEventListener('click',()=>generateLibrary('names',[libraryArtist]));
$('#libraryGenerateMissingBtn').addEventListener('click',()=>generateLibrary('missing'));$('#libraryGenerateAllBtn').addEventListener('click',()=>generateLibrary('all'));
$('#libraryViewerClose').addEventListener('click',closeLibraryViewer);$('#libraryViewerPrev').addEventListener('click',()=>stepLibraryViewer(-1));$('#libraryViewerNext').addEventListener('click',()=>stepLibraryViewer(1));
$('#libraryViewer').addEventListener('click',e=>{if(e.target===e.currentTarget)closeLibraryViewer()});
$('#libraryDialog').addEventListener('keydown',e=>{if(!libraryViewer)return;if(e.key==='ArrowLeft')stepLibraryViewer(-1);if(e.key==='ArrowRight')stepLibraryViewer(1)});
$('#librarySearch').addEventListener('input',renderLibraryGrid);$('#libraryMissingOnly').addEventListener('change',renderLibraryGrid);
$('#artistOpenLibraryBtn').addEventListener('click',()=>{const name=activeArtistSettings;closeDialog($('#artistSettingsDialog'));openLibrary(name)});
$('#librarySaveBtn').addEventListener('click',()=>saveLibrarySettings());$('#libraryResetBtn').addEventListener('click',resetWholeLibrary);
$('#librarySettingsForm').addEventListener('input',updateLibrarySaveState);$('#librarySettingsForm').addEventListener('change',updateLibrarySaveState);
$('#libResolution').addEventListener('change',applyLibraryResolution);$$('#libWidth,#libHeight').forEach(n=>n.addEventListener('input',syncLibraryResolution));
$('#libraryDialog').addEventListener('cancel',e=>{if(libraryViewer){e.preventDefault();closeLibraryViewer();return}if(libraryFormDirty()&&!confirm('저장하지 않은 Library 설정 변경이 있습니다. 닫을까요?'))e.preventDefault()});
$('#generationSection').addEventListener('input',updateGenerationSummary);$('#generationSection').addEventListener('change',updateGenerationSummary);
$('#promptPreviewSection').addEventListener('toggle',e=>{try{localStorage.setItem('artistLab.promptPreviewOpen',e.target.open?'1':'0')}catch{}});window.addEventListener('resize',autosizePromptRows);
$$('#fallback,#styleFallback').forEach(node=>node.addEventListener('change',()=>onBlockSettingsChange(false)));
$$('#artistBlockEnabled,#styleBlockEnabled').forEach(node=>node.addEventListener('change',()=>onBlockSettingsChange(true)));
$('#resampleBlocksBtn').addEventListener('click',()=>refreshBlockSample(false));
$('#styleAddInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing){e.preventDefault();addStyles(value('#styleAddInput'))}});
$('#editStylesBtn').addEventListener('click',openStyleEditor);$('#saveStylesBtn').addEventListener('click',saveStyleEditor);$('#styleEditCategory').addEventListener('change',fillStyleEditor);
$('#randomizeStyleDefaultsBtn').addEventListener('click',randomizeStyleDefaults);
$$('#styleWeightMin,#styleWeightMax,#styleWeightStep').forEach(node=>node.addEventListener('change',saveStyleWeightRange));
$('#styleDetailWeightMode').addEventListener('change',updateStyleWeightFields);
$$('#styleDetailRequired,#styleDetailRnd,#styleDetailCategory,#styleDetailWeightMode,#styleDetailWeight,#styleDetailWeightMin,#styleDetailWeightMax').forEach(node=>node.addEventListener('change',saveStyleSettings));
$('#doneStyleSettingsBtn').addEventListener('click',()=>closeDialog($('#styleSettingsDialog')));$('#deleteStyleBtn').addEventListener('click',deleteActiveStyle);
$('#styleSettingsDialog').addEventListener('close',()=>{activeStyleTag=null});
$('#artistSearch').addEventListener('input',renderArtists);
$('#resolutionPreset').addEventListener('change',applyResolutionPreset);$$('#width,#height').forEach(node=>node.addEventListener('input',syncResolutionPreset));$('#model').addEventListener('change',updateGenerationSummary);
$('#editTokenBtn').addEventListener('click',()=>{setTokenCompact(null);$('#token').focus()});
$('#addArtistsBtn').addEventListener('click',()=>{const source=detectedPrompt.artists.length?value('#positivePrompt'):'';$('#addArtistsText').value=source;detectedAddArtists=[];selectedDetectedAddArtists.clear();$('#addArtistsDetected').textContent=source?'현재 Positive Prompt를 분석하는 중입니다.':'붙여넣으면 자동으로 인식합니다.';$('#confirmAddArtistsBtn').disabled=true;$('#confirmAddArtistsBtn').textContent='인식된 작가 추가';openDialog($('#addArtistsDialog'));if(source)detectArtistsForAdd()});
$('#addArtistsText').addEventListener('input',scheduleAddArtistDetection);
$('#confirmAddArtistsBtn').addEventListener('click',async()=>{const selected=detectedAddArtists.filter(name=>selectedDetectedAddArtists.has(name));if(!selected.length)return;await addArtists(selected.join('\n'));closeDialog($('#addArtistsDialog'))});
$('#addDetectedBtn').addEventListener('click',async()=>addArtists(detectedPrompt.artists.map(a=>a.name).join('\n')));
$('#detailWeightMode').addEventListener('change',updateRuleFields);$('#saveArtistSettingsBtn').addEventListener('click',()=>saveArtistSettings(true));
$('#deleteArtistBtn').addEventListener('click',deleteActiveArtist);
$$('#detailFixedInclude,#detailExcluded,#detailWeightMode,#detailFixedWeight,#detailWeightMin,#detailWeightMax').forEach(node=>node.addEventListener('change',()=>saveArtistSettings(false)));
$('#saveTokenBtn').addEventListener('click',async()=>{try{await api('/api/token',{method:'PUT',body:JSON.stringify({token:value('#token'),remember:$('#rememberToken').checked})});$('#tokenState').textContent=value('#token')?'적용됨':'미입력';$('#tokenState').classList.toggle('ok',!!value('#token'));setTokenCompact(value('#token')?($('#rememberToken').checked?'저장됨':'적용됨'):null);toast('토큰을 적용했습니다.')}catch(e){toast(e.message,true)}});
$('#singleTarget').addEventListener('change',()=>{const mode=value('#singleTarget');$('#singleCustomSelection').classList.toggle('show',mode==='custom');if(mode==='custom')openSingleCustomDialog();updateEstimates()});
$('#openSingleCustomBtn').addEventListener('click',openSingleCustomDialog);
$('#singleImageImportBtn').addEventListener('click',()=>$('#singleImageFile').click());
$('#singleImageFile').addEventListener('change',e=>{importArtistsFromImage(e.target.files[0]);e.target.value=''});
$('#singleImageImportResult').addEventListener('click',e=>{const mode=e.target.closest('[data-image-import]')?.dataset.imageImport;if(mode)applyImageArtists(mode)});
$('#artistTemplate').addEventListener('input',()=>{showArtistTemplateState();clearTimeout(onArtistTemplateChange.timer);onArtistTemplateChange.timer=setTimeout(onArtistTemplateChange,500)});
$('#artistTemplateResetBtn').addEventListener('click',resetArtistTemplate);$('#singleCustomText').addEventListener('input',scheduleCustomArtistDetection);$('#confirmSingleCustomBtn').addEventListener('click',applyCustomArtists);
$$('#singleImages,#comboCount,#imagesPerCombo').forEach(x=>x.addEventListener('input',updateEstimates));
$('#previewMixBtn').addEventListener('click',()=>makePreview(false));$('#togglePreviewBtn').addEventListener('click',()=>setPreviewCollapsed(!$('#comboPreview').classList.contains('hidden')));$('#reshuffleBtn').addEventListener('click',()=>makePreview(true));$('#startMixBtn').addEventListener('click',startMix);$('#startSingleBtn').addEventListener('click',startSingle);
$('#pauseBtn').addEventListener('click',()=>jobAction('pause'));$('#resumeBtn').addEventListener('click',()=>jobAction('resume'));$('#stopBtn').addEventListener('click',()=>jobAction('stop'));$('#retryBtn').addEventListener('click',()=>jobAction('retry'));
$('#commonSettings').addEventListener('input',scheduleCommonAutosave);$('#commonSettings').addEventListener('change',scheduleCommonAutosave);
window.addEventListener('pagehide',flushCommonAutosave);window.addEventListener('beforeunload',flushCommonAutosave);
$('#toggleSettings').addEventListener('click',e=>{const node=$('#commonSettings');node.classList.toggle('hidden');e.target.textContent=node.classList.contains('hidden')?'펼치기':'접기';autosizePromptRows()});
$('#copyPromptBtn').addEventListener('click',async()=>{await navigator.clipboard.writeText($('#promptText').textContent);toast('Prompt를 복사했습니다.')});
$('#imageDialog').addEventListener('click',event=>{if(event.target===event.currentTarget)closeDialog(event.currentTarget)});
$('#shutdownBtn').addEventListener('click',async()=>{if(confirm('앱 서버를 종료할까요?')){await api('/api/shutdown',{method:'POST'});document.body.innerHTML='<div class="empty" style="margin:15vh auto;max-width:500px">Artist Lab 서버가 종료되었습니다. 이 창을 닫아도 됩니다.</div>'}});
init();

from __future__ import annotations

import copy
import logging
from decimal import Decimal
from logging.handlers import RotatingFileHandler
import os
import random
import threading
import time
import uuid
import webbrowser
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError

from backend.artist_library import (
    IMAGE_DIR as LIBRARY_IMAGE_DIR, LibraryPathError, find_artist_entry as find_library_entry, library_prompt, load_library, load_settings as load_library_settings,
    remove_image, reset_library, save_settings as save_library_settings,
    set_cover, settings_for_generation as library_settings_for_generation, settings_key as library_settings_key,
)
from backend.artist_mix import (
    DEFAULT_ARTIST_TEMPLATE, MixValidationError, apply_prompt_blocks, assemble_prompt_blocks, detect_artist_input,
    format_artist_mix, format_artist_tag, generate_combo_set, migrate_artist_record,
    migrate_artist_records, normalize_artist_list, replace_artist_tags_with_placeholder,
)
from backend.models import (
    AppSettings, ArtistBulkUpdate, ArtistPatch, ArtistPoolUpdate, LibraryCoverUpdate,
    LibraryGenerateRequest, LibraryResetRequest, LibrarySettings, MixJobRequest,
    MixPreviewRequest, PromptDetectRequest, PromptPreviewRequest, RegenerateRequest,
    SavedComboCreate, SingleJobRequest, StyleBulkUpdate, StyleCategoryPatch, StylePoolUpdate,
    StyleTagPatch, StyleWeightRange, TokenUpdate,
)
from backend.style_pool import (
    default_style_pool, generate_style_block, make_style_tag, migrate_style_pool, normalize_style_lines,
    normalize_style_tag, randomize_default_selection, validate_style_pool,
)
from backend.image_metadata import extract_artists_from_image
from backend.output_cleanup import FINAL_STATUSES
from backend.queue_manager import QueueManager
from backend.storage import Storage


ROOT = Path(__file__).resolve().parent
storage = Storage(ROOT)


def build_log_handler(path: Path, max_bytes: int = 5 * 1024 * 1024, backup_count: int = 3) -> logging.Handler:
    """app.log rotates at 5MB and keeps app.log.1 .. app.log.3; older logs are dropped."""
    return RotatingFileHandler(path, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    handlers=[build_log_handler(storage.logs_dir / "app.log"), logging.StreamHandler()],
)
log = logging.getLogger("artist_lab")

session_token = ""
queue = QueueManager(storage, lambda: session_token or storage.get_token())
DEFAULT_SETTINGS = AppSettings().model_dump()


@asynccontextmanager
async def lifespan(app: FastAPI):
    queue.load_recent()
    await queue.cleanup_outputs()  # once at start; again after each finished job (queue_manager)
    await queue.start()
    yield
    await queue.shutdown()


app = FastAPI(title="NovelAI Artist Lab", lifespan=lifespan)


@app.exception_handler(Exception)
async def unhandled_error(_: Request, exc: Exception):
    log.exception("Unhandled application error")
    return JSONResponse(status_code=500, content={"detail": "예상하지 못한 오류가 발생했습니다. logs/app.log를 확인해 주세요."})


def get_artists() -> list[dict]:
    raw = storage.read_json("artists", [])
    migrated = migrate_artist_records(raw)
    if migrated != raw:
        storage.write_json("artists", migrated)
    return migrated


def _recover_settings(raw: dict) -> dict:
    """Apply the stored values one field at a time on top of the defaults and keep each
    one only if the whole settings object still validates; invalid fields keep defaults."""
    candidate = AppSettings().model_dump()
    for key, value in raw.items():
        if key == "generation" and isinstance(value, dict):
            for sub_key, sub_value in value.items():
                trial = copy.deepcopy(candidate)
                trial["generation"][sub_key] = sub_value
                try:
                    candidate = AppSettings.model_validate(trial).model_dump()
                except ValidationError:
                    continue
        elif key in candidate and key != "generation":
            trial = {**candidate, key: value}
            try:
                candidate = AppSettings.model_validate(trial).model_dump()
            except ValidationError:
                continue
    return AppSettings.model_validate(candidate).model_dump()


def get_settings() -> dict:
    """Load settings.json. Fields added by newer versions get defaults; invalid fields are
    replaced by their defaults one by one; an unreadable file is backed up first. Always
    returns a valid AppSettings dict."""
    raw = storage.read_json("settings", None)
    path = storage.data_dir / "settings.json"
    if not isinstance(raw, dict):
        if path.exists():
            backup = path.with_name(f"settings.corrupt-{time.strftime('%Y%m%d-%H%M%S')}.json")
            try:
                path.replace(backup)
                log.warning("settings.json was unreadable; kept it as %s and used defaults", backup.name)
            except OSError:
                log.warning("settings.json was unreadable; used defaults")
        return AppSettings().model_dump()
    try:
        return AppSettings.model_validate(raw).model_dump()
    except ValidationError:
        log.warning("settings.json had invalid values; those fields were reset to their defaults")
        return _recover_settings(raw)


def get_style_pool() -> dict:
    raw = storage.read_json("style_pool", None)
    path = storage.data_dir / "style_pool.json"
    if raw is None:
        if path.exists():
            # Unreadable file: keep it for recovery instead of silently overwriting it.
            path.replace(path.with_name(f"style_pool.corrupt-{time.strftime('%Y%m%d-%H%M%S')}.json"))
            log.warning("style_pool.json was unreadable; kept a copy and created a new Style Pool")
        # Fresh install: pick one default-eligible required tag per category, once, and persist it.
        pool = default_style_pool(random.Random())
    else:
        pool = migrate_style_pool(raw, storage.read_json("settings", None))
    if pool != raw:
        storage.write_json("style_pool", pool)
    return pool


def save_style_pool(pool: dict) -> dict:
    pool = migrate_style_pool(pool)
    storage.write_json("style_pool", pool)
    return pool


def find_style_tag(pool: dict, tag: str) -> dict:
    found = next((item for item in pool["tags"] if item["tag"].casefold() == tag.casefold()), None)
    if not found:
        raise HTTPException(404, "Style 태그를 찾을 수 없습니다.")
    return found


def require_style_category(pool: dict, category: str) -> None:
    if category not in {item["id"] for item in pool["categories"]}:
        raise HTTPException(404, "Style 카테고리를 찾을 수 없습니다.")


def style_block_for(pool: dict, rng: random.Random) -> dict:
    try:
        validate_style_pool(pool)
        return generate_style_block(pool, rng)
    except MixValidationError as exc:
        raise HTTPException(400, str(exc)) from exc


def job_style_block(settings: AppSettings) -> dict:
    """One Style Block per job, fixed before any image is queued."""
    if not settings.style_block_enabled:
        return {"style_tags": [], "style_block": ""}
    return style_block_for(get_style_pool(), random.Random())


def current_artist_template() -> str:
    """The saved Artist 출력 형식 (default for settings written before it existed)."""
    template = get_settings().get("artist_template") or DEFAULT_ARTIST_TEMPLATE
    return template if "{artistname}" in template else DEFAULT_ARTIST_TEMPLATE


def combo_decimals(combo: dict) -> int:
    """Weight precision of a saved combo: the mix's own decimals when stored, otherwise the
    precision its stored weights need (0.25 -> 2, 0.125 -> 3), at least 1, at most 4."""
    stored = combo.get("decimals")
    if isinstance(stored, int) and 0 <= stored <= 4:
        return stored
    needed = 1
    for artist in combo.get("artists") or []:
        try:
            exponent = Decimal(str(artist.get("weight"))).normalize().as_tuple().exponent
        except Exception:
            continue
        if isinstance(exponent, int):
            needed = max(needed, -exponent)
    return min(needed, 4)


def get_saved_combos() -> list[dict]:
    """Saved combos keep their artists + weights; artist_mix is rendered with the current
    Artist 출력 형식 and the combo's own weight precision when read, so saved_combos.json
    itself is never rewritten."""
    saved = storage.read_json("saved_combos", [])
    template = current_artist_template()
    for combo in saved:
        if combo.get("artists"):
            combo["artist_mix"] = format_artist_mix(combo["artists"], combo_decimals(combo), template)
    return saved


def selected_pool(mode: str) -> list[dict]:
    """Random-mix candidates. "active" (default) = checked artists; "all" = every
    artist that is not hard-excluded. Legacy "selected" (old MIX-only mode) = "active"."""
    artists = [a for a in get_artists() if not a.get("excluded")]
    if mode == "all":
        return artists
    if mode == "favorites":
        return [a for a in artists if a.get("favorite") and a.get("enabled")]
    return [a for a in artists if a.get("enabled")]


def validate_artist_record(artist: dict) -> None:
    mode = artist.get("weight_mode", "global")
    if mode == "fixed" and artist.get("fixed_weight") is None:
        raise HTTPException(400, "고정 weight 값을 입력해 주세요.")
    if mode == "range":
        minimum, maximum = artist.get("weight_min"), artist.get("weight_max")
        if minimum is None or maximum is None:
            raise HTTPException(400, "개별 weight 최소값과 최대값을 모두 입력해 주세요.")
        if float(minimum) > float(maximum):
            raise HTTPException(400, "개별 weight 최소값이 최대값보다 큽니다.")


def random_seeds(count: int, base_seed: int | None = None) -> list[int]:
    rng = random.Random(base_seed if base_seed is not None else random.SystemRandom().randint(0, 2**31 - 1))
    return [rng.randint(0, 2**32 - 1) for _ in range(count)]


def build_item(item_id: str, group_key: str, label: str, prompt: str, negative: str, seed: int, settings: AppSettings) -> dict:
    return {
        "item_id": item_id,
        "group_key": group_key,
        "label": label,
        "final_prompt": prompt,
        "negative_prompt": negative,
        "seed": seed,
        "parameters": {
            **settings.generation.model_dump(),
            "character_prompt": settings.character_prompt,
        },
    }


@app.get("/api/state")
async def state():
    return {
        "artists": get_artists(),
        "settings": get_settings(),
        "style_pool": get_style_pool(),
        "token_remembered": bool(storage.get_token()),
        "preview": storage.read_json("current_preview", None),
        "saved_combos": get_saved_combos(),
        "jobs": queue.list_jobs(),
        "artist_library": load_library(storage),
    }


@app.put("/api/artists")
async def update_artists(body: ArtistPoolUpdate):
    names = normalize_artist_list(body.text)
    existing = {a["name"].casefold(): a for a in get_artists()}
    result = []
    for name in names:
        record = existing.get(name.casefold(), {"name": name})
        result.append(migrate_artist_record({**record, "name": name}))
    storage.write_json("artists", result)
    return result


@app.post("/api/artists/add")
async def add_artists(body: ArtistPoolUpdate):
    artists = get_artists()
    seen = {artist["name"].casefold() for artist in artists}
    for name in detect_artist_input(body.text):
        if name.casefold() not in seen:
            artists.append(migrate_artist_record({"name": name}))
            seen.add(name.casefold())
    storage.write_json("artists", artists)
    return artists


@app.post("/api/artists/detect")
async def detect_artists_for_pool(body: ArtistPoolUpdate):
    return {"artists": detect_artist_input(body.text)}


@app.patch("/api/artists/{artist_name}")
async def patch_artist(artist_name: str, patch: ArtistPatch):
    artists = get_artists()
    found = False
    for artist in artists:
        if artist["name"] == artist_name:
            changes = patch.model_dump(exclude_unset=True)
            # Older clients still send mix_enabled; it now means the unified checkbox.
            legacy_mix = changes.pop("mix_enabled", None)
            if legacy_mix is not None and "enabled" not in changes:
                changes["enabled"] = legacy_mix
            artist.update(changes)
            if changes.get("enabled") is False or artist.get("excluded"):
                artist["fixed_include"] = False
            elif artist.get("fixed_include"):
                artist["enabled"] = True
            artist["mix_enabled"] = artist["mix_selected"] = bool(artist.get("enabled"))
            validate_artist_record(artist)
            found = True
            break
    if not found:
        raise HTTPException(404, "Artist를 찾을 수 없습니다.")
    storage.write_json("artists", artists)
    return artists


@app.delete("/api/artists/{artist_name}")
async def delete_artist(artist_name: str):
    artists = get_artists()
    filtered = [artist for artist in artists if artist["name"] != artist_name]
    if len(filtered) == len(artists):
        raise HTTPException(404, "Artist를 찾을 수 없습니다.")
    storage.write_json("artists", filtered)
    return filtered


@app.post("/api/artists/bulk")
async def bulk_artists(body: ArtistBulkUpdate):
    artists = get_artists()
    selected = {name.casefold() for name in body.names}
    for artist in artists:
        # mix_include / mix_exclude are legacy names for checking selected artists.
        if body.action in {"enable_all", "disable_all"} or artist["name"].casefold() in selected:
            enabled = body.action in {"enable_all", "mix_include"}
            artist["enabled"] = artist["mix_enabled"] = artist["mix_selected"] = enabled
            if not enabled:
                artist["fixed_include"] = False
    storage.write_json("artists", artists)
    return artists


@app.post("/api/styles/add")
async def add_styles(body: StylePoolUpdate):
    pool = get_style_pool()
    require_style_category(pool, body.category)
    seen = {tag["tag"].casefold() for tag in pool["tags"]}
    for item in normalize_style_lines(body.text):
        if item["tag"].casefold() not in seen:
            weighted = {"weight_mode": "fixed", "weight": item["weight"]} if item["weight"] is not None else {}
            pool["tags"].append(make_style_tag(item["tag"], body.category, **weighted))
            seen.add(item["tag"].casefold())
    return save_style_pool(pool)


@app.put("/api/styles")
async def update_styles(body: StylePoolUpdate):
    """Replace one category's tag list (one tag per line); surviving tags keep their settings."""
    pool = get_style_pool()
    require_style_category(pool, body.category)
    existing = {tag["tag"].casefold(): tag for tag in pool["tags"]}
    lines = normalize_style_lines(body.text)
    listed = {item["tag"].casefold() for item in lines}
    updated = []
    for item in lines:
        record = existing.get(item["tag"].casefold())
        record = {**record, "tag": item["tag"], "category": body.category} if record else make_style_tag(item["tag"], body.category)
        if item["weight"] is not None:
            record.update(weight_mode="fixed", weight=item["weight"])
        updated.append(normalize_style_tag(record))
    kept = [tag for tag in pool["tags"] if tag["category"] != body.category and tag["tag"].casefold() not in listed]
    pool["tags"] = kept + updated
    return save_style_pool(pool)


@app.post("/api/styles/bulk")
async def bulk_styles(body: StyleBulkUpdate):
    """전체 선택 / 전체 해제: only the required (☑) check changes; RND is left untouched."""
    pool = get_style_pool()
    if body.category is not None:
        require_style_category(pool, body.category)
    for tag in pool["tags"]:
        if body.category is None or tag["category"] == body.category:
            tag["required"] = body.action == "check_all"
    return save_style_pool(pool)


@app.post("/api/styles/randomize-defaults")
async def randomize_style_defaults():
    """기본 조합 랜덤 생성: one new default-eligible required tag per built-in category."""
    return save_style_pool(randomize_default_selection(get_style_pool(), random.Random()))


@app.put("/api/styles/weight-range")
async def update_style_weight_range(body: StyleWeightRange):
    pool = get_style_pool()
    pool["weight_range"] = body.model_dump()
    return save_style_pool(pool)


@app.patch("/api/styles/categories/{category_id}")
async def patch_style_category(category_id: str, patch: StyleCategoryPatch):
    pool = get_style_pool()
    require_style_category(pool, category_id)
    category = next(item for item in pool["categories"] if item["id"] == category_id)
    category.update(patch.model_dump(exclude_unset=True, exclude_none=True))
    if category["rnd_min"] > category["rnd_max"]:
        raise HTTPException(400, "RND 추가 최소 개수가 최대 개수보다 큽니다.")
    return save_style_pool(pool)


@app.patch("/api/styles/{tag:path}")
async def patch_style(tag: str, patch: StyleTagPatch):
    pool = get_style_pool()
    record = find_style_tag(pool, tag)
    changes = patch.model_dump(exclude_unset=True)
    if "category" in changes:
        require_style_category(pool, changes["category"])
    record.update(changes)
    if record["weight_mode"] == "fixed" and record["weight"] is None:
        raise HTTPException(400, "고정 weight 값을 입력해 주세요.")
    if record["weight_mode"] == "range" and None not in (record["weight_min"], record["weight_max"]) \
            and record["weight_min"] > record["weight_max"]:
        raise HTTPException(400, "개별 weight 최소값이 최대값보다 큽니다.")
    return save_style_pool(pool)


@app.delete("/api/styles/{tag:path}")
async def delete_style(tag: str):
    pool = get_style_pool()
    record = find_style_tag(pool, tag)
    pool["tags"].remove(record)
    return save_style_pool(pool)


@app.post("/api/prompt/preview")
async def preview_prompt(body: PromptPreviewRequest):
    return assemble_prompt_blocks(
        body.prompt,
        body.artist_block if body.artist_block_enabled else None,
        body.style_block if body.style_block_enabled else None,
        body.artist_fallback, body.style_fallback,
    )


@app.post("/api/blocks/sample")
async def sample_blocks(body: MixPreviewRequest):
    """Draw one throw-away Artist/Style Block pair for the prompt preview."""
    seed = random.SystemRandom().randint(0, 2**32 - 1)
    result = {"artist_block": "", "artist_error": None, "style_block": "", "style_tags": [], "style_error": None}
    if body.artist_block_enabled:
        pool = selected_pool(body.pool_mode)
        # A preview sample only needs to look plausible, so clamp counts to the pool.
        max_count = max(1, min(body.max_artists, len(pool)))
        try:
            result["artist_block"] = generate_combo_set(
                pool, min(body.min_artists, max_count), max_count,
                body.weight_min, body.weight_max, body.decimals, 1, seed, current_artist_template(),
            )[0]["artist_mix"]
        except MixValidationError as exc:
            result["artist_error"] = str(exc)
    if body.style_block_enabled:
        try:
            result.update(style_block_for(get_style_pool(), random.Random(seed)))
        except HTTPException as exc:
            result["style_error"] = exc.detail
    return result


@app.post("/api/metadata/artists")
async def artists_from_image(request: Request):
    """Read artist: tags from an image's own metadata (PNG text, stealth alpha, EXIF,
    XMP, comments). Only fills the 직접 입력 list; nothing is added to the Artist Pool."""
    data = await request.body()
    if len(data) > 60 * 1024 * 1024:
        return {"status": "too_large", "artists": [], "message": "이미지가 너무 큽니다 (최대 60MB)."}
    return extract_artists_from_image(data)


@app.post("/api/prompt/detect")
async def detect_prompt_artists(body: PromptDetectRequest):
    base_prompt, artists = replace_artist_tags_with_placeholder(body.prompt)
    return {"artists": artists, "base_prompt": base_prompt}


@app.put("/api/settings")
async def update_settings(settings: AppSettings):
    storage.write_json("settings", settings.model_dump())
    return settings


@app.put("/api/token")
async def update_token(body: TokenUpdate):
    global session_token
    session_token = body.token.strip()
    storage.set_token(session_token if body.remember else None)
    return {"ok": True, "remembered": body.remember and bool(session_token)}


@app.post("/api/preview/mix")
async def preview_mix(body: MixPreviewRequest):
    mix_seed = body.mix_seed if body.mix_seed is not None else random.SystemRandom().randint(0, 2**32 - 1)
    if not body.artist_block_enabled and not body.style_block_enabled:
        raise HTTPException(400, "Artist Block과 Style Block이 모두 꺼져 있습니다.")
    if body.artist_block_enabled:
        try:
            combos = generate_combo_set(
                selected_pool(body.pool_mode), body.min_artists, body.max_artists,
                body.weight_min, body.weight_max, body.decimals, body.combo_count, mix_seed,
                current_artist_template(),
            )
        except MixValidationError as exc:
            raise HTTPException(400, str(exc)) from exc
    else:
        combos = [{"combo_id": index, "artists": [], "artist_mix": "", "mix_seed": mix_seed}
                  for index in range(1, body.combo_count + 1)]
    # Style tags use their own RNG stream so turning Style Block on does not
    # change the artist combos produced by the same Mix Seed.
    style_pool = get_style_pool() if body.style_block_enabled else None
    style_rng = random.Random(f"style:{mix_seed}")
    for combo in combos:
        combo.update(style_block_for(style_pool, style_rng)
                     if body.style_block_enabled else {"style_tags": [], "style_block": ""})
    if body.seed_mode == "shared":
        shared = random_seeds(body.images_per_combo, body.base_seed)
        for combo in combos:
            combo["seeds"] = shared
    else:
        seed_rng = random.Random(body.base_seed if body.base_seed is not None else mix_seed ^ 0x5F3759DF)
        for combo in combos:
            combo["seeds"] = [seed_rng.randint(0, 2**32 - 1) for _ in range(body.images_per_combo)]
    preview = {
        "preview_id": uuid.uuid4().hex,
        "mix_seed": mix_seed,
        "settings": body.model_dump(),
        "combos": combos,
        "total_images": body.combo_count * body.images_per_combo,
    }
    storage.write_json("current_preview", preview)
    return preview


@app.post("/api/jobs/mix")
async def start_mix(body: MixJobRequest):
    preview = storage.read_json("current_preview", None)
    if not preview or preview.get("preview_id") != body.preview_id:
        raise HTTPException(409, "미리보기가 변경되었거나 없습니다. 조합을 다시 미리보기 해주세요.")
    locked = preview.get("settings", {})
    if (locked.get("artist_block_enabled", True), locked.get("style_block_enabled", False)) != (
        body.settings.artist_block_enabled, body.settings.style_block_enabled
    ):
        raise HTTPException(409, "Artist/Style Block 사용 설정이 미리보기 이후 바뀌었습니다. 조합을 다시 미리보기 해주세요.")
    storage.write_json("settings", body.settings.model_dump())
    items, groups = [], []
    decimals = int(locked.get("decimals", 1))
    for combo in preview["combos"]:
        # Artist and Style Blocks were both locked per combo at preview time; the Artist
        # 출력 형식 is applied to those locked artists/weights now.
        if combo.get("artists"):
            combo["artist_mix"] = format_artist_mix(combo["artists"], decimals, body.settings.artist_template)
        prompt, counts = apply_prompt_blocks(
            body.settings.positive_prompt, combo["artist_mix"], combo.get("style_block"),
            body.settings.placeholder_fallback, body.settings.style_fallback,
        )
        group_key = f"combo-{combo['combo_id']}"
        groups.append({**combo, "group_key": group_key, "decimals": decimals, "base_prompt": body.settings.positive_prompt,
                       "negative_prompt": body.settings.negative_prompt, "character_prompt": body.settings.character_prompt,
                       "placeholder_count": counts["artist_placeholder_count"],
                       "style_placeholder_count": counts["style_placeholder_count"]})
        for index, seed in enumerate(combo["seeds"], 1):
            items.append(build_item(f"{group_key}-{index}", group_key, f"Combo {combo['combo_id']:03d}", prompt,
                                    body.settings.negative_prompt, seed, body.settings))
    metadata = {"preview_id": body.preview_id, "mix_seed": preview["mix_seed"],
                "max_retries": body.settings.retry_count, "settings": body.settings.model_dump()}
    return queue.create_job("random_mix", items, metadata, groups)


@app.post("/api/jobs/single")
async def start_single(body: SingleJobRequest):
    artists = get_artists()
    job_settings = body.settings.model_copy(deep=True)
    if body.target_mode == "detected":
        base_prompt, detected = replace_artist_tags_with_placeholder(body.settings.positive_prompt)
        selected = {name.casefold() for name in body.selected_names}
        targets = [item["name"] for item in detected if item["name"].casefold() in selected]
        job_settings.positive_prompt = base_prompt
    elif body.target_mode == "all":
        targets = [a["name"] for a in artists if not a.get("excluded")]
    elif body.target_mode == "selected":
        selected = {n.casefold() for n in body.selected_names}
        targets = [a["name"] for a in artists if a["name"].casefold() in selected and not a.get("excluded")]
    elif body.target_mode == "custom":
        base_prompt, _ = replace_artist_tags_with_placeholder(body.settings.positive_prompt)
        job_settings.positive_prompt = base_prompt
        targets = normalize_artist_list(body.selected_names)
    else:
        targets = [a["name"] for a in artists if a.get("enabled", True) and not a.get("excluded")]
    if not targets:
        raise HTTPException(400, "테스트할 artist가 없습니다.")
    # Every tested artist shares one Style Block so the comparison stays fair.
    # The Artist Block is always the tested artist in this mode.
    style = job_style_block(job_settings)
    storage.write_json("settings", body.settings.model_dump())
    shared = random_seeds(body.images_per_artist, body.base_seed)
    all_random = random_seeds(len(targets) * body.images_per_artist) if body.seed_mode == "random" else []
    items, groups = [], []
    offset = 0
    for artist_index, name in enumerate(targets, 1):
        artist_mix = format_artist_tag(name, body.artist_weight, body.weight_decimals, job_settings.artist_template)
        prompt, counts = apply_prompt_blocks(
            job_settings.positive_prompt, artist_mix, style["style_block"],
            job_settings.placeholder_fallback, job_settings.style_fallback,
        )
        seeds = shared if body.seed_mode == "shared" else all_random[offset:offset + body.images_per_artist]
        offset += body.images_per_artist
        group_key = f"artist-{artist_index}"
        groups.append({"group_key": group_key, "artist_id": artist_index, "artist_name": name,
                       "weight": body.artist_weight, "artist_mix": artist_mix, "seeds": seeds,
                       "base_prompt": job_settings.positive_prompt, "negative_prompt": job_settings.negative_prompt,
                       "character_prompt": job_settings.character_prompt, **style,
                       "placeholder_count": counts["artist_placeholder_count"],
                       "style_placeholder_count": counts["style_placeholder_count"]})
        for image_index, seed in enumerate(seeds, 1):
            items.append(build_item(f"{group_key}-{image_index}", group_key, name, prompt,
                                    job_settings.negative_prompt, seed, job_settings))
    metadata = {"max_retries": job_settings.retry_count, "settings": job_settings.model_dump(),
                "source_prompt": body.settings.positive_prompt, "seed_mode": body.seed_mode,
                "style_block": style["style_block"]}
    return queue.create_job("single_artist", items, metadata, groups)


def library_state_payload(library: dict | None = None) -> dict:
    settings, saved = load_library_settings(storage)
    current_key = library_settings_key({**settings, "artist_template": current_artist_template()})
    return {"settings": settings, "saved": saved, "settings_key": current_key,
            "library": library if library is not None else load_library(storage)}


def library_targets(body: LibraryGenerateRequest, current_key: str) -> list[str]:
    """Library target = "is the artist in the Artist Pool". Checked / 🚫 / 📌 are mix and
    single-test rules and are deliberately ignored here."""
    if body.target == "names":
        return normalize_artist_list(body.artist_names)
    pool = [artist["name"] for artist in get_artists()]
    if body.target == "all":
        return pool
    library = load_library(storage)
    return [name for name in pool
            if not any(image.get("settings_key") == current_key
                       for image in (find_library_entry(library, name) or {}).get("images", []))]


@app.get("/api/library")
async def library_state():
    return library_state_payload()


@app.put("/api/library/settings")
async def update_library_settings(body: LibrarySettings):
    save_library_settings(storage, body.model_dump())
    return library_state_payload()


@app.delete("/api/library")
async def reset_library_endpoint(body: LibraryResetRequest):
    """Library 전체 초기화: all Library samples, their image copies and the Library 설정.
    The Artist Pool and everything outside the Library stay."""
    if not body.confirm:
        raise HTTPException(400, "Library 전체 초기화를 확인해 주세요.")
    library_jobs = [job for job in queue.jobs.values() if job.get("mode") == "artist_library"]
    if any(job.get("status") not in FINAL_STATUSES for job in library_jobs):
        raise HTTPException(409, "끝나지 않은 Library 생성 작업(대기·생성 중·일시정지·중지 중)이 있습니다. "
                                 "최근 기록에서 중지하거나 끝난 뒤 다시 시도해 주세요.")
    # Jobs from before the reset (e.g. "실패 재시도" later) must never write into the new Library.
    for job in library_jobs:
        job.setdefault("metadata", {})["library_superseded"] = True
        if job.get("output_folder"):
            queue._persist(job)
    removed = reset_library(storage)
    log.info("Artist Library reset: %s data files, %s images removed", removed["files"], removed["images"])
    return {**library_state_payload(), "removed": removed}


@app.post("/api/library/generate")
async def generate_library(body: LibraryGenerateRequest):
    """One image per artist with the Library's own saved settings; only the artist changes."""
    template = current_artist_template()
    settings = {**library_settings_for_generation(storage), "artist_template": template}
    targets = library_targets(body, library_settings_key(settings))
    if not targets:
        raise HTTPException(400, "현재 설정 샘플이 없는 작가가 없습니다." if body.target == "missing"
                            else "Library를 만들 작가가 없습니다.")
    job_settings = AppSettings(
        generation={"model": settings["model"], **settings["generation"]},
        positive_prompt=settings["positive_prompt"], negative_prompt=settings["negative_prompt"],
        character_prompt=settings["character_prompt"],
    )
    items, groups = [], []
    for index, name in enumerate(targets, 1):
        prompt = library_prompt(settings, name, template)
        group_key = f"artist-{index}"
        groups.append({"group_key": group_key, "artist_id": index, "artist_name": name,
                       "weight": settings["artist_weight"], "artist_mix": format_artist_tag(name, settings["artist_weight"], 1, template),
                       "seeds": [settings["seed"]], "base_prompt": settings["positive_prompt"],
                       "negative_prompt": settings["negative_prompt"], "character_prompt": settings["character_prompt"]})
        items.append(build_item(f"{group_key}-1", group_key, name, prompt, settings["negative_prompt"],
                                settings["seed"], job_settings))
    metadata = {"max_retries": job_settings.retry_count, "library_settings": settings}
    return {"job": queue.create_job("artist_library", items, metadata, groups), **library_state_payload()}


@app.put("/api/library/artists/{artist_name}/cover")
async def update_library_cover(artist_name: str, body: LibraryCoverUpdate):
    library = set_cover(storage, artist_name, body.image_id)
    if library is None:
        raise HTTPException(404, "Library 이미지를 찾을 수 없습니다.")
    return library_state_payload(library)


@app.delete("/api/library/artists/{artist_name}/images/{image_id}")
async def delete_library_image(artist_name: str, image_id: str):
    try:
        library = remove_image(storage, artist_name, image_id)
    except LibraryPathError as exc:
        log.warning("Refused to delete a Library file outside the Library folder (%s)", exc)
        raise HTTPException(400, "이 Library 기록의 파일 경로가 올바르지 않아 삭제하지 않았습니다.") from exc
    except OSError as exc:
        log.warning("Could not save the Library index while deleting an image (%s)", exc.__class__.__name__)
        raise HTTPException(500, "Library 기록을 저장하지 못해 이미지를 삭제하지 않았습니다. 잠시 후 다시 시도해 주세요.") from exc
    if library is None:
        raise HTTPException(404, "Library 이미지를 찾을 수 없습니다.")
    return library_state_payload(library)


@app.get("/api/jobs")
async def jobs():
    return queue.list_jobs()


@app.get("/api/jobs/{job_id}")
async def job_detail(job_id: str):
    job = queue.get_job(job_id)
    if not job:
        raise HTTPException(404, "작업을 찾을 수 없습니다.")
    return job


def queue_action(job_id: str, action: str):
    try:
        return getattr(queue, action)(job_id)
    except KeyError as exc:
        raise HTTPException(404, "작업을 찾을 수 없습니다.") from exc


@app.post("/api/jobs/{job_id}/pause")
async def pause_job(job_id: str): return queue_action(job_id, "pause")


@app.post("/api/jobs/{job_id}/resume")
async def resume_job(job_id: str): return queue_action(job_id, "resume")


@app.post("/api/jobs/{job_id}/stop")
async def stop_job(job_id: str): return queue_action(job_id, "stop")


@app.post("/api/jobs/{job_id}/retry")
async def retry_job(job_id: str):
    job = queue.jobs.get(job_id)
    if job and job.get("metadata", {}).get("library_superseded"):
        # The Library was reset after this job; retrying would spend API calls for images
        # the new Library would never record.
        raise HTTPException(409, "Library 초기화 이전의 작업이라 재시도할 수 없습니다. Library에서 새로 생성해 주세요.")
    return queue_action(job_id, "retry_failed")


@app.post("/api/saved-combos")
async def save_combo(body: SavedComboCreate):
    job = queue.get_job(body.job_id)
    if not job:
        raise HTTPException(404, "작업을 찾을 수 없습니다.")
    group = next((g for g in job["groups"] if g.get("combo_id") == body.combo_id), None)
    if not group:
        raise HTTPException(404, "조합을 찾을 수 없습니다.")
    images = [i for i in job["items"] if i["group_key"] == group["group_key"] and i["status"] == "completed"]
    saved = get_saved_combos()
    existing = next((s for s in saved if s.get("source_job_id") == body.job_id and s.get("source_combo_id") == body.combo_id), None)
    record = {
        "saved_id": existing["saved_id"] if existing else uuid.uuid4().hex[:12],
        "source_job_id": body.job_id, "source_combo_id": body.combo_id,
        "artists": group["artists"], "artist_mix": group["artist_mix"],
        "decimals": group.get("decimals", combo_decimals(group)),
        "style_tags": group.get("style_tags", []), "style_block": group.get("style_block", ""),
        "base_prompt": group.get("base_prompt", ""), "negative_prompt": group.get("negative_prompt", ""),
        "character_prompt": group.get("character_prompt", ""),
        "seeds": group.get("seeds", []), "images": [i["image_url"] for i in images],
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    if existing:
        saved[saved.index(existing)] = record
    else:
        saved.insert(0, record)
    storage.write_json("saved_combos", saved)
    return record


@app.delete("/api/saved-combos/{saved_id}")
async def delete_saved(saved_id: str):
    saved = get_saved_combos()
    filtered = [s for s in saved if s.get("saved_id") != saved_id]
    if len(filtered) == len(saved):
        raise HTTPException(404, "저장된 조합을 찾을 수 없습니다.")
    storage.write_json("saved_combos", filtered)
    return {"ok": True}


@app.post("/api/saved-combos/{saved_id}/regenerate")
async def regenerate_saved(saved_id: str, body: RegenerateRequest):
    saved = next((s for s in get_saved_combos() if s.get("saved_id") == saved_id), None)
    if not saved:
        raise HTTPException(404, "저장된 조합을 찾을 수 없습니다.")
    # A saved combo replays its own Style Block; older saves without one get a
    # fresh block only when Style Block is currently enabled.
    style = {"style_tags": saved.get("style_tags") or [], "style_block": saved.get("style_block") or ""}
    if not style["style_block"]:
        style = job_style_block(body.settings)
    if saved.get("artists"):
        saved["artist_mix"] = format_artist_mix(saved["artists"], combo_decimals(saved), body.settings.artist_template)
    prompt, counts = apply_prompt_blocks(
        body.settings.positive_prompt, saved["artist_mix"], style["style_block"],
        body.settings.placeholder_fallback, body.settings.style_fallback,
    )
    original = saved.get("seeds", [])
    seeds = (original[:body.images] if body.seed_mode == "original" else random_seeds(body.images))
    while len(seeds) < body.images:
        seeds.extend(random_seeds(body.images - len(seeds)))
    group = {"group_key": "combo-1", "combo_id": 1, "artists": saved["artists"],
             "artist_mix": saved["artist_mix"], **style, "seeds": seeds, "base_prompt": body.settings.positive_prompt,
             "negative_prompt": body.settings.negative_prompt, "character_prompt": body.settings.character_prompt,
             "placeholder_count": counts["artist_placeholder_count"],
             "style_placeholder_count": counts["style_placeholder_count"]}
    items = [build_item(f"combo-1-{i}", "combo-1", "저장 조합", prompt, body.settings.negative_prompt, seed, body.settings)
             for i, seed in enumerate(seeds, 1)]
    return queue.create_job("saved_combo", items, {"saved_id": saved_id, "max_retries": body.settings.retry_count,
                                                    "settings": body.settings.model_dump()}, [group])


@app.post("/api/shutdown")
async def shutdown():
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {"ok": True}


app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
app.mount("/generated", StaticFiles(directory=storage.outputs_dir), name="generated")
(storage.data_dir / LIBRARY_IMAGE_DIR).mkdir(parents=True, exist_ok=True)
app.mount("/library-files", StaticFiles(directory=storage.data_dir / LIBRARY_IMAGE_DIR), name="library-files")


@app.get("/")
async def index():
    return FileResponse(ROOT / "static" / "index.html")


if __name__ == "__main__":
    if os.environ.get("ARTIST_LAB_NO_BROWSER") != "1":
        threading.Timer(1.2, lambda: webbrowser.open("http://127.0.0.1:8766")).start()
    uvicorn.run(app, host="127.0.0.1", port=8766, log_config=None)

"""Artist Library: per-artist sample images generated with the Library's own settings.

The Library never reads the main screen's prompt / model / mix / single-test values.

data/library_settings.json  - Library 설정 (absent = defaults)::

    {"positive_prompt", "negative_prompt", "model", "seed" (int | null), "artist_weight",
     "artist_position" ("prepend" | "append"), "character_prompt",
     "generation": {"width", "height", "steps", "sampler", "scheduler", "scale", "cfg_rescale"},
     "updated_at"}

data/artist_library.json  - samples per artist (keyed by casefolded artist name)::

    {"version": 2, "artists": {"<key>": {"name", "cover_image_id",
        "images": [{"image_id", "file", "image_url", "created_at", "seed", "model", "prompt",
                    "job_id", "settings": {...snapshot...}, "settings_key"}]}}}

data/artist_library/<artist>/<image_id>.png  - independent copies; deleting generation
results or job history never removes Library images.
"""
from __future__ import annotations

import copy
import hashlib
import json
import random
import re
import shutil
import uuid
from pathlib import Path
from datetime import datetime

from .artist_mix import (
    DEFAULT_ARTIST_TEMPLATE, apply_prompt_blocks, format_artist_tag, normalize_artist_name,
    replace_artist_tags_with_placeholder, safe_folder_name,
)
from .storage import Storage


LIBRARY_FILE = "artist_library"
SETTINGS_FILE = "library_settings"
LEGACY_SETTINGS_FILE = "library_benchmark"
IMAGE_DIR = "artist_library"
IMAGE_URL_PREFIX = "/library-files/"
GENERATION_DEFAULTS = {"width": 832, "height": 1216, "steps": 28, "sampler": "k_euler_ancestral",
                       "scheduler": "karras", "scale": 5.0, "cfg_rescale": 0.0}
SETTINGS_DEFAULTS = {
    "positive_prompt": "", "negative_prompt": "", "model": "nai-diffusion-5-full", "seed": None,
    "artist_weight": 1.0, "artist_position": "prepend", "character_prompt": "",
    "generation": GENERATION_DEFAULTS,
}
# Fields that define how a sample looks; used to tell "made with the current settings".
SNAPSHOT_KEYS = ("positive_prompt", "negative_prompt", "model", "seed", "artist_weight",
                 "artist_position", "character_prompt", "generation")


def library_key(name: str) -> str:
    return normalize_artist_name(name).casefold()


def default_settings() -> dict:
    return copy.deepcopy(SETTINGS_DEFAULTS)


def settings_key(settings: dict) -> str:
    snapshot = {key: settings.get(key) for key in SNAPSHOT_KEYS}
    # The artist output template changes the prompt too; the default is left out so
    # samples made before templates existed still count as made with the default.
    template = settings.get("artist_template")
    if template not in (None, DEFAULT_ARTIST_TEMPLATE):
        snapshot["artist_template"] = template
    return hashlib.sha1(json.dumps(snapshot, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:12]


# ---- Library 설정 -------------------------------------------------------------------

def _from_legacy_benchmark(old: dict) -> dict:
    """The first Library version stored a "benchmark" copied from the main screen with
    block placeholders; turn it into plain Library 설정 text."""
    prompt = str(old.get("positive_prompt", ""))
    position = "prepend"
    stripped = prompt.strip()
    for token in ("{{ARTIST_BLOCK}}", "{{ARTISTS}}"):
        if stripped.startswith(token):
            prompt, position = stripped[len(token):].lstrip(" ,"), "prepend"
            break
        if stripped.endswith(token):
            prompt, position = stripped[:-len(token)].rstrip(" ,"), "append"
            break
    if "{{STYLE_BLOCK}}" in prompt:
        prompt = prompt.replace("{{STYLE_BLOCK}}", old.get("style_block") or "")
        prompt = re.sub(r",\s*,", ",", prompt).strip(" ,")
    return {
        "positive_prompt": prompt, "negative_prompt": old.get("negative_prompt", ""),
        "model": old.get("model"), "seed": old.get("seed"), "artist_weight": old.get("artist_weight"),
        "artist_position": position, "character_prompt": old.get("character_prompt", ""),
        "generation": old.get("generation") or {},
    }


def normalize_settings(raw: dict | None) -> dict:
    settings = default_settings()
    if isinstance(raw, dict):
        for key in SETTINGS_DEFAULTS:
            if key == "generation":
                settings["generation"].update({k: v for k, v in (raw.get("generation") or {}).items()
                                               if k in GENERATION_DEFAULTS and v is not None})
            elif raw.get(key) is not None or key == "seed":
                settings[key] = raw.get(key, settings[key])
        if raw.get("updated_at"):
            settings["updated_at"] = raw["updated_at"]
    return settings


def load_settings(storage: Storage) -> tuple[dict, bool]:
    """(settings, saved). Migrates the old library_benchmark.json once."""
    raw = storage.read_json(SETTINGS_FILE, None)
    legacy_path = storage.data_dir / f"{LEGACY_SETTINGS_FILE}.json"
    if raw is None and legacy_path.exists():
        legacy = storage.read_json(LEGACY_SETTINGS_FILE, None)
        if isinstance(legacy, dict):
            raw = save_settings(storage, _from_legacy_benchmark(legacy))
            legacy_path.replace(legacy_path.with_name(f"{LEGACY_SETTINGS_FILE}.migrated.json"))
    if not isinstance(raw, dict):
        return default_settings(), False
    return normalize_settings(raw), True


def save_settings(storage: Storage, settings: dict) -> dict:
    settings = normalize_settings(settings)
    settings["updated_at"] = datetime.now().isoformat(timespec="seconds")
    storage.write_json(SETTINGS_FILE, settings)
    return settings


def reset_settings(storage: Storage) -> dict:
    """Back to defaults (seed empty). Library images and the Artist Pool are untouched."""
    path = storage.data_dir / f"{SETTINGS_FILE}.json"
    if path.exists():
        path.unlink()
    return default_settings()


def settings_for_generation(storage: Storage) -> dict:
    """Saved settings, with an empty seed replaced by a random one that is stored for reuse."""
    settings, _ = load_settings(storage)
    if settings["seed"] is None:
        settings["seed"] = random.SystemRandom().randint(0, 2**32 - 1)
        settings = save_settings(storage, settings)
    return settings


def library_prompt(settings: dict, artist_name: str, template: str | None = None) -> str:
    """Only the artist changes: literal artist tags in the prompt become the artist slot,
    otherwise the tag goes to the configured position."""
    artist_tag = format_artist_tag(artist_name, settings["artist_weight"], 1, template)
    base, _ = replace_artist_tags_with_placeholder(settings["positive_prompt"])
    prompt, _ = apply_prompt_blocks(base, artist_tag, None, settings["artist_position"])
    return prompt


# ---- Library images -----------------------------------------------------------------

IMAGE_SUFFIXES = {".png", ".webp", ".jpg", ".jpeg"}


class LibraryPathError(ValueError):
    """A recorded path points outside the folder it must stay in."""


def _contained_file(root: Path, candidate: Path, suffixes: set[str] | None = None) -> Path:
    """Resolve ``candidate`` and require a regular (non-symlink) file strictly inside
    ``root``: no "..", no absolute or junction/symlink escape, never the root itself."""
    try:
        root_resolved = root.resolve(strict=True)
        resolved = candidate.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        raise LibraryPathError(str(exc)) from exc
    if resolved == root_resolved or root_resolved not in resolved.parents:
        raise LibraryPathError("outside of its folder")
    if candidate.is_symlink() or (resolved.exists() and not resolved.is_file()):
        raise LibraryPathError("not a regular file")
    if suffixes is not None and resolved.suffix.lower() not in suffixes:
        raise LibraryPathError("not an image file")
    return resolved


def library_image_file(storage: Storage, relative: str) -> Path:
    """The on-disk file of a Library record, guaranteed to be inside data/artist_library/."""
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise LibraryPathError("invalid path")
    return _contained_file(storage.data_dir / IMAGE_DIR, storage.data_dir / relative, IMAGE_SUFFIXES)


def generated_source_file(storage: Storage, url: str) -> Path:
    """The outputs/ file behind a /generated/... URL, guaranteed to be inside outputs/."""
    if not isinstance(url, str) or not url.startswith("/generated/"):
        raise LibraryPathError("not a generated image")
    return _contained_file(storage.outputs_dir, storage.outputs_dir / url.removeprefix("/generated/"), IMAGE_SUFFIXES)


def _image_path(storage: Storage, folder: str, image_id: str):
    return storage.data_dir / IMAGE_DIR / folder / f"{image_id}.png"


def _copy_into_library(storage: Storage, source, artist_name: str, image_id: str) -> dict:
    folder = safe_folder_name(artist_name)
    target = _image_path(storage, folder, image_id)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    return {"file": f"{IMAGE_DIR}/{folder}/{image_id}.png", "image_url": f"{IMAGE_URL_PREFIX}{folder}/{image_id}.png"}


def _remove_quietly(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def load_library(storage: Storage) -> dict:
    raw = storage.read_json(LIBRARY_FILE, None)
    path = storage.data_dir / f"{LIBRARY_FILE}.json"
    if raw is None and path.exists():
        # Unreadable index: keep it for recovery instead of overwriting it with an empty one.
        backup = path.with_name(f"{LIBRARY_FILE}.corrupt-{datetime.now():%Y%m%d-%H%M%S}.json")
        path.replace(backup)
    artists = raw.get("artists") if isinstance(raw, dict) else None
    library = {"version": 2, "artists": artists if isinstance(artists, dict) else {}}
    if isinstance(raw, dict) and raw.get("version") != 2:
        _migrate_v1_images(storage, library)
        storage.write_json(LIBRARY_FILE, library)
    return library


def _migrate_v1_images(storage: Storage, library: dict) -> None:
    """v1 only referenced files under outputs/; copy them into the Library folder."""
    for entry in library["artists"].values():
        for image in entry.get("images", []):
            if image.get("file"):
                continue
            try:
                source = generated_source_file(storage, str(image.get("image_url", "")))
            except LibraryPathError:
                source = None  # never copy from outside outputs/
            if source is not None and source.exists():
                image.update(_copy_into_library(storage, source, entry["name"], image["image_id"]))
            legacy = image.pop("benchmark", None) or {}
            snapshot = normalize_settings(_from_legacy_benchmark(legacy)) if legacy else {}
            image.setdefault("settings", snapshot)
            image.setdefault("settings_key", settings_key(snapshot) if snapshot else None)
            image.setdefault("seed", legacy.get("seed"))
            image.setdefault("model", legacy.get("model"))


def record_library_image(storage: Storage, job: dict, group: dict, item: dict) -> dict | None:
    """Called by the queue when an artist_library item finishes: copy the image into the
    Library folder and record it with the settings snapshot used to make it. A job started
    before a Library reset never records again. If the index cannot be saved the new copy
    is removed again, so no orphan file is left behind."""
    if job["metadata"].get("library_superseded"):
        return None
    library = load_library(storage)
    name = group["artist_name"]
    entry = library["artists"].setdefault(library_key(name), {"name": name, "cover_image_id": None, "images": []})
    image_id = uuid.uuid4().hex[:12]
    source = generated_source_file(storage, item["image_url"])
    snapshot = job["metadata"].get("library_settings", {})
    image = {
        "image_id": image_id,
        **_copy_into_library(storage, source, name, image_id),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "seed": item["seed"],
        "model": item["parameters"].get("model"),
        "prompt": item["final_prompt"],
        "job_id": job["job_id"],
        "settings": snapshot,
        "settings_key": settings_key(snapshot),
    }
    entry["images"].append(image)
    try:
        storage.write_json(LIBRARY_FILE, library)
    except Exception:
        _remove_quietly(storage.data_dir / image["file"])
        raise
    return image


def find_artist_entry(library: dict, name: str) -> dict | None:
    return library["artists"].get(library_key(name))


def set_cover(storage: Storage, name: str, image_id: str | None) -> dict | None:
    library = load_library(storage)
    entry = find_artist_entry(library, name)
    if entry is None or (image_id is not None and not any(i["image_id"] == image_id for i in entry["images"])):
        return None
    entry["cover_image_id"] = image_id
    storage.write_json(LIBRARY_FILE, library)
    return library


def remove_image(storage: Storage, name: str, image_id: str) -> dict | None:
    """Removes the Library copy and its record; generation results in outputs/ stay.
    The recorded path must stay inside data/artist_library/ (LibraryPathError otherwise).
    The index is saved first and the file removed afterwards, so a failure can leave at
    worst an unreferenced file, never a record whose file is gone."""
    library = load_library(storage)
    entry = find_artist_entry(library, name)
    image = next((i for i in entry["images"] if i["image_id"] == image_id), None) if entry else None
    if image is None:
        return None
    path = library_image_file(storage, image["file"]) if image.get("file") else None
    entry["images"].remove(image)
    if entry["cover_image_id"] == image_id:
        entry["cover_image_id"] = None
    if not entry["images"]:
        del library["artists"][library_key(name)]
    storage.write_json(LIBRARY_FILE, library)
    if path is not None:
        _remove_quietly(path)
    return library


# ---- Library 전체 초기화 ------------------------------------------------------------

LIBRARY_DATA_FILES = (LIBRARY_FILE, SETTINGS_FILE, LEGACY_SETTINGS_FILE, f"{LEGACY_SETTINGS_FILE}.migrated")


def reset_library(storage: Storage) -> dict:
    """Return the Artist Library to its never-used state: every sample record, cover,
    settings snapshot, the Library 설정 (seed included) and the Library image copies.
    Only Library-owned paths are touched; the Artist Pool, outputs/, saved combos,
    history and app settings stay."""
    removed = {"files": 0, "images": 0, "failed": 0}
    for name in LIBRARY_DATA_FILES:
        path = storage.data_dir / f"{name}.json"
        if path.exists():
            path.unlink()
            removed["files"] += 1
    image_root = (storage.data_dir / IMAGE_DIR).resolve()
    if image_root.parent != storage.data_dir.resolve() or image_root.name != IMAGE_DIR:
        raise RuntimeError("Unexpected Library image folder")
    if image_root.exists():
        files = [path for path in image_root.rglob("*") if path.is_file()]
        # The index files are already gone, so a partial failure here can only leave
        # unreferenced image files (the next reset removes them), never broken records.
        shutil.rmtree(image_root, ignore_errors=True)
        left = [path for path in files if path.exists()]
        removed["images"] = len(files) - len(left)
        removed["failed"] = len(left)
    image_root.mkdir(parents=True, exist_ok=True)  # served at /library-files
    return removed

"""Read the positive prompt stored in an image and pull artist: tags out of it.

Pure Python (the portable build ships without Pillow). Supported, as NovelAI and common
tools actually store them:

* PNG ``tEXt`` / ``zTXt`` / ``iTXt``: NovelAI writes ``Comment`` (JSON with ``prompt`` and
  ``v4_prompt``) and ``Description`` (the prompt as text); A1111 writes ``parameters``.
* PNG "stealth pnginfo": NovelAI also hides the same metadata in the alpha channel's
  least-significant bits (column-major, ``stealth_pnginfo``/``stealth_pngcomp`` header),
  which survives sites that strip text chunks.
* JPEG / WebP: EXIF ``UserComment`` / ``ImageDescription`` / ``XPComment``, XMP, and JPEG
  ``COM`` comments.

Only positive-prompt fields are used: negative prompts (``uc``, ``negative_prompt``,
``v4_negative_prompt``) often list artists the user does *not* want.
"""
from __future__ import annotations

import gzip
import json
import re
import struct
import zlib

from .artist_mix import extract_artist_tags


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
NEGATIVE_KEYS = {"uc", "negative_prompt", "v4_negative_prompt", "negative"}
PROMPT_KEYS = ("prompt", "Description", "description", "positive_prompt")
STEALTH_SIGNATURES = {b"stealth_pnginfo": False, b"stealth_pngcomp": True}
MESSAGES = {
    "unsupported": "지원하지 않는 이미지 형식입니다. PNG, WebP, JPEG 이미지를 선택해 주세요.",
    "no_metadata": "이미지에서 메타데이터를 찾지 못했습니다.",
    "no_prompt": "메타데이터는 있지만 Prompt를 찾지 못했습니다.",
    "no_artist": "Prompt는 찾았지만 artist: 태그가 없습니다.",
    "error": "이미지 메타데이터를 읽지 못했습니다. 손상되었거나 지원하지 않는 형식일 수 있습니다.",
}


# ---- PNG ----------------------------------------------------------------------------

def _png_chunks(data: bytes):
    pos = len(PNG_SIGNATURE)
    while pos + 8 <= len(data):
        length, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + length]
        yield kind, body
        pos += 12 + length
        if kind == b"IEND":
            break


def png_text_chunks(data: bytes) -> dict[str, str]:
    texts: dict[str, str] = {}
    for kind, body in _png_chunks(data):
        try:
            if kind == b"tEXt":
                key, _, value = body.partition(b"\0")
                texts[key.decode("latin-1")] = value.decode("utf-8", "replace")
            elif kind == b"zTXt":
                key, _, rest = body.partition(b"\0")
                texts[key.decode("latin-1")] = zlib.decompress(rest[1:]).decode("utf-8", "replace")
            elif kind == b"iTXt":
                key, _, rest = body.partition(b"\0")
                compressed, rest = rest[0], rest[2:]
                _, _, rest = rest.partition(b"\0")  # language tag
                _, _, value = rest.partition(b"\0")  # translated keyword
                texts[key.decode("latin-1")] = (zlib.decompress(value) if compressed else value).decode("utf-8", "replace")
        except (zlib.error, IndexError, UnicodeDecodeError):
            continue
    return texts


def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else b if pb <= pc else c


def _png_rows(raw: bytes, stride: int, bpp: int, height: int):
    previous = bytearray(stride)
    pos = 0
    for _ in range(height):
        kind = raw[pos]
        line = bytearray(raw[pos + 1:pos + 1 + stride])
        pos += 1 + stride
        if kind == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 255
        elif kind == 2:
            line = bytearray((x + y) & 255 for x, y in zip(line, previous))
        elif kind == 3:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((left + previous[i]) >> 1)) & 255
        elif kind == 4:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                up_left = previous[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + _paeth(left, previous[i], up_left)) & 255
        yield line
        previous = line


def png_stealth_metadata(data: bytes) -> dict | None:
    """NovelAI stealth pnginfo from the alpha channel (8-bit RGBA, non-interlaced)."""
    header = next((body for kind, body in _png_chunks(data) if kind == b"IHDR"), None)
    if not header:
        return None
    width, height, depth, color, _, _, interlace = struct.unpack(">IIBBBBB", header[:13])
    if depth != 8 or color != 6 or interlace:
        return None
    raw = zlib.decompress(b"".join(body for kind, body in _png_chunks(data) if kind == b"IDAT"))
    stride = width * 4
    # Bits are read column by column (x outer, y inner). Collect the alpha of the first
    # columns only as far as needed; rows still have to be decoded in order.
    header_bits = 15 * 8 + 32
    columns_needed = -(-header_bits // height)
    alphas: list[bytearray] = []
    rows = _png_rows(raw, stride, 4, height)
    for line in rows:
        alphas.append(line[3::4])

    def bits(start: int, count: int):
        return [alphas[i % height][i // height] & 1 for i in range(start, start + count)]

    def to_bytes(bit_list):
        return bytes(int("".join(map(str, bit_list[i:i + 8])), 2) for i in range(0, len(bit_list), 8))

    if columns_needed > width:
        return None
    signature = to_bytes(bits(0, 15 * 8))
    if signature not in STEALTH_SIGNATURES:
        return None
    length = int("".join(map(str, bits(15 * 8, 32))), 2)
    if length <= 0 or length % 8 or header_bits + length > width * height:
        return None
    payload = to_bytes(bits(header_bits, length))
    text = (gzip.decompress(payload) if STEALTH_SIGNATURES[signature] else payload).decode("utf-8")
    outer = json.loads(text)
    return outer if isinstance(outer, dict) else None


# ---- EXIF / XMP (JPEG, WebP) ---------------------------------------------------------

def _decode_user_comment(value: bytes) -> str:
    prefix, body = value[:8], value[8:]
    if prefix.startswith(b"UNICODE"):
        if body[:2] in (b"\xff\xfe", b"\xfe\xff"):
            return body.decode("utf-16")
        # piexif writes UTF-16 big-endian; fall back to little-endian when that looks wrong
        big = body.decode("utf-16-be", "ignore")
        little = body.decode("utf-16-le", "ignore")
        return big if big.isprintable() or "\n" in big else little
    if prefix.startswith((b"ASCII", b"\0\0\0\0\0\0\0\0")):
        return body.decode("utf-8", "replace")
    return value.decode("utf-8", "replace")


def exif_texts(tiff: bytes) -> list[str]:
    """ImageDescription, XPComment and UserComment from a TIFF/EXIF block."""
    if len(tiff) < 8 or tiff[:2] not in (b"II", b"MM"):
        return []
    endian = "<" if tiff[:2] == b"II" else ">"
    texts: list[str] = []
    sizes = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8}

    def read_ifd(offset: int, depth: int = 0):
        if depth > 3 or offset <= 0 or offset + 2 > len(tiff):
            return
        (count,) = struct.unpack(endian + "H", tiff[offset:offset + 2])
        for index in range(min(count, 512)):
            entry = offset + 2 + index * 12
            if entry + 12 > len(tiff):
                return
            tag, kind, n = struct.unpack(endian + "HHI", tiff[entry:entry + 8])
            size = sizes.get(kind, 1) * n
            raw = tiff[entry + 8:entry + 8 + size] if size <= 4 else \
                tiff[struct.unpack(endian + "I", tiff[entry + 8:entry + 12])[0]:][:size]
            if tag == 0x8769:  # Exif IFD pointer
                read_ifd(struct.unpack(endian + "I", tiff[entry + 8:entry + 12])[0], depth + 1)
            elif tag == 0x010E:  # ImageDescription
                texts.append(raw.rstrip(b"\0").decode("utf-8", "replace"))
            elif tag == 0x9C9C:  # XPComment (UTF-16LE)
                texts.append(raw.decode("utf-16-le", "ignore").rstrip("\0"))
            elif tag == 0x9286:  # UserComment
                texts.append(_decode_user_comment(raw).rstrip("\0"))

    read_ifd(struct.unpack(endian + "I", tiff[4:8])[0])
    return [text for text in texts if text.strip()]


def _xmp_texts(xmp: bytes) -> list[str]:
    text = xmp.decode("utf-8", "replace")
    found = re.findall(r"<(?:dc:description|exif:UserComment|tiff:ImageDescription)[^>]*>(.*?)</", text, re.S)
    found += re.findall(r"<rdf:li[^>]*>(.*?)</rdf:li>", text, re.S)
    unescape = {"&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'", "&amp;": "&"}
    return [re.sub("|".join(map(re.escape, unescape)), lambda m: unescape[m.group(0)], value).strip()
            for value in found if value.strip()]


def jpeg_texts(data: bytes) -> list[str]:
    texts: list[str] = []
    pos = 2
    while pos + 4 <= len(data) and data[pos] == 0xFF:
        marker = data[pos + 1]
        if marker in (0xD9, 0xDA):  # end of image / start of scan
            break
        (length,) = struct.unpack(">H", data[pos + 2:pos + 4])
        segment = data[pos + 4:pos + 2 + length]
        if marker == 0xE1 and segment.startswith(b"Exif\0\0"):
            texts += exif_texts(segment[6:])
        elif marker == 0xE1 and segment.startswith(b"http://ns.adobe.com/xap/1.0/\0"):
            texts += _xmp_texts(segment[29:])
        elif marker == 0xFE:
            texts.append(segment.decode("utf-8", "replace"))
        pos += 2 + length
    return texts


def webp_texts(data: bytes) -> list[str]:
    texts: list[str] = []
    pos = 12
    while pos + 8 <= len(data):
        kind, size = data[pos:pos + 4], struct.unpack("<I", data[pos + 4:pos + 8])[0]
        body = data[pos + 8:pos + 8 + size]
        if kind == b"EXIF":
            texts += exif_texts(body[6:] if body.startswith(b"Exif\0\0") else body)
        elif kind == b"XMP ":
            texts += _xmp_texts(body)
        pos += 8 + size + (size & 1)
    return texts


# ---- prompt -> artists ---------------------------------------------------------------

def prompts_from_value(value) -> list[str]:
    """Positive prompt strings from a metadata value (JSON or plain text)."""
    if isinstance(value, str):
        stripped = value.strip()
        if stripped.startswith("{"):
            try:
                return prompts_from_value(json.loads(stripped))
            except ValueError:
                pass
        # A1111 "parameters": the positive prompt ends where "Negative prompt:" starts.
        return [re.split(r"\n\s*Negative prompt:", value, 1)[0]] if stripped else []
    if not isinstance(value, dict):
        return []
    prompts: list[str] = []
    for key in PROMPT_KEYS:
        if isinstance(value.get(key), str) and value[key].strip():
            prompts.append(value[key])
    caption = (value.get("v4_prompt") or {}).get("caption") if isinstance(value.get("v4_prompt"), dict) else None
    if isinstance(caption, dict):
        if isinstance(caption.get("base_caption"), str):
            prompts.append(caption["base_caption"])
        prompts += [c.get("char_caption", "") for c in caption.get("char_captions", []) if isinstance(c, dict)]
    if isinstance(value.get("Comment"), (str, dict)):  # stealth outer wrapper
        prompts += prompts_from_value(value["Comment"])
    return [prompt for prompt in prompts if prompt and prompt.strip()]


def _collect_metadata(data: bytes) -> tuple[bool, list[str]]:
    """(found any metadata, positive prompt candidates)."""
    if data.startswith(PNG_SIGNATURE):
        texts = png_text_chunks(data)
        prompts: list[str] = []
        for key in ("Comment", "Description", "parameters", "prompt"):
            if key in texts:
                prompts += prompts_from_value(texts[key])
        if prompts:
            return True, prompts
        stealth = png_stealth_metadata(data)
        if stealth:
            return True, prompts_from_value(stealth)
        return bool(texts), []
    if data.startswith(b"\xff\xd8"):
        texts = jpeg_texts(data)
    elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        texts = webp_texts(data)
    else:
        raise ValueError("unsupported")
    return bool(texts), [prompt for text in texts for prompt in prompts_from_value(text)]


def extract_artists_from_image(data: bytes) -> dict:
    """{"status", "message", "artists"}; never raises. Prompt text is not logged."""
    try:
        found, prompts = _collect_metadata(data)
    except ValueError as exc:
        status = "unsupported" if str(exc) == "unsupported" else "error"
        return {"status": status, "message": MESSAGES[status], "artists": []}
    except Exception:
        return {"status": "error", "message": MESSAGES["error"], "artists": []}
    if not found:
        return {"status": "no_metadata", "message": MESSAGES["no_metadata"], "artists": []}
    if not prompts:
        return {"status": "no_prompt", "message": MESSAGES["no_prompt"], "artists": []}
    artists: list[str] = []
    seen: set[str] = set()
    for prompt in prompts:
        for artist in extract_artist_tags(prompt):
            if artist["name"].casefold() not in seen:
                artists.append(artist["name"])
                seen.add(artist["name"].casefold())
    if not artists:
        return {"status": "no_artist", "message": MESSAGES["no_artist"], "artists": []}
    return {"status": "ok", "message": f"artist {len(artists)}명을 찾았습니다.", "artists": artists}

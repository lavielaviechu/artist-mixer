"""Keep outputs/ from growing forever.

Every generation job lives in ``outputs/<time>_<mode>_<id>/`` (``job.json`` + its images).
Recent History shows the newest 30 jobs by ``created_at``; older job folders are deleted
unless something still needs them:

* the 30 most recent jobs (same order as Recent History),
* unfinished jobs (pending / running / pausing / paused / stopping) and jobs the queue
  reports as active,
* saved combos: they reference ``/generated/<job folder>/...`` images and ``source_job_id``,
* Artist Library records that still point into ``/generated/`` (current records use their
  own copies under data/artist_library/, which this module never touches).

Only folders directly under outputs/ that contain a readable ``job.json`` are candidates;
anything else (unknown folders, broken metadata, symlinks) is left alone. Failures are
logged briefly and skipped.
"""
from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path
from typing import Callable, Iterable

from .storage import Storage


log = logging.getLogger(__name__)
KEEP_RECENT = 30
FINAL_STATUSES = {"completed", "completed_with_errors", "cancelled"}
GENERATED_PREFIX = "/generated/"


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


class ProtectionIndexUnavailable(Exception):
    """A saved-combo / Library index exists but cannot be trusted: nothing may be deleted."""


def _load_protection_index(path: Path, valid) -> object | None:
    """None when the file does not exist (first run). Unreadable, malformed or
    wrongly shaped files raise instead of being treated as "nothing to protect"."""
    try:
        if not path.exists():
            return None
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ProtectionIndexUnavailable(f"{path.name}: {exc.__class__.__name__}") from exc
    if not valid(value):
        raise ProtectionIndexUnavailable(f"{path.name}: unexpected format")
    return value


def _valid_saved_combos(value) -> bool:
    return isinstance(value, list) and all(isinstance(combo, dict) for combo in value)


def _valid_library(value) -> bool:
    artists = value.get("artists") if isinstance(value, dict) else None
    return isinstance(artists, dict) and all(
        isinstance(entry, dict) and isinstance(entry.get("images", []), list)
        and all(isinstance(image, dict) for image in entry.get("images", []))
        for entry in artists.values())


def job_order_key(job: dict) -> tuple:
    """The one Recent History order (newest first when sorted with reverse=True), shared by
    the queue (list / load_recent) and cleanup so both see the same "newest 30".
    created_at has second resolution; created_ts (newer jobs) and job_id break ties."""
    try:
        stamp = float(job.get("created_ts") or 0)
    except (TypeError, ValueError):
        stamp = 0.0
    return (str(job.get("created_at", "")), stamp, str(job.get("job_id", "")))


def job_folders(outputs_dir: Path, known_jobs: dict[str, dict] | None = None) -> list[tuple[Path, dict]]:
    """(folder, job) for every folder directly under outputs/ with a readable job.json.
    Jobs the queue already holds (by folder name) are taken from memory, so their job.json
    is not opened while the queue may be replacing it."""
    found = []
    try:
        candidates = list(outputs_dir.iterdir())
    except OSError:
        return []
    for folder in candidates:
        if not folder.is_dir() or folder.is_symlink():
            continue
        job = (known_jobs or {}).get(folder.name) or _read_json(folder / "job.json", None)
        if isinstance(job, dict) and job.get("job_id"):
            found.append((folder, job))
    found.sort(key=lambda entry: job_order_key(entry[1]), reverse=True)
    return found


def _folder_of(url: str) -> str | None:
    if not isinstance(url, str) or not url.startswith(GENERATED_PREFIX):
        return None
    return url[len(GENERATED_PREFIX):].split("/", 1)[0] or None


def protected_folders(storage: Storage, jobs: list[tuple[Path, dict]], keep: int,
                      active_job_ids: Iterable[str] = ()) -> dict[str, str]:
    """{folder name: reason} for every job folder that must stay."""
    active = set(active_job_ids)
    by_job_id = {job["job_id"]: folder.name for folder, job in jobs}
    protected: dict[str, str] = {}

    def protect(name: str | None, reason: str) -> None:
        if name and name not in protected:
            protected[name] = reason

    for folder, job in jobs[:keep]:
        protect(folder.name, "recent")
    for folder, job in jobs:
        if job.get("status") not in FINAL_STATUSES or job["job_id"] in active:
            protect(folder.name, "active")
    saved = _load_protection_index(storage.data_dir / "saved_combos.json", _valid_saved_combos) or []
    for combo in saved:
        protect(by_job_id.get(combo.get("source_job_id")), "saved_combo")
        for url in combo.get("images") or []:
            protect(_folder_of(url), "saved_combo")
    library = _load_protection_index(storage.data_dir / "artist_library.json", _valid_library) or {"artists": {}}
    for entry in library["artists"].values():
        for image in entry.get("images", []):
            protect(_folder_of(image.get("image_url")), "artist_library")
            if not image.get("file"):  # legacy record without its own copy
                protect(by_job_id.get(image.get("job_id")), "artist_library")
    return protected


def plan_cleanup(storage: Storage, keep: int = KEEP_RECENT, active_job_ids: Iterable[str] = (),
                 known_jobs: dict[str, dict] | None = None) -> dict:
    jobs = job_folders(storage.outputs_dir, known_jobs)
    protected = protected_folders(storage, jobs, keep, active_job_ids)
    delete = [(folder, job) for folder, job in jobs if folder.name not in protected]
    return {"jobs": jobs, "protected": protected, "delete": delete}


def _safe_target(outputs_dir: Path, folder: Path) -> bool:
    """Only an existing, non-symlink folder directly inside outputs/."""
    try:
        root = outputs_dir.resolve(strict=True)
        target = folder.resolve(strict=True)
    except OSError:
        return False
    return target.parent == root and target != root and not folder.is_symlink() and target.is_dir()


def _remove_job_folder(folder: Path, remove_tree: Callable) -> None:
    # job.json goes last, so a partial failure never leaves images without their metadata.
    for child in folder.iterdir():
        if child.name == "job.json":
            continue
        if child.is_dir() and not child.is_symlink():
            remove_tree(child)
        else:
            child.unlink(missing_ok=True)
    (folder / "job.json").unlink(missing_ok=True)
    folder.rmdir()


def cleanup_outputs(storage: Storage, keep: int = KEEP_RECENT, active_job_ids: Iterable[str] = (),
                    remove_tree: Callable = shutil.rmtree, known_jobs: dict[str, dict] | None = None) -> dict:
    """Delete old, unprotected job folders. Never raises."""
    result = {"deleted_job_ids": [], "deleted_folders": [], "failed": [], "protected": {}, "aborted": None}
    try:
        plan = plan_cleanup(storage, keep, active_job_ids, known_jobs)
    except ProtectionIndexUnavailable as exc:
        # Fail closed: if we cannot tell what saved combos / the Library still use, keep everything.
        result["aborted"] = f"protection index unavailable ({exc})"
        log.warning("Output cleanup aborted, nothing deleted: %s", exc)
        return result
    except Exception as exc:
        result["aborted"] = f"could not plan cleanup ({exc.__class__.__name__})"
        log.warning("Output cleanup aborted, nothing deleted: %s", exc.__class__.__name__)
        return result
    result["protected"] = plan["protected"]
    for folder, job in plan["delete"]:
        if not _safe_target(storage.outputs_dir, folder):
            result["failed"].append(folder.name)
            continue
        try:
            _remove_job_folder(folder, remove_tree)
        except FileNotFoundError:
            pass  # already gone
        except OSError as exc:
            result["failed"].append(folder.name)
            log.warning("Output cleanup: could not remove %s (%s)", folder.name, exc.__class__.__name__)
            continue
        result["deleted_job_ids"].append(job["job_id"])
        result["deleted_folders"].append(folder.name)
    if result["deleted_folders"] or result["failed"]:
        log.info("Output cleanup: removed %d old job folder(s), %d skipped",
                 len(result["deleted_folders"]), len(result["failed"]))
    return result

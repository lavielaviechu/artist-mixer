from __future__ import annotations

import asyncio
import hashlib
import logging
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Callable

from .artist_library import record_library_image
from .artist_mix import safe_folder_name
from .nai_client import NaiError, NovelAIClient
from .output_cleanup import FINAL_STATUSES, cleanup_outputs, job_order_key
from .storage import Storage


log = logging.getLogger(__name__)
RECENT_JOB_LIMIT = 30
PERSIST_ERROR = "작업 상태를 저장하지 못했습니다. 디스크 공간과 폴더 권한을 확인한 뒤 재개해 주세요."
RUNNER_ERROR = "예상하지 못한 오류로 작업을 일시정지했습니다. logs/app.log를 확인한 뒤 재개해 주세요."


class QueueManager:
    def __init__(self, storage: Storage, token_provider: Callable[[], str]):
        self.storage = storage
        self.token_provider = token_provider
        self.client = NovelAIClient()
        self.jobs: dict[str, dict] = {}
        self._runner: asyncio.Task | None = None
        self._wake = asyncio.Event()

    def load_recent(self) -> None:
        """Load the newest RECENT_JOB_LIMIT jobs (Recent History order) plus every unfinished
        job regardless of age, so it can still be resumed or stopped from the UI.

        output_folder is re-based to where job.json actually is now: a portable folder that
        was moved or copied never writes back to its old location."""
        found = []
        for path in self.storage.outputs_dir.glob("*/job.json"):
            try:
                job = self.storage.read_json_file(path)
            except Exception:
                continue
            if not isinstance(job, dict) or "job_id" not in job or not isinstance(job.get("items"), list):
                continue
            job["output_folder"] = str(path.parent)
            found.append(job)
        found.sort(key=job_order_key, reverse=True)
        for index, job in enumerate(found):
            unfinished = job.get("status") not in FINAL_STATUSES
            if index >= RECENT_JOB_LIMIT and not unfinished:
                continue
            if unfinished:
                self._recover_after_restart(job)
            self.jobs[job["job_id"]] = job

    def _recover_after_restart(self, job: dict) -> None:
        """No worker survives a restart, so nothing may stay "generating" and nothing resumes
        on its own:
        * stopping / stop_requested -> the stop is completed: unfinished items cancelled.
        * pending / running / pausing / paused (any other unfinished state) -> paused,
          generating items back to pending; the user resumes explicitly."""
        items = job.get("items", [])
        if job.get("status") == "stopping" or job.get("stop_requested"):
            for item in items:
                if item.get("status") in {"generating", "pending"}:
                    item["status"] = "cancelled"
            job["paused"] = False
            self._finalize_status(job)
            if job.get("status") not in FINAL_STATUSES:
                job["status"] = "cancelled"
        else:
            for item in items:
                if item.get("status") == "generating":
                    item["status"] = "pending"
            job["status"] = "paused"
            job["paused"] = True
        self._persist(job)

    async def start(self) -> None:
        if not self._runner or self._runner.done():
            self._runner = asyncio.create_task(self._run(), name="generation-queue")

    def _ensure_runner(self) -> None:
        """Restart the runner if it ever stopped unexpectedly (not after shutdown)."""
        if self._runner and self._runner.done() and not self._runner.cancelled():
            log.warning("Generation queue runner had stopped; restarting it")
            try:
                self._runner = asyncio.get_running_loop().create_task(self._run(), name="generation-queue")
            except RuntimeError:
                pass

    async def shutdown(self) -> None:
        if self._runner:
            self._runner.cancel()
            try:
                await self._runner
            except asyncio.CancelledError:
                pass

    def create_job(self, mode: str, items: list[dict], metadata: dict, groups: list[dict]) -> dict:
        now = datetime.now()
        job_id = uuid.uuid4().hex[:12]
        folder = self.storage.outputs_dir / f"{now:%Y-%m-%d_%H%M%S}_{mode}_{job_id[:4]}"
        folder.mkdir(parents=True, exist_ok=False)
        for item in items:
            item.update({
                "job_id": job_id,
                "status": "pending",
                "retry_count": 0,
                "error": None,
                "image_url": None,
            })
        job = {
            "job_id": job_id,
            "mode": mode,
            "created_at": now.isoformat(timespec="seconds"),
            "created_ts": time.time(),
            "updated_at": now.isoformat(timespec="seconds"),
            "status": "pending",
            "paused": False,
            "stop_requested": False,
            "output_folder": str(folder),
            "metadata": metadata,
            "groups": groups,
            "items": items,
        }
        # Written before the job is registered: a job that cannot be saved is never queued.
        self._write_group_metadata(job)
        job["updated_at"] = now.isoformat(timespec="seconds")
        self.storage.atomic_json(folder / "job.json", job)
        self.jobs[job_id] = job
        self._ensure_runner()
        self._wake.set()
        return self.public_job(job)

    def _write_group_metadata(self, job: dict) -> None:
        root = Path(job["output_folder"])
        used: set[str] = set()
        for group in job["groups"]:
            if job["mode"] == "random_mix" or job["mode"] == "saved_combo":
                dirname = f"combo_{int(group['combo_id']):03d}"
                filename = "combo.json"
            else:
                dirname = self._unique_artist_folder(group["artist_name"], used)
                filename = "artist.json"
            used.add(dirname.casefold())
            group["folder"] = dirname
            self.storage.atomic_json(root / dirname / filename, group)

    @staticmethod
    def _unique_artist_folder(name: str, used: set[str]) -> str:
        """Readable folder name; when two artists clean up to the same name (e.g. "a/b" and
        "a:b", case-only differences, or long names cut at 80 characters) a short stable
        hash of the full name keeps them apart. The UI shows group["artist_name"]."""
        base = safe_folder_name(name)
        if base.casefold() not in used:
            return base
        candidate = f"{base[:70]}_{hashlib.sha1(name.encode('utf-8')).hexdigest()[:8]}"
        counter = 2
        while candidate.casefold() in used:
            candidate = f"{base[:66]}_{hashlib.sha1(name.encode('utf-8')).hexdigest()[:8]}_{counter}"
            counter += 1
        return candidate

    def _persist(self, job: dict) -> bool:
        """Save job.json; never raises. A failure is kept on the job so the UI can say why."""
        job["updated_at"] = datetime.now().isoformat(timespec="seconds")
        try:
            self.storage.atomic_json(Path(job["output_folder"]) / "job.json", job)
        except Exception as exc:
            job["persist_error"] = PERSIST_ERROR
            log.warning("Could not save job %s: %s", job.get("job_id"), exc.__class__.__name__)
            return False
        if job.pop("persist_error", None):
            log.info("Job %s saved again", job.get("job_id"))
        return True

    def _summary(self, job: dict) -> dict:
        counts = {status: 0 for status in ("pending", "generating", "completed", "failed", "cancelled")}
        for item in job["items"]:
            counts[item["status"]] = counts.get(item["status"], 0) + 1
        return {"total": len(job["items"]), **counts}

    def public_job(self, job: dict, include_prompts: bool = True) -> dict:
        result = {k: v for k, v in job.items() if k != "output_folder"}
        result["output_folder_name"] = Path(job["output_folder"]).name
        result["summary"] = self._summary(job)
        if not include_prompts:
            result["items"] = [{k: v for k, v in item.items() if k not in {"final_prompt", "negative_prompt", "parameters"}} for item in job["items"]]
        return result

    def list_jobs(self) -> list[dict]:
        """Recent History: the newest RECENT_JOB_LIMIT jobs (same order cleanup uses) plus any
        older unfinished job, which stays reachable until it is resumed or stopped."""
        jobs = sorted(self.jobs.values(), key=job_order_key, reverse=True)
        shown = jobs[:RECENT_JOB_LIMIT] + [job for job in jobs[RECENT_JOB_LIMIT:] if job.get("status") not in FINAL_STATUSES]
        return [self.public_job(job, include_prompts=False) for job in shown]

    def get_job(self, job_id: str) -> dict | None:
        job = self.jobs.get(job_id)
        return self.public_job(job) if job else None

    def pause(self, job_id: str) -> dict:
        job = self._require(job_id)
        job["paused"] = True
        if job["status"] in {"pending", "running"}:
            job["status"] = "pausing" if any(i["status"] == "generating" for i in job["items"]) else "paused"
        self._persist(job)
        return self.public_job(job)

    def resume(self, job_id: str) -> dict:
        job = self._require(job_id)
        if job["status"] in FINAL_STATUSES:
            return self.public_job(job)
        job["paused"] = False
        job["stop_requested"] = False
        job["status"] = "pending"
        job.pop("error", None)
        self._persist(job)
        self._ensure_runner()
        self._wake.set()
        return self.public_job(job)

    def stop(self, job_id: str) -> dict:
        job = self._require(job_id)
        job["stop_requested"] = True
        for item in job["items"]:
            if item["status"] == "pending":
                item["status"] = "cancelled"
        job["status"] = "stopping" if any(i["status"] == "generating" for i in job["items"]) else "cancelled"
        self._persist(job)
        return self.public_job(job)

    def retry_failed(self, job_id: str) -> dict:
        job = self._require(job_id)
        changed = False
        for item in job["items"]:
            if item["status"] == "failed":
                item["status"] = "pending"
                item["error"] = None
                item["retry_count"] = 0
                changed = True
        if changed:
            job["paused"] = False
            job["stop_requested"] = False
            job["status"] = "pending"
            self._persist(job)
            self._ensure_runner()
            self._wake.set()
        return self.public_job(job)

    def _require(self, job_id: str) -> dict:
        if job_id not in self.jobs:
            raise KeyError(job_id)
        return self.jobs[job_id]

    async def _run(self) -> None:
        while True:
            try:
                worked = await self._run_once()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Generation queue error; continuing")
                await asyncio.sleep(1.0)  # never spin on a repeating failure
                continue
            if not worked:
                self._wake.clear()
                await self._wake.wait()

    async def _run_once(self) -> bool:
        for job in list(self.jobs.values()):
            if job.get("paused") or job.get("stop_requested"):
                continue
            item = next((i for i in job["items"] if i["status"] == "pending"), None)
            if not item:
                self._finalize_status(job)
                continue
            try:
                await self._process(job, item)
            except asyncio.CancelledError:
                raise
            except Exception:
                # Pause this job instead of retrying it forever.
                log.exception("Unexpected error while processing job %s", job.get("job_id"))
                if item.get("status") == "generating":
                    item["status"] = "pending"
                job.update(status="paused", paused=True, error=RUNNER_ERROR)
                self._persist(job)
                await asyncio.sleep(0.2)
            return True
        return False

    async def _process(self, job: dict, item: dict) -> None:
        job["status"] = "running"
        item["status"] = "generating"
        if not self._persist(job):
            # Keep memory equal to what is on disk and do not spend an API call.
            item["status"] = "pending"
            job.update(status="paused", paused=True, error=PERSIST_ERROR)
            return
        job.pop("error", None)
        try:
            image = await self.client.generate_with_retry(
                self.token_provider(), item, int(job["metadata"].get("max_retries", 2))
            )
            group = next(g for g in job["groups"] if g["group_key"] == item["group_key"])
            group_items = [i for i in job["items"] if i["group_key"] == item["group_key"]]
            image_number = group_items.index(item) + 1
            output = Path(job["output_folder"]) / group["folder"] / f"{image_number:03d}.png"
            self.storage.write_bytes(output, image)
            item["image_url"] = self.storage.public_path(output)
            item["status"] = "completed"
            if job["mode"] == "artist_library":
                record_library_image(self.storage, job, group, item)
        except NaiError as exc:
            item["status"] = "failed"
            item["error"] = str(exc)
            log.warning("Image generation failed: status=%s message=%s", exc.status_code, str(exc))
        except Exception:
            item["status"] = "failed"
            item["error"] = "예상하지 못한 오류가 발생했습니다. logs/app.log를 확인해 주세요."
            log.exception("Unexpected queue error")
        if job.get("stop_requested"):
            job["status"] = "cancelled"
        elif job.get("paused"):
            job["status"] = "paused"
        else:
            self._finalize_status(job)
        self._persist(job)
        if job["status"] in FINAL_STATUSES:  # the job just finished (it was "running" above)
            await self.cleanup_outputs()

    async def cleanup_outputs(self) -> dict:
        """Remove old job folders beyond Recent History (see output_cleanup). Never raises,
        so generation is never interrupted by it. It runs on the event loop, between queue
        steps: on Windows a job.json opened by another thread could not be replaced by
        _persist, so cleanup must not overlap the queue's own writes."""
        active = [job_id for job_id, job in self.jobs.items() if job.get("status") not in FINAL_STATUSES]
        known = {Path(job["output_folder"]).name: job for job in self.jobs.values() if job.get("output_folder")}
        try:
            result = cleanup_outputs(self.storage, RECENT_JOB_LIMIT, active, known_jobs=known)
        except Exception:
            log.warning("Output cleanup failed; skipped")
            return {"deleted_job_ids": [], "deleted_folders": [], "failed": [], "protected": {}}
        for job_id in result["deleted_job_ids"]:
            self.jobs.pop(job_id, None)
        return result

    def _finalize_status(self, job: dict) -> None:
        statuses = {i["status"] for i in job["items"]}
        if "pending" in statuses or "generating" in statuses:
            return
        if statuses <= {"cancelled"}:
            job["status"] = "cancelled"
        elif "failed" in statuses:
            job["status"] = "completed_with_errors"
        else:
            job["status"] = "completed"

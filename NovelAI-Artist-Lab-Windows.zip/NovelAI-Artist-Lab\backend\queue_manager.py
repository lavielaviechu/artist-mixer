from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Callable

from .artist_mix import safe_folder_name
from .nai_client import NaiError, NovelAIClient
from .storage import Storage


log = logging.getLogger(__name__)
RECENT_JOB_LIMIT = 30


class QueueManager:
    def __init__(self, storage: Storage, token_provider: Callable[[], str]):
        self.storage = storage
        self.token_provider = token_provider
        self.client = NovelAIClient()
        self.jobs: dict[str, dict] = {}
        self._runner: asyncio.Task | None = None
        self._wake = asyncio.Event()

    def load_recent(self) -> None:
        for path in sorted(self.storage.outputs_dir.glob("*/job.json"), reverse=True)[:RECENT_JOB_LIMIT]:
            try:
                job = self.storage.read_json_file(path)
            except Exception:
                continue
            if not isinstance(job, dict) or "job_id" not in job:
                continue
            if job.get("status") in {"running", "pending", "pausing"}:
                job["status"] = "paused"
                job["paused"] = True
                for item in job.get("items", []):
                    if item.get("status") == "generating":
                        item["status"] = "pending"
            self.jobs[job["job_id"]] = job

    async def start(self) -> None:
        if not self._runner or self._runner.done():
            self._runner = asyncio.create_task(self._run(), name="generation-queue")

    async def shutdown(self) -> None:
        if self._runner:
            self._runner.cancel()
            try:
                await self._runner
            except asyncio.CancelledError:
                pass

    def create_job(self, mode: str, items: list[dict], metadata: dict, groups: list[dict]) -> dict:
        now = datetime.now()
        job_id = uuid.uuid4().hex[:12]
        folder = self.storage.outputs_dir / f"{now:%Y-%m-%d_%H%M%S}_{mode}_{job_id[:4]}"
        folder.mkdir(parents=True, exist_ok=False)
        for item in items:
            item.update({
                "job_id": job_id,
                "status": "pending",
                "retry_count": 0,
                "error": None,
                "image_url": None,
            })
        job = {
            "job_id": job_id,
            "mode": mode,
            "created_at": now.isoformat(timespec="seconds"),
            "updated_at": now.isoformat(timespec="seconds"),
            "status": "pending",
            "paused": False,
            "stop_requested": False,
            "output_folder": str(folder),
            "metadata": metadata,
            "groups": groups,
            "items": items,
        }
        self.jobs[job_id] = job
        self._write_group_metadata(job)
        self._persist(job)
        self._wake.set()
        return self.public_job(job)

    def _write_group_metadata(self, job: dict) -> None:
        root = Path(job["output_folder"])
        for group in job["groups"]:
            if job["mode"] == "random_mix" or job["mode"] == "saved_combo":
                dirname = f"combo_{int(group['combo_id']):03d}"
                filename = "combo.json"
            else:
                dirname = safe_folder_name(group["artist_name"])
                filename = "artist.json"
            group["folder"] = dirname
            self.storage.atomic_json(root / dirname / filename, group)

    def _persist(self, job: dict) -> None:
        job["updated_at"] = datetime.now().isoformat(timespec="seconds")
        self.storage.atomic_json(Path(job["output_folder"]) / "job.json", job)

    def _summary(self, job: dict) -> dict:
        counts = {status: 0 for status in ("pending", "generating", "completed", "failed", "cancelled")}
        for item in job["items"]:
            counts[item["status"]] = counts.get(item["status"], 0) + 1
        return {"total": len(job["items"]), **counts}

    def public_job(self, job: dict, include_prompts: bool = True) -> dict:
        result = {k: v for k, v in job.items() if k != "output_folder"}
        result["output_folder_name"] = Path(job["output_folder"]).name
        result["summary"] = self._summary(job)
        if not include_prompts:
            result["items"] = [{k: v for k, v in item.items() if k not in {"final_prompt", "negative_prompt", "parameters"}} for item in job["items"]]
        return result

    def list_jobs(self) -> list[dict]:
        jobs = sorted(self.jobs.values(), key=lambda value: value.get("created_at", ""), reverse=True)
        return [self.public_job(job, include_prompts=False) for job in jobs[:RECENT_JOB_LIMIT]]

    def get_job(self, job_id: str) -> dict | None:
        job = self.jobs.get(job_id)
        return self.public_job(job) if job else None

    def pause(self, job_id: str) -> dict:
        job = self._require(job_id)
        job["paused"] = True
        if job["status"] in {"pending", "running"}:
            job["status"] = "pausing" if any(i["status"] == "generating" for i in job["items"]) else "paused"
        self._persist(job)
        return self.public_job(job)

    def resume(self, job_id: str) -> dict:
        job = self._require(job_id)
        if job["status"] in {"completed", "cancelled"}:
            return self.public_job(job)
        job["paused"] = False
        job["stop_requested"] = False
        job["status"] = "pending"
        self._persist(job)
        self._wake.set()
        return self.public_job(job)

    def stop(self, job_id: str) -> dict:
        job = self._require(job_id)
        job["stop_requested"] = True
        for item in job["items"]:
            if item["status"] == "pending":
                item["status"] = "cancelled"
        job["status"] = "stopping" if any(i["status"] == "generating" for i in job["items"]) else "cancelled"
        self._persist(job)
        return self.public_job(job)

    def retry_failed(self, job_id: str) -> dict:
        job = self._require(job_id)
        changed = False
        for item in job["items"]:
            if item["status"] == "failed":
                item["status"] = "pending"
                item["error"] = None
                item["retry_count"] = 0
                changed = True
        if changed:
            job["paused"] = False
            job["stop_requested"] = False
            job["status"] = "pending"
            self._persist(job)
            self._wake.set()
        return self.public_job(job)

    def _require(self, job_id: str) -> dict:
        if job_id not in self.jobs:
            raise KeyError(job_id)
        return self.jobs[job_id]

    async def _run(self) -> None:
        while True:
            worked = False
            for job in list(self.jobs.values()):
                if job.get("paused") or job.get("stop_requested"):
                    continue
                item = next((i for i in job["items"] if i["status"] == "pending"), None)
                if not item:
                    self._finalize_status(job)
                    continue
                worked = True
                await self._process(job, item)
                break
            if not worked:
                self._wake.clear()
                await self._wake.wait()

    async def _process(self, job: dict, item: dict) -> None:
        job["status"] = "running"
        item["status"] = "generating"
        self._persist(job)
        try:
            image = await self.client.generate_with_retry(
                self.token_provider(), item, int(job["metadata"].get("max_retries", 2))
            )
            group = next(g for g in job["groups"] if g["group_key"] == item["group_key"])
            group_items = [i for i in job["items"] if i["group_key"] == item["group_key"]]
            image_number = group_items.index(item) + 1
            output = Path(job["output_folder"]) / group["folder"] / f"{image_number:03d}.png"
            self.storage.write_bytes(output, image)
            item["image_url"] = self.storage.public_path(output)
            item["status"] = "completed"
        except NaiError as exc:
            item["status"] = "failed"
            item["error"] = str(exc)
            log.warning("Image generation failed: status=%s message=%s", exc.status_code, str(exc))
        except Exception:
            item["status"] = "failed"
            item["error"] = "예상하지 못한 오류가 발생했습니다. logs/app.log를 확인해 주세요."
            log.exception("Unexpected queue error")
        if job.get("stop_requested"):
            job["status"] = "cancelled"
        elif job.get("paused"):
            job["status"] = "paused"
        else:
            self._finalize_status(job)
        self._persist(job)

    def _finalize_status(self, job: dict) -> None:
        statuses = {i["status"] for i in job["items"]}
        if "pending" in statuses or "generating" in statuses:
            return
        if statuses <= {"cancelled"}:
            job["status"] = "cancelled"
        elif "failed" in statuses:
            job["status"] = "completed_with_errors"
        else:
            job["status"] = "completed"

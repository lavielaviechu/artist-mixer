# NovelAI Artist Lab

Windows localhost에서 여러 NovelAI artist tag를 같은 조건으로 비교하고, 결정적으로 재현 가능한 랜덤 artist mix를 만들어 일괄 생성하는 개인용 도구입니다.

## 일반 사용자 실행 (Windows portable release)

1. `NovelAI-Artist-Lab-Windows.zip`을 원하는 폴더에 완전히 압축 해제합니다.
2. `run.bat`을 더블클릭합니다.
3. 브라우저가 `http://127.0.0.1:8766`을 자동으로 엽니다.
4. NovelAI Persistent API token과 Artist Pool을 입력합니다.

Python 설치, PATH 설정, pip 명령 또는 인터넷을 통한 패키지 설치가 필요하지 않습니다. 서버는 `127.0.0.1`에만 바인딩됩니다. BAT 창을 닫거나 우측 상단 **앱 종료**를 누르면 종료됩니다. 이미지 생성 시에는 NovelAI API 연결을 위한 인터넷이 필요합니다.

## 주요 사용 기능

- Positive Prompt에 기존 NovelAI prompt를 그대로 붙여넣으면 `artist:` tag를 감지해 단일 작가 비교 대상으로 보여줍니다.
- Artist Pool은 검색 가능한 compact 목록이며, 활성·즐겨찾기·MIX·고정 포함 상태와 작가별 weight 규칙을 자동 저장합니다.
- 공통 생성 설정의 **Character Prompt**에는 한 캐릭터의 외형·의상·표정 prompt를 입력할 수 있습니다. 값이 있으면 NovelAI v4 character caption 형식으로 API 요청에 포함됩니다.
- 출력 artist tag는 항상 `1.0::artist:이름 ::` 형식으로 생성됩니다.
- Positive Prompt에 `{{ARTIST_BLOCK}}`(artist 조합)과 `{{STYLE_BLOCK}}`(화풍 태그)을 넣을 수 있습니다. 에디터의 **+ Artist Block / + Style Block** 버튼이 커서 위치에 삽입합니다. 기존 `{{ARTISTS}}`는 `{{ARTIST_BLOCK}}`과 같게 처리됩니다. placeholder가 없으면 블록별로 설정한 위치(맨 앞/맨 뒤)에 자동 삽입되고, 꺼진 블록의 placeholder는 제거됩니다.
- **Style Pool**은 스타일 / 매체 / 선화 / 채색·색감 / 사용자 추가 카테고리로 나뉩니다. ☑ 필수 포함 태그는 항상 들어가고, 여기에 카테고리별 RND 추가 개수만큼 **RND** 후보에서 중복 없이 뽑아 더합니다. 카테고리를 끄면 해당 태그가 모두 빠지며(설정은 유지), ⋯ 에서 태그별 weight(없음 / 전역 범위 / 고정 / 개별 범위)를 정합니다. 처음 실행 시 각 카테고리에서 태그 1개를 무작위로 필수 체크해 저장하고(채색·색감 카테고리는 기본 OFF), 이후에는 **기본 조합 랜덤 생성**을 누를 때만 다시 뽑습니다. Style Block은 Combo마다(단일 작가 테스트는 작업마다) 한 번 확정되어 그 안의 모든 이미지에 동일하게 쓰입니다.
- **최근 기록**에는 저장된 조합과 별개로 최근 생성 작업 80개가 유지되며, 앱을 다시 실행한 뒤에도 결과를 다시 열 수 있습니다.
- 이미지 크기는 NovelAI 명칭을 따라 `Portrait / Landscape / Square`의 Normal 및 Large 프리셋을 제공합니다.

정상 portable release에는 다음 구조가 포함됩니다.

```text
NovelAI-Artist-Lab/
  run.bat
  app.py
  python/python.exe
  python/python311.zip
  python/Lib/site-packages/
  backend/
  static/
  LICENSES/
```

## Portable release 빌드

Windows PowerShell에서 `build_portable.bat`을 실행합니다. 빌드 스크립트는 공식 Python 3.11.9 Windows x64 embeddable runtime을 받고, 고정된 애플리케이션 의존성을 내부 `python/Lib/site-packages`에 설치한 다음 import와 localhost HTTP 응답을 검증합니다.

완성물:

```text
_dist/NovelAI-Artist-Lab/
_dist/NovelAI-Artist-Lab-Windows.zip
```

개발 저장소에는 Python 바이너리나 `_dist` 결과를 커밋하지 않습니다. 첫 배포 빌드에는 Python runtime과 PyPI wheel 다운로드를 위한 인터넷 연결이 필요합니다.

## 데이터 위치

- 설정과 Artist Pool: `data/` (Style Pool은 `data/style_pool.json`, Block 설정은 `data/settings.json`)
- 기억한 토큰: `data/secrets.json` (평문, Git 제외)
- 생성 결과와 작업 metadata: `outputs/<작업 폴더>/`
- 오류 상세: `logs/app.log`

`data/`, 생성 결과, 로그, 토큰은 Git에서 제외됩니다. 결과 파일은 임시 파일에 먼저 쓴 뒤 원자적으로 교체합니다.

## 개발 테스트

```powershell
py -3 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m pytest
```

NovelAI API 요청은 `backend/nai_client.py`에 격리되어 있습니다. 모델 API가 바뀌면 이 모듈의 payload 생성만 조정하면 됩니다.

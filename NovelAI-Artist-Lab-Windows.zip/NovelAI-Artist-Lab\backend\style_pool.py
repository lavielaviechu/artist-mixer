"""Style Pool: categorized style tags used to build the Style Block.

Stored in data/style_pool.json as::

    {
      "version": 2,
      "categories": [{"id", "name", "enabled", "rnd_min", "rnd_max"}, ...],
      "weight_range": {"min", "max", "step"},
      "tags": [{"tag", "category", "required", "rnd", "default_random_eligible",
                "weight_mode", "weight", "weight_min", "weight_max"}, ...]
    }

Per enabled category a Style Block holds every ``required`` tag plus a random
pick of ``rnd_min``..``rnd_max`` tags among the non-required ``rnd`` tags.
``default_random_eligible`` is only used when (re)creating the default
required selection.
"""
from __future__ import annotations

import copy
import random
import re
from decimal import Decimal
from typing import Iterable

from .artist_mix import MixValidationError, format_weight


STYLE_POOL_VERSION = 2
CUSTOM_CATEGORY = "custom"
WEIGHT_MODES = {"none", "global", "fixed", "range"}

DEFAULT_CATEGORIES = [
    {"id": "style", "name": "스타일", "enabled": True, "rnd_min": 0, "rnd_max": 1},
    {"id": "medium", "name": "매체", "enabled": True, "rnd_min": 0, "rnd_max": 1},
    {"id": "lineart", "name": "선화", "enabled": True, "rnd_min": 0, "rnd_max": 1},
    {"id": "color", "name": "채색/색감", "enabled": False, "rnd_min": 0, "rnd_max": 2},
    {"id": CUSTOM_CATEGORY, "name": "사용자 추가", "enabled": True, "rnd_min": 0, "rnd_max": 1},
]
DEFAULT_WEIGHT_RANGE = {"min": -1.0, "max": 1.0, "step": 0.1}

# (category, tag, default_random_eligible)
DEFAULT_TAGS: list[tuple[str, str, bool]] = [
    *[("style", tag, True) for tag in (
        "realistic", "semi-realistic", "photorealistic", "painterly", "anime coloring",
        "novel illustration", "ligne claire", "tegaki",
    )],
    ("style", "pop art", False),
    ("style", "art nouveau", True),
    ("style", "nihonga", True),
    ("style", "pixel art", False),
    *[("medium", tag, True) for tag in (
        "acrylic paint (medium)", "oil painting (medium)", "painting (medium)", "watercolor (medium)",
        "watercolor pencil (medium)", "pastel (medium)", "marker (medium)", "graphite (medium)",
        "colored pencil (medium)", "ink (medium)", "ballpoint pen (medium)", "millipen (medium)",
        "pen (medium)", "nib pen (medium)", "calligraphy brush (medium)",
    )],
    *[("lineart", tag, True) for tag in (
        "lineart", "no lineart", "thick lineart", "rough lineart", "jaggy lines", "sketch",
    )],
    *[("color", tag, True) for tag in (
        "muted color", "flat color", "colorful", "saturated", "spot color", "limited palette",
        "greyscale", "monochrome", "partially colored", "high contrast", "pastel color",
    )],
]
_DEFAULT_TAG_INDEX = {tag.casefold(): (category, eligible) for category, tag, eligible in DEFAULT_TAGS}

# Optional NovelAI weight syntax per line: "0.8::thin lineart ::".
_WEIGHTED_STYLE_RE = re.compile(r"^(?P<weight>[+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*::\s*(?P<tag>.+?)\s*::$")


# ---- text input -------------------------------------------------------------------

def parse_style_line(raw: str) -> tuple[str, float | None]:
    value = str(raw).strip()
    match = _WEIGHTED_STYLE_RE.match(value)
    if match:
        return match.group("tag").strip(), float(match.group("weight"))
    return value, None


def normalize_style_lines(values: str | Iterable[str]) -> list[dict]:
    """One tag per line: trims, drops blank lines and case-insensitive duplicates."""
    lines = values.splitlines() if isinstance(values, str) else values
    result: list[dict] = []
    seen: set[str] = set()
    for raw in lines:
        tag, weight = parse_style_line(raw)
        key = tag.casefold()
        if tag and key not in seen:
            result.append({"tag": tag, "weight": weight})
            seen.add(key)
    return result


# ---- formatting -------------------------------------------------------------------

def format_style_weight(weight: float) -> str:
    text = format_weight(weight, 2).rstrip("0")
    return text + "0" if text.endswith(".") else text


def format_style_tag(tag: str, weight: float | None = None) -> str:
    # Same NovelAI syntax as artist tags: a space stays before the closing "::".
    return tag if weight is None else f"{format_style_weight(weight)}::{tag} ::"


def format_style_block(tags: list[dict]) -> str:
    return ", ".join(format_style_tag(item["tag"], item.get("weight")) for item in tags)


# ---- records ----------------------------------------------------------------------

def _float_or_none(value) -> float | None:
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _int(value, default: int) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def make_style_tag(tag: str, category: str = CUSTOM_CATEGORY, **fields) -> dict:
    default = _DEFAULT_TAG_INDEX.get(tag.casefold())
    record = {
        "tag": tag,
        "category": category,
        "required": False,
        "rnd": False,
        "default_random_eligible": default[1] if default else True,
        "weight_mode": "none",
        "weight": None,
        "weight_min": None,
        "weight_max": None,
    }
    record.update(fields)
    return normalize_style_tag(record)


def normalize_style_tag(record: dict, category_ids: set[str] | None = None) -> dict:
    tag, parsed_weight = parse_style_line(str(record.get("tag", "")))
    category = str(record.get("category") or CUSTOM_CATEGORY)
    if category_ids is not None and category not in category_ids:
        category = CUSTOM_CATEGORY
    weight = _float_or_none(record.get("weight", parsed_weight))
    if weight is None:
        weight = parsed_weight
    mode = record.get("weight_mode")
    if mode not in WEIGHT_MODES:
        mode = "fixed" if weight is not None else "none"
    return {
        "tag": tag,
        "category": category,
        "required": bool(record.get("required", False)),
        "rnd": bool(record.get("rnd", False)),
        "default_random_eligible": bool(record.get("default_random_eligible", True)),
        "weight_mode": mode,
        "weight": weight,
        "weight_min": _float_or_none(record.get("weight_min")),
        "weight_max": _float_or_none(record.get("weight_max")),
    }


def _normalize_categories(raw: Iterable[dict] | None) -> list[dict]:
    given = {str(item.get("id")): item for item in raw or [] if isinstance(item, dict) and item.get("id")}
    result = []
    for default in DEFAULT_CATEGORIES:
        source = {**default, **given.pop(default["id"], {})}
        result.append(_category(source, default))
    for item in given.values():  # user-defined categories are kept as-is
        result.append(_category(item, {"name": str(item["id"]), "enabled": True, "rnd_min": 0, "rnd_max": 1}))
    return result


def _category(source: dict, default: dict) -> dict:
    rnd_min = _int(source.get("rnd_min"), default["rnd_min"])
    rnd_max = max(rnd_min, _int(source.get("rnd_max"), default["rnd_max"]))
    return {"id": str(source["id"]), "name": str(source.get("name") or default["name"]),
            "enabled": bool(source.get("enabled", default["enabled"])), "rnd_min": rnd_min, "rnd_max": rnd_max}


def normalize_weight_range(raw: dict | None) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    minimum = _float_or_none(raw.get("min"))
    maximum = _float_or_none(raw.get("max"))
    step = _float_or_none(raw.get("step"))
    minimum = DEFAULT_WEIGHT_RANGE["min"] if minimum is None else minimum
    maximum = DEFAULT_WEIGHT_RANGE["max"] if maximum is None else maximum
    step = DEFAULT_WEIGHT_RANGE["step"] if step is None or step <= 0 else step
    if minimum > maximum:
        minimum, maximum = maximum, minimum
    return {"min": minimum, "max": maximum, "step": step}


def _dedupe_tags(records: Iterable[dict], category_ids: set[str]) -> list[dict]:
    result, seen = [], set()
    for record in records:
        if not isinstance(record, dict):
            continue
        tag = normalize_style_tag(record, category_ids)
        key = tag["tag"].casefold()
        if tag["tag"] and key not in seen:
            result.append(tag)
            seen.add(key)
    return result


# ---- default pool / randomized default selection ----------------------------------

def randomize_default_selection(pool: dict, rng: random.Random) -> dict:
    """Clear required checks, then check exactly one default-eligible tag per built-in
    category, and restore built-in category ON/OFF defaults."""
    pool = copy.deepcopy(pool)
    defaults = {category["id"]: category for category in DEFAULT_CATEGORIES}
    for category in pool["categories"]:
        if category["id"] in defaults and category["id"] != CUSTOM_CATEGORY:
            category["enabled"] = defaults[category["id"]]["enabled"]
    for tag in pool["tags"]:
        tag["required"] = False
    for category in DEFAULT_CATEGORIES:
        if category["id"] == CUSTOM_CATEGORY:
            continue
        eligible = [tag for tag in pool["tags"] if tag["category"] == category["id"] and tag["default_random_eligible"]]
        if eligible:
            rng.choice(eligible)["required"] = True
    return pool


def default_style_pool(rng: random.Random) -> dict:
    pool = {
        "version": STYLE_POOL_VERSION,
        "categories": _normalize_categories(None),
        "weight_range": dict(DEFAULT_WEIGHT_RANGE),
        "tags": [make_style_tag(tag, category, default_random_eligible=eligible) for category, tag, eligible in DEFAULT_TAGS],
    }
    return randomize_default_selection(pool, rng)


# ---- migration --------------------------------------------------------------------

def _legacy_tag(record: dict | str, style_mode: str) -> dict | None:
    source = {"tag": record} if isinstance(record, str) else dict(record)
    tag, parsed_weight = parse_style_line(str(source.get("tag", source.get("name", ""))))
    if not tag:
        return None
    enabled = bool(source.get("enabled", True))
    fixed = bool(source.get("fixed_include", False))
    random_enabled = bool(source.get("random_enabled", True))
    weight = _float_or_none(source.get("weight", parsed_weight))
    default = _DEFAULT_TAG_INDEX.get(tag.casefold())
    return make_style_tag(
        tag, default[0] if default else CUSTOM_CATEGORY,
        # v1 "fixed include" == v2 "required"; v1 "all active tags" mode used every enabled tag.
        required=fixed or (style_mode == "all" and enabled),
        rnd=enabled and random_enabled and not fixed,
        weight_mode="fixed" if weight is not None else "none",
        weight=weight,
    )


def migrate_style_pool(raw, legacy_settings: dict | None = None) -> dict:
    """Return a v2 pool. ``raw`` must not be None (a missing file is a fresh install)."""
    if isinstance(raw, dict) and raw.get("version") == STYLE_POOL_VERSION:
        categories = _normalize_categories(raw.get("categories"))
        category_ids = {category["id"] for category in categories}
        return {
            "version": STYLE_POOL_VERSION,
            "categories": categories,
            "weight_range": normalize_weight_range(raw.get("weight_range")),
            "tags": _dedupe_tags(raw.get("tags") or [], category_ids),
        }

    # v1: a flat list of {tag, enabled, random_enabled, fixed_include, weight}.
    settings = legacy_settings if isinstance(legacy_settings, dict) else {}
    style_mode = settings.get("style_mode", "random")
    legacy = [_legacy_tag(record, style_mode) for record in (raw if isinstance(raw, list) else [])
              if isinstance(record, (dict, str))]
    categories = _normalize_categories(None)
    category_ids = {category["id"] for category in categories}
    tags = _dedupe_tags([tag for tag in legacy if tag], category_ids)
    # Keep the old total-count setting for the user's own tags; v1 counts included fixed tags.
    custom_fixed = sum(1 for tag in tags if tag["category"] == CUSTOM_CATEGORY and tag["required"])
    custom = next(category for category in categories if category["id"] == CUSTOM_CATEGORY)
    custom["rnd_min"] = max(0, _int(settings.get("style_min"), 1) - custom_fixed)
    custom["rnd_max"] = max(custom["rnd_min"], _int(settings.get("style_max"), 3) - custom_fixed)
    # Add built-in tags the user does not have yet, unchecked (no random default selection).
    present = {tag["tag"].casefold() for tag in tags}
    tags += [make_style_tag(tag, category, default_random_eligible=eligible)
             for category, tag, eligible in DEFAULT_TAGS if tag.casefold() not in present]
    return {"version": STYLE_POOL_VERSION, "categories": categories,
            "weight_range": dict(DEFAULT_WEIGHT_RANGE), "tags": tags}


# ---- Style Block generation -------------------------------------------------------

def _step_decimals(step: float) -> int:
    exponent = Decimal(str(step)).normalize().as_tuple().exponent
    return max(0, -int(exponent))


def _random_step_weight(rng: random.Random, minimum: float, maximum: float, step: float) -> float:
    if minimum > maximum:
        minimum, maximum = maximum, minimum
    count = int(round((maximum - minimum) / step + 1e-9))
    return round(minimum + rng.randint(0, count) * step, _step_decimals(step))


def resolve_style_weight(tag: dict, rng: random.Random, weight_range: dict) -> float | None:
    mode = tag.get("weight_mode", "none")
    if mode == "fixed":
        return tag.get("weight")
    if mode == "global":
        return _random_step_weight(rng, weight_range["min"], weight_range["max"], weight_range["step"])
    if mode == "range":
        minimum = tag.get("weight_min") if tag.get("weight_min") is not None else weight_range["min"]
        maximum = tag.get("weight_max") if tag.get("weight_max") is not None else weight_range["max"]
        return _random_step_weight(rng, minimum, maximum, weight_range["step"])
    return None


def style_block_candidates(pool: dict) -> int:
    """How many tags could ever appear (required + RND) in enabled categories."""
    enabled = {category["id"] for category in pool["categories"] if category["enabled"]}
    return sum(1 for tag in pool["tags"] if tag["category"] in enabled and (tag["required"] or tag["rnd"]))


def generate_style_tags(pool: dict, rng: random.Random) -> list[dict]:
    """Required tags of every enabled category, then that category's random RND picks."""
    pool = migrate_style_pool(pool)
    result: list[dict] = []
    for category in pool["categories"]:
        tags = [tag for tag in pool["tags"] if tag["category"] == category["id"]]
        required = [tag for tag in tags if tag["required"]]
        candidates = [tag for tag in tags if tag["rnd"] and not tag["required"]]
        # Always consume the RNG the same way so toggling one category does not
        # reshuffle the picks of the others for the same seed.
        low = min(category["rnd_min"], len(candidates))
        high = min(category["rnd_max"], len(candidates))
        count = rng.randint(low, high) if high >= low else 0
        picked_ids = {id(tag) for tag in rng.sample(candidates, count)}
        picked = [tag for tag in candidates if id(tag) in picked_ids]
        weights = [resolve_style_weight(tag, rng, pool["weight_range"]) for tag in required + picked]
        if category["enabled"]:
            result += [{"tag": tag["tag"], "weight": weight} for tag, weight in zip(required + picked, weights)]
    return result


def generate_style_block(pool: dict, rng: random.Random) -> dict:
    tags = generate_style_tags(pool, rng)
    return {"style_tags": tags, "style_block": format_style_block(tags)}


def validate_style_pool(pool: dict) -> None:
    if not style_block_candidates(pool):
        raise MixValidationError("Style Block이 켜져 있지만 켜진 카테고리에 필수 포함(☑) 또는 RND 태그가 없습니다.")

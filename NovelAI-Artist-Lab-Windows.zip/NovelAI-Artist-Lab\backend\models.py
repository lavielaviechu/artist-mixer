from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field, model_validator


class ArtistRecord(BaseModel):
    name: str
    enabled: bool = True
    favorite: bool = False
    excluded: bool = False
    mix_enabled: bool = True
    fixed_include: bool = False
    weight_mode: Literal["global", "fixed", "range"] = "global"
    fixed_weight: float | None = None
    weight_min: float | None = None
    weight_max: float | None = None


class ArtistPoolUpdate(BaseModel):
    text: str


class ArtistPatch(BaseModel):
    enabled: bool | None = None
    favorite: bool | None = None
    excluded: bool | None = None
    mix_enabled: bool | None = None
    fixed_include: bool | None = None
    weight_mode: Literal["global", "fixed", "range"] | None = None
    fixed_weight: float | None = None
    weight_min: float | None = None
    weight_max: float | None = None


class ArtistBulkUpdate(BaseModel):
    action: Literal["enable_all", "disable_all", "mix_include", "mix_exclude"]
    names: list[str] = Field(default_factory=list)


class StylePoolUpdate(BaseModel):
    text: str
    category: str = "custom"


class StyleTagPatch(BaseModel):
    required: bool | None = None
    rnd: bool | None = None
    category: str | None = None
    default_random_eligible: bool | None = None
    weight_mode: Literal["none", "global", "fixed", "range"] | None = None
    weight: float | None = None
    weight_min: float | None = None
    weight_max: float | None = None


class StyleCategoryPatch(BaseModel):
    enabled: bool | None = None
    rnd_min: int | None = Field(None, ge=0, le=50)
    rnd_max: int | None = Field(None, ge=0, le=50)


class StyleBulkUpdate(BaseModel):
    action: Literal["check_all", "uncheck_all"]
    category: str | None = None  # None = every category


class StyleWeightRange(BaseModel):
    min: float = -1.0
    max: float = 1.0
    step: float = Field(0.1, gt=0, le=10)

    @model_validator(mode="after")
    def ordered(self):
        if self.min > self.max:
            raise ValueError("Weight 최소값이 최대값보다 큽니다.")
        return self


class PromptDetectRequest(BaseModel):
    prompt: str


class PromptPreviewRequest(BaseModel):
    prompt: str
    artist_block: str | None = None
    style_block: str | None = None
    artist_block_enabled: bool = True
    style_block_enabled: bool = True
    artist_fallback: Literal["prepend", "append"] = "prepend"
    style_fallback: Literal["prepend", "append"] = "append"


class GenerationSettings(BaseModel):
    model: Literal[
        "nai-diffusion-5-full", "nai-diffusion-5-curated",
        "nai-diffusion-4-5-full", "nai-diffusion-4-5-curated",
    ] = "nai-diffusion-5-full"
    width: int = Field(832, ge=64, le=2048)
    height: int = Field(1216, ge=64, le=2048)
    steps: int = Field(28, ge=1, le=50)
    sampler: str = "k_euler_ancestral"
    scheduler: str = "karras"
    scale: float = Field(5.0, ge=0, le=20)
    cfg_rescale: float = Field(0.0, ge=0, le=1)

    @model_validator(mode="after")
    def dimensions_are_multiples(self):
        if self.width % 64 or self.height % 64:
            raise ValueError("width와 height는 64의 배수여야 합니다.")
        return self


class AppSettings(BaseModel):
    generation: GenerationSettings = GenerationSettings()
    positive_prompt: str = "1girl, {{ARTIST_BLOCK}}"
    negative_prompt: str = ""
    character_prompt: str = ""
    # Artist Block fallback position (kept under its original name for old settings.json).
    placeholder_fallback: Literal["prepend", "append"] = "prepend"
    retry_count: int = Field(2, ge=0, le=5)
    artist_block_enabled: bool = True
    style_block_enabled: bool = False
    style_fallback: Literal["prepend", "append"] = "append"
    # Legacy (v1 Style Pool) fields: kept so old settings.json still validates and can be
    # migrated. Tag counts now come from the Style Pool's per-category RND ranges.
    style_mode: Literal["random", "all"] = "random"
    style_min: int = Field(1, ge=0, le=50)
    style_max: int = Field(3, ge=0, le=50)

    # How one artist name is written into prompts; {artistname} is replaced per artist.
    artist_template: str = Field("artist:{artistname},", max_length=200)

    @model_validator(mode="after")
    def artist_template_has_placeholder(self):
        if "{artistname}" not in self.artist_template:
            raise ValueError("Artist 출력 형식에 {artistname} 이 있어야 합니다.")
        return self

    @model_validator(mode="after")
    def style_range_is_ordered(self):
        if self.style_min > self.style_max:
            raise ValueError("Style 최소 개수가 최대 개수보다 큽니다.")
        return self


class TokenUpdate(BaseModel):
    token: str
    remember: bool = False


class MixPreviewRequest(BaseModel):
    min_artists: int = Field(3, ge=1)
    max_artists: int = Field(7, ge=1)
    weight_min: float = 0.2
    weight_max: float = 1.2
    decimals: int = Field(1, ge=0, le=4)
    combo_count: int = Field(10, ge=1, le=500)
    images_per_combo: int = Field(4, ge=1, le=100)
    mix_seed: int | None = None
    seed_mode: Literal["shared", "per_combo"] = "shared"
    base_seed: int | None = None
    # "selected" is the legacy MIX-only mode and is treated as "active" (checked artists).
    pool_mode: Literal["active", "all", "favorites", "selected"] = "active"
    artist_block_enabled: bool = True
    style_block_enabled: bool = False
    style_mode: Literal["random", "all"] = "random"
    style_min: int = Field(1, ge=0, le=50)
    style_max: int = Field(3, ge=0, le=50)


class MixJobRequest(BaseModel):
    preview_id: str
    settings: AppSettings


class SingleJobRequest(BaseModel):
    settings: AppSettings
    target_mode: Literal["detected", "all", "active", "selected", "custom"] = "detected"
    selected_names: list[str] = Field(default_factory=list)
    images_per_artist: int = Field(2, ge=1, le=100)
    artist_weight: float = Field(1.0, ge=0, le=10)
    weight_decimals: int = Field(1, ge=0, le=4)
    seed_mode: Literal["shared", "random"] = "shared"
    base_seed: int | None = None


class FinderDirectInputRequest(BaseModel):
    """Danbooru Artist Finder -> 단일 작가 테스트 직접 입력. Plain artist names only: it cannot
    carry Pool, prompt, generation, Library, favorite, pin or Saved Combo changes."""
    artists: list[Annotated[str, Field(max_length=200)]] = Field(min_length=1, max_length=500)


class SavedComboCreate(BaseModel):
    job_id: str
    combo_id: int


class RegenerateRequest(BaseModel):
    settings: AppSettings
    images: int = Field(1, ge=1, le=100)
    seed_mode: Literal["original", "random"] = "random"


class LibraryGenerationSettings(BaseModel):
    width: int = Field(832, ge=64, le=2048)
    height: int = Field(1216, ge=64, le=2048)
    steps: int = Field(28, ge=1, le=50)
    sampler: str = "k_euler_ancestral"
    scheduler: str = "karras"
    scale: float = Field(5.0, ge=0, le=20)
    cfg_rescale: float = Field(0.0, ge=0, le=1)

    @model_validator(mode="after")
    def dimensions_are_multiples(self):
        if self.width % 64 or self.height % 64:
            raise ValueError("width와 height는 64의 배수여야 합니다.")
        return self


class LibrarySettings(BaseModel):
    """Artist Library's own generation settings (independent of the main screen)."""
    positive_prompt: str = ""
    negative_prompt: str = ""
    model: Literal[
        "nai-diffusion-5-full", "nai-diffusion-5-curated",
        "nai-diffusion-4-5-full", "nai-diffusion-4-5-curated",
    ] = "nai-diffusion-5-full"
    seed: int | None = Field(None, ge=0, le=2**32 - 1)  # None = pick one on the next generation
    artist_weight: float = Field(1.0, ge=0, le=10)
    artist_position: Literal["prepend", "append"] = "prepend"
    character_prompt: str = ""
    generation: LibraryGenerationSettings = LibraryGenerationSettings()


class LibraryGenerateRequest(BaseModel):
    """Library targets never use the mix/single filters (checked, excluded, pinned).
    "names" = the given artists, "all" = every Artist Pool artist, "missing" = Artist Pool
    artists without a sample made with the current Library 설정."""
    target: Literal["names", "all", "missing"] = "names"
    artist_names: list[str] = Field(default_factory=list, max_length=500)


class LibraryCoverUpdate(BaseModel):
    image_id: str | None = None


class LibraryResetRequest(BaseModel):
    confirm: bool = False  # the UI sends true only after the user confirms

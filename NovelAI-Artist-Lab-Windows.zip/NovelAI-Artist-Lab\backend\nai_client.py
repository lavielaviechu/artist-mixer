from __future__ import annotations

import asyncio
import io
import json
import logging
import zipfile
from dataclasses import dataclass

import httpx


log = logging.getLogger(__name__)

ENDPOINT = "https://image.novelai.net/ai/generate-image"
SUPPORTED_MODELS = {
    "nai-diffusion-5-full",
    "nai-diffusion-5-curated",
    "nai-diffusion-4-5-full",
    "nai-diffusion-4-5-curated",
}


@dataclass
class NaiError(Exception):
    message: str
    retryable: bool = False
    status_code: int | None = None

    def __str__(self) -> str:
        return self.message


class NovelAIClient:
    def __init__(self, timeout: float = 180.0):
        self.timeout = timeout

    @staticmethod
    def build_payload(prompt: str, negative_prompt: str, seed: int, settings: dict) -> dict:
        model = settings.get("model", "nai-diffusion-5-full")
        if model not in SUPPORTED_MODELS:
            raise NaiError("지원하지 않는 NovelAI 모델입니다.")
        parameters = {
            # The official web client sends 4 for V4.5 and V5 (verified: same image as 3 on V5).
            "params_version": 4,
            "width": int(settings.get("width", 832)),
            "height": int(settings.get("height", 1216)),
            "scale": float(settings.get("scale", 5.0)),
            "sampler": settings.get("sampler", "k_euler_ancestral"),
            "steps": int(settings.get("steps", 28)),
            "n_samples": 1,
            "ucPreset": 0,
            "qualityToggle": False,
            "sm": False,
            "sm_dyn": False,
            "dynamic_thresholding": False,
            "controlnet_strength": 1,
            "legacy": False,
            "add_original_image": True,
            "cfg_rescale": float(settings.get("cfg_rescale", 0.0)),
            "noise_schedule": settings.get("scheduler", "karras"),
            "legacy_v3_extend": False,
            "seed": int(seed),
            "negative_prompt": negative_prompt,
        }
        # V4.5 and V5 both read the prompt from v4_prompt / v4_negative_prompt. Without them
        # NovelAI now answers 500 Internal Server Error (reproduced 2026-09-30 on both models),
        # so they are always sent; char_captions stays empty when there is no character prompt.
        character_prompt = str(settings.get("character_prompt", "")).strip()
        characters, negative_characters = [], []
        if character_prompt:
            characters = [{"char_caption": character_prompt, "centers": [{"x": 0.5, "y": 0.5}]}]
            negative_characters = [{"char_caption": "", "centers": [{"x": 0.5, "y": 0.5}]}]
        parameters["v4_prompt"] = {
            "caption": {"base_caption": prompt, "char_captions": characters},
            "use_coords": False,
            "use_order": True,
        }
        parameters["v4_negative_prompt"] = {
            "caption": {"base_caption": negative_prompt, "char_captions": negative_characters},
            "legacy_uc": False,
        }
        if characters:
            # Unchanged from the previously working character-prompt requests.
            parameters["v4_negative_prompt"].update({"use_coords": False, "use_order": True})
        return {
            "input": prompt,
            "model": model,
            "action": "generate",
            "parameters": parameters,
        }

    @staticmethod
    def diagnostic_payload(payload: dict) -> dict:
        """The request body for error logs. The token lives only in the HTTP header and is
        never part of this; long prompt texts are shortened."""
        def shorten(value):
            if isinstance(value, str):
                return value if len(value) <= 400 else f"{value[:400]}…(+{len(value) - 400} chars)"
            if isinstance(value, dict):
                return {key: shorten(item) for key, item in value.items()}
            if isinstance(value, list):
                return [shorten(item) for item in value]
            return value
        return shorten(payload)

    async def generate(self, token: str, prompt: str, negative_prompt: str, seed: int, settings: dict) -> bytes:
        if not token.strip():
            raise NaiError("NovelAI API token을 입력해 주세요.")
        payload = self.build_payload(prompt, negative_prompt, seed, settings)
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    ENDPOINT,
                    json=payload,
                    headers={"Authorization": f"Bearer {token.strip()}", "Accept": "application/zip"},
                )
        except (httpx.TimeoutException, httpx.NetworkError) as exc:
            raise NaiError("NovelAI 서버 연결에 실패했습니다.", retryable=True) from exc
        if response.status_code != 200:
            retryable = response.status_code == 429 or response.status_code >= 500
            detail = ""
            try:
                parsed = response.json()
                detail = str(parsed.get("message") or parsed.get("error") or "")[:300]
            except Exception:
                detail = response.text[:300]
            log.warning(
                "NovelAI %s failed: status=%s body=%s request=%s",
                ENDPOINT, response.status_code, response.text[:1000], json.dumps(self.diagnostic_payload(payload), ensure_ascii=False),
            )
            message = f"NovelAI API 오류 ({response.status_code})"
            if detail:
                message += f": {detail}"
            raise NaiError(message, retryable=retryable, status_code=response.status_code)
        try:
            with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
                image_names = [n for n in archive.namelist() if n.lower().endswith((".png", ".webp", ".jpg", ".jpeg"))]
                if not image_names:
                    raise NaiError("API 응답 ZIP에 이미지가 없습니다.")
                return archive.read(image_names[0])
        except zipfile.BadZipFile as exc:
            raise NaiError("NovelAI API가 올바른 ZIP 이미지를 반환하지 않았습니다.") from exc

    async def generate_with_retry(self, token: str, item: dict, max_retries: int = 2) -> bytes:
        while True:
            try:
                return await self.generate(
                    token, item["final_prompt"], item["negative_prompt"], item["seed"], item["parameters"]
                )
            except NaiError as exc:
                if not exc.retryable or item["retry_count"] >= max_retries:
                    raise
                item["retry_count"] += 1
                await asyncio.sleep(min(2 ** item["retry_count"], 6))

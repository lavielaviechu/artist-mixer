@echo off
setlocal
cd /d "%~dp0"
title NovelAI Artist Lab

set "PORTABLE_PY=%~dp0python\python.exe"
if not exist "%PORTABLE_PY%" (
  echo [ERROR] The portable Python runtime is missing.
  echo.
  echo Expected file:
  echo   %PORTABLE_PY%
  echo.
  echo Please extract the complete NovelAI-Artist-Lab-Windows ZIP again.
  echo Do not run this source-only folder as a portable release.
  pause
  exit /b 1
)

set "PYTHONHOME="
set "PYTHONPATH="
set "PYTHONNOUSERSITE=1"
set "PYTHONDONTWRITEBYTECODE=1"

echo Starting NovelAI Artist Lab at http://127.0.0.1:8766
"%PORTABLE_PY%" -X utf8 app.py
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" (
  echo.
  echo The application stopped because of an error. See logs\app.log for details.
  pause
)
exit /b %APP_EXIT%
